---
name: project_auth_emails_branding
description: Branded Zee-voiced auth emails via Resend SMTP + Supabase; setup steps and decisions
metadata: 
  node_type: memory
  type: project
  originSessionId: cc10e71b-ba41-4f24-9d1e-83575959b9e4
---

2026-06-16: Reworked all transactional auth emails (signup confirm, team invite, password reset, magic link).

**Root finding:** Resend was NEVER actually wired up. All four emails were going out on Supabase's free
shared SMTP (`noreply@mail.app.supabase.io`, default templates) = the spammy look. The "Onboarding" Resend
API key (`re_aGo1Nw6n…`, sending access) sits unused in `erp/apps/website/.env.local` line 8; no code reads it.
TODO for founder: rotate that key (it surfaced in chat) and remove the unused env line.

**Approach chosen:** Custom SMTP (Resend) + branded templates pasted into Supabase dashboard. NOT the
Send Email Hook + React Email path (deferred as post-launch; plain-text twins already staged for it).

**Artifacts** (source of truth) in `erp/docs/auth-emails/`: `_base.html` master + 4 HTML + 4 `.txt` twins +
`README.md` (Phase 0 deploy logo → 1 verify domain → 2 SMTP → 3 paste templates → 4 verify + deliverability).
Logo assets at `erp/apps/website/public/email/zerupt-lockup.png` (+ `zerupt-mark.png`), cropped from
`agent-os/brand/assets/Banner.png`; serve from `https://zerupt.com/email/...` after a website deploy (REQUIRED
before emails render the logo). Verified rendering via browse — looks premium.

**Brand decisions baked in** (see [[feedback_no_em_dashes_product_copy]], brand-foundation/story):
- Emails are FROM Zee, the AI team lead (single owner-facing voice; female; زي in ar). Supabase SMTP sender
  name MUST be `Zee at Zerupt`, from `auth@send.zerupt.com` (subdomain, verified in Resend).
- Buttons are INK `#141310` (brand primary-action color; citron fails WCAG as a button fill). Olive-deep
  `#454729` is the only brand-safe green alt. Citron `#979C1A` used only as the accent rule.
- Ink header band holds the dark-bg lockup (banner bg `#14130F` = brand ink, seamless) + citron tagline
  "Your business, handled." as REAL text (not in image). Bilingual en + ar (Arabic art-directed not translated).
- Voice = quietly confident, warm, ends with momentum; leads with a teammate's job then the name (signup
  reveals Mira). No em dashes anywhere (verified clean).

**Deliverability (Primary not Promotions/Spam):** SPF+DKIM+DMARC must PASS; turn OFF Resend open/click
tracking for the domain (pixel/link-rewrite = promo signal); one CTA, minimal images, plain-text part,
sentence-case subjects. Full notes in the README.

**As-built (2026-06-16):** DNS = Namecheap; root zerupt.com mail = Google Workspace (so hussain@zerupt.com
is real). Sending domain `mail.zerupt.com` VERIFIED in Resend (DKIM + SPF on send.mail, Sending ON,
Receiving OFF). Sender = `Zee at Zerupt <zee@mail.zerupt.com>`. DMARC = root `_dmarc.zerupt.com` p=none
(subdomain inherits; no rua). Reply-To: dashboard SMTP CAN'T set one, so launch uses a no-code forward
`zee@mail.zerupt.com → hussain@zerupt.com` via **ImprovMX** (Namecheap native redirect doesn't do subdomains)
— MX `mail`→mx1/mx2.improvmx.com + SPF include:spf.improvmx.com on host `mail`. Proper reply_to header =
**DEV-424** (post-launch Send Email Hook in apps/api: reply_to + multipart text + per-locale ar/en).
