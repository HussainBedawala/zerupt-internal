---
name: project-gtm-migration-wedge
description: "Zerupt's locked go-to-market wedge and first-customer strategy (from /office-hours, 2026-05-31)"
metadata: 
  node_type: memory
  type: project
  originSessionId: cbde5de5-7fc7-463c-babe-d1c48c6f24db
---

Zerupt's GTM strategy, locked via /office-hours on 2026-05-31. Full design doc:
`~/.gstack/projects/HussainBedawala-zerupt-internal/hus3ain-main-design-20260531-011509.md`.

**The wedge (lead message, NOT the AI-advisor vision):** "Switch off your slow,
broken-Arabic billing in one afternoon. Fast Arabic invoicing, your barcode and invoice
layout your way, compliance-ready, and we move all your old data for free." The agentic-AI
"next move" advisor is the EXPANSION, lead with the painkiller.

**The switcher (validated, firsthand + desk research):** a GCC shop owner already paying
for clunky software (Tally, Vyapar, Zoho, Merpec) whose Arabic breaks, checkout is slow,
nervous about compliance (ZATCA), stuck only by fear of losing old data on migration.
Recurring complaints from Merpec's Kuwait customers: no proper Arabic, too slow, not enough
features, no invoice/barcode customization.

**COLD-START REFRAME (2026-05-31):** Merpec customers CANNOT be taken (family — can't
cannibalize dad's business). Merpec data = internal TEST fuel only, never customers. So
treat acquisition as a pure cold start. The warm-list "unfair advantage" is dead; the
self-serve migration import tool is now the thing that kills the data-loss switching
objection for COLD customers.

**Beachhead LOCKED = GCC first (UAE/Saudi).** Economics: ~85 customers to $5k MRR at ~$60/mo
vs ~330 in India at ~$15/mo. GCC is where the differentiator (proper Arabic + ZATCA + premium)
is worth the most, willingness-to-pay is higher, churn lower, competition weak in good-Arabic
software. India/SEA = phase-2 expansion AFTER proof + revenue (price-crushed, brutal Tally/
Vyapar competition, fights premium positioning). HQ-in-India is fine for cost base but don't
lead sales there.

**Cold acquisition channel stack (ranked):** (1) partnerships/channel — VAT/bookkeeping firms,
business-setup consultants, POS hardware vendors in GCC (India = CAs later); the recommender
matters more than ads. (2) intent SEO — "Tally alternative", "Arabic billing software",
"ZATCA e-invoicing software", competitor comparison pages. (3) founder + product content
(record-once-clip-many). (4) communities + manual outreach = first 20 customers. (5) paid ads
= message-testing lab only at $300/mo. First ~20 customers are MANUAL; channels are built after.

**Trust manufacturing (cold, no warm intro):** free trial + self-serve migration + localized
proof/testimonials + obsessive Arabic/compliance/local-payments + a switch guarantee.

**Keystone feature for global scale:** self-serve migration/import tool (owner exports file
from current software, drops it in, Zerupt maps + imports). Without it the wedge is a Kuwait
consulting shop, not a global product.

**Channels:** organic founder short-form video (@hussainbuildswithai + @zerupt.erp) on
Instagram + TikTok = the engine. $300/mo ads = message-testing lab only (CANNOT be the
acquisition engine at that budget). One landing page, not 200. No webinar, no waitlist deposit.

**Current assignment (as of 2026-05-31):** offer 10 frustrated Merpec customers a free
data-migration switch; win = 3 say "yes when?" + 1 pays; grab one's export file to test
self-serve migration feasibility.

Related: [[feedback_full_suite]], [[project_mvp_status]].
