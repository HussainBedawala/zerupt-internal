---
name: feedback-no-scope-cuts
description: Do NOT suggest cutting Sales, Purchase, or AI onboarding from MVP — Hussain validated these are essential
type: feedback
---

Do not suggest stripping the MVP to POS-only or cutting modules like Sales Invoicing, Purchase, or AI Onboarding.

**Why:** Hussain has talked to experienced people and shop owners. Competing in MENA/India/SEA requires a full retail ERP (accounting, POS, sales, purchase, reports). The AI onboarding + AI suggestions are the #1 differentiator vs Zoho/Tally/ERPNext. Cutting them makes Zerupt just another half-baked POS.

**How to apply:** Focus on execution speed, not scope reduction. Help him build faster, not build less.
