---
name: project-ecc-hooks-decoupled
description: ECC plugin disabled to cut context; hooks now self-managed in project settings.local.json
metadata: 
  node_type: memory
  type: project
  originSessionId: 2ead97e3-4c53-41de-8a96-b1f2b0dad7df
---

On 2026-05-25 the everything-claude-code (ECC) plugin was **disabled** in
`.claude/settings.local.json` (`enabledPlugins["everything-claude-code@everything-claude-code"] = false`)
to remove ~41 stack-irrelevant skills from session-load context.

ECC's hooks were preserved by **moving the hooks block into `settings.local.json`**
(the `hooks` key), with `${CLAUDE_PLUGIN_ROOT}` rewritten to the absolute local path
`/Users/hus3ain/Development/Zerupt/.claude`. The hook scripts were already vendored at
`.claude/scripts/hooks/` and the runner (`run-with-flags.js`) self-resolves to the local
`.claude/` when `CLAUDE_PLUGIN_ROOT` is unset.

**Why:** ECC dumped 65 skills into every session; only 24 useful ones were already
vendored in `.claude/skills/` (tdd-workflow, content-engine, search-first,
strategic-compact, eval-harness, verification-loop, etc.) and stay regardless.

**How to apply:** Hooks are now OWNED by the project, not the plugin — ECC updates won't
auto-propagate. To change hooks, edit `settings.local.json`. Backup at
`settings.local.json.bak`. Also disabled: `vercel`, `figma` plugins (global settings.json).
Deleted `.claude/rules/common/` (duplicated global). See [[MEMORY]].
