---
name: project_migration_deploy_hardening
description: Tenant migration deploy now self-verifies (drift guard) + feature-flag infra; root cause of silent-skip was Railway config-as-code path unset
metadata: 
  node_type: memory
  type: project
  originSessionId: 9c43ef51-5270-4c9c-ae49-19d803ee9d68
---

2026-06-28: Fixed the long-standing "new migrations don't reach EXISTING prod tenants" problem
permanently and shipped feature-flag infra. See study/ops/tenant-migration-deploy/README.md.

**Root cause of the silent skip:** Railway's config-as-code path was UNSET, so
`apps/api/railway.json` (which holds the preDeployCommand that migrates existing tenants) was
ignored entirely; only dashboard build settings ran. User set the path to `/apps/api/railway.json`
2026-06-27. Then the Docker build failed on the husky `prepare` script (no .git in build context)
-> fixed with `ENV HUSKY=0` in apps/api/Dockerfile (both stages). New tenants were always fine
(provisioning applies migrations at signup); only existing tenants were skipped.

**Shipped on main** (commits 58cb0a85, 76e1c680, 91bfcdb1):
- `migrate-all.cli` = single-process pre-deploy (admin then tenants apply), non-zero exit on any
  failure. railway.json preDeployCommand = `node dist/migration/migrate-all.cli`.
- Boot-time drift guard (apps/api/src/health/migration-drift.service.ts + migration-health.indicator.ts):
  bootstrap dry-run scan, cached; wired into GET /api/v1/health -> behind/failed fleet returns DOWN,
  so Railway keeps the old version. Escape hatch env `STRICT_MIGRATION_HEALTH=false`. Detail:
  GET /api/v1/health/migrations.
- migration_runs audit table (admin migration 0014); post-apply journal==target assertion.
- Feature flags (Tier 3.5): feature_flags admin table (migration 0015; tenant_id null = global;
  partial unique index = one global row per key), FeatureFlagsService (resolution tenant>global>off,
  30s immutable TTL cache), `@RequiresFeature('key')` + global FeatureFlagGuard (pass-through when no
  decorator/public/auth-only so existing routes unaffected), admin endpoints gated by
  PlatformAdmin+AdminGuard (env PLATFORM_ADMIN_USER_IDS — must be set in prod). NO customer self-serve
  UI yet. SACRED INVARIANT: one schema/codebase for all tenants; gate feature EXPOSURE via flags,
  NEVER fork schema/code per tenant.

**Proof it works:** deploy 5684f6bd pre-deploy logs showed the tenant step auto-running for the
first time (`Found 1 migratable tenant(s); target 0115; OK al_asala @ 0115`).

**LESSON (important):** DI wiring bugs evade unit tests (they mock DI). 5684f6bd FAILED on boot
because MigrateTenantsModule provided but did NOT export MigrateAllTenantsService -> the drift guard
crashed the app -> healthcheck never green -> Railway held the old version (NO outage; the guard
caught its own bug). Fix added the export + two compile smoke tests: health.module.spec.ts and
app.module.boot.spec.ts (full AppModule graph compile, no lifecycle hooks). ALWAYS add a
module-compile smoke test for new NestJS module wiring.

**Manual fallback** (still valid, the blessed way; supersedes nothing in [[project_manual_tenant_migration]]):
`railway run --service "@zerupt/api" --environment production node apps/api/dist/migration/migrate-tenants.cli [--apply]`
(dry-run without --apply). Always verify from the actual DB via Neon MCP, never trust CLI output.

**Remaining (post-launch):** Tier 4 changelog tied to target-tag bumps; feature-flag self-serve UI;
pre-go-live reconciliation gate.

**PLATFORM_ADMIN_USER_IDS:** NOT launch-blocking, leave UNSET. Gates only the feature-flag admin
API endpoints; it's the list of ZERUPT OPERATOR (founder) Supabase auth UUIDs, NOT customers — does
NOT grow with customers. Manage flags by editing feature_flags rows directly in admin DB via Neon
until an admin UI exists. Set it to the founder's OWN Supabase auth UUID (from Supabase Auth by email,
not Neon) only when he wants to toggle flags through the live app. 2026-06-28 only prod user =
Al-Asala owner 02196df6-e121-4d87-90c9-e80a2ed17166 (likely founder test tenant, unconfirmed).
Related: [[project_admin_migration_deploy_gap]], [[project_neon_db_topology]], [[project_manual_tenant_migration]].
