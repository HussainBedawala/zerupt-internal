---
name: feedback_pos_approval_gates_settings_optional
description: "POS manager-approval gates must be settings-gated and default OFF, not mandatory — a sole owner runs the till alone"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4a79818d-3b2d-471b-a5bd-68a3481da3f6
---

Founder ruling (2026-07-05, POS submodule 05 returns dogfooding): do NOT hardcode a mandatory manager-approval/PIN on POS actions. Many tenants are a **sole owner running the till** with no manager to approve. Approval must be **opt-in via a per-register setting, default OFF** — if the owner enables it, require the manager PIN + SoD; otherwise let the cashier through. This is the same shape as void (which has no approval at all).

**Why:** a mandatory approval strands a solo operator (they cannot self-approve). MENA/SEA/India retail is heavily owner-operated.

**How to apply:** for any POS approval gate, add a nullable/boolean policy column on `pos_registers` (pattern: `require_approval_for_no_receipt_return` boolean default false, or `max_discount_pct_without_approval` nullable threshold), read it in the service BEFORE the PIN block, and only enforce SoD + `pinVerification.verifyApproval` when enabled. Frontend reads the flag from register context and conditionally renders `ApprovalPinFields` (reference impl: discount gate in `cart-line-row.tsx`). Surface the toggle in the register-settings "Approvals" section. Shipped for no-receipt returns in commit d8edf92f (migration 0155). Aligns with [[feedback_decide_for_module_persona]] and [[feedback_assume_dumb_customers]].
