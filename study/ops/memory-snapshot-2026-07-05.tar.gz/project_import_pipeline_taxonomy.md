---
name: project_import_pipeline_taxonomy
description: "AUTHORITATIVE live-vs-dead map of the data-import/migration pipeline — read FIRST before touching any import code; 'rung/ladder' is CURRENT, Pipeline A is the dead one"
metadata: 
  node_type: memory
  type: project
  originSessionId: b7343043-4d75-4be1-9ebf-f973e9397933
---

Authoritative taxonomy of Zerupt's import/migration code (verified against the tree 2026-06-15). Written because agents kept treating the live rung/ladder engines as "old" and proposing to delete them. **Read this before any import cleanup.**

> ⚠️ SUPERSEDED IN PART (2026-06-17): founder ruled column/field/location MEANING resolution must
> be **fully AI-first**; the deterministic rung/alias gate is being REMOVED, not kept. See
> [[project_import_ai_first_mandate]]. The Pipeline-A live-vs-dead map below is still valid; the
> "keep the rung ladder for column mapping" stance is not.

## The one rule
"rung", "ladder", "tier", "T0–T5" are the **CURRENT, LIVE** engines. The dead thing is **Pipeline A** — the old `consolidate → graph → nodes` flow with decision-cards + matching-review. Do not conflate them.

## LIVE engines (NEVER delete)
- **Unified import = the AI-first front door.** `UnifiedImportPlanService` → `AiImportClient.classifyFile()` → AI route `POST /ai/import/classify-file` (gemini-2.5-flash-lite, `import_classifier.py`) classifies each file's PURPOSE with AI, then routes by purpose. Endpoints: `POST .../sessions/:id/plan` (writes nothing) + `:id/commit-unified`. Frontend hook `features/migration-matching/hooks/use-mira-import-flow.ts` (phases collecting→previewing→done). Screens: onboarding mira-import + in-product `data-import-flow.tsx`.
- **Entity rung ladder:** `apps/api/src/import/` — `ImportResolutionService` (rungs 1–4 deterministic + rung-5 LLM column-mapping for the unresolved tail) → `ImportApplyService`. Controller `tenant/imports`. Reused by the unified flow for product/customer/supplier/category. Column mapping is HYBRID (deterministic fast-path feeds AI; AI owns the tail), file classification is AI.
- **TB import:** `apps/api/src/tb-import/` → `ResolverEngineService` (`apps/api/src/resolver-engine/`, tiers T0 normalize→T1 exact→T2 memory→T3 semantic/pgvector→T4 LLM→T5 card) + AI `/ai/diagnose`.
- **Opening import:** `apps/api/src/opening-import/` (stock/party/balance + reconciliation).
- **Migration session + matching service:** `migration-session.service/controller` (create/`:id`/`plan`/`commit-unified`/`reconciliation-overrides`/`next-move`), `MiraMatchingService` (LIVE — injected by `import-resolution.service.ts` and powers the `next-move` dashboard card via `dashboard/first-login.tsx`).

## DEAD — "Pipeline A" (removed 2026-06-15 on web)
Old consolidate→graph→nodes flow. Backend source was already gone (only stale `dist/migration/*.js` artifacts remained: migration-apply, migration-consolidate.client, migration-node-projection, migration-opening-synthesis, graph-edge-derivation, party-conversion-plan). The `/consolidate`, old `/commit`, `/cards/resolve` routes DO NOT EXIST on the backend.
Web Pipeline A island deleted: `migration-session-view`, `decision-card-stack`, `matching-review-panel`, `candidate-band-section`, `ai-matched-badge`, `undo-queue`, `migration-settings-panel`, `migration-matching/mira-narration-panel`, and the unlinked `settings/migration` + `[sessionId]` pages. Dead funcs trimmed from `session-api.ts`/`session-queries.ts`/`matching-api.ts`/`matching-queries.ts`/`index.ts` (kept: createSession, plan/commit-unified, `getMigrationNextMove`/`useMigrationNextMove`).

## DEPRECATED but NOT deleted (founder decision 2026-06-15)
Backend `mira-matching.controller.ts` routes `/matching/{state,bulk-accept,undo-accept,park,resolve,finish-later}` have ZERO live frontend callers after the web cleanup, BUT are audited money-path endpoints on the still-live `MiraMatchingService`. Annotated `@deprecated`, kept pending a dedicated backend removal pass. `next-move` + `MiraMatchingService` stay live.

Backend follow-ups for that same removal pass: (1) those 6 deprecated matching route handlers + their `MiraMatchingService` methods (`getMatchingState`/`bulkAccept`/`undoBulkAccept`/`parkToSuspense`/`resolveSuspenseItem`/`getFinishLaterCards`) — keep `getLatestNextMove`; (2) `migration.types.ts` header comment + Pipeline-A-only types still describe the dead `/ai/migration/consolidate` + deleted `migration-consolidate.client.ts` — the file is MIXED (its clean/control-total types are still imported by LIVE `migration-clean.client.ts`/`reconciliation-bridge.ts`), so split live vs dead types carefully; (3) stale `dist/migration/*.js` artifacts regenerate clean on next build.

NOTE: the onboarding `features/onboarding/components/import/mira-narration-panel.tsx` is a DIFFERENT, LIVE file — not the deleted migration-matching one.

See [[project_resolver_engine_tb_import]] [[project_unified_mira_import]] [[project_tb_import_zero_question_session]] [[project_import_pipeline_fixes_2026-06]].
