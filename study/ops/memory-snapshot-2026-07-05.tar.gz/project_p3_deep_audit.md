---
name: project_p3_deep_audit
description: P3 deep audit (2026-07-04) findings + remediation status; what shipped vs founder to-dos
metadata: 
  node_type: memory
  type: project
  originSessionId: f63cdf24-a586-47e8-8468-50bbb325880a
---

P3 four-track deep audit (security, perf-at-scale, POS resilience, observability) run 2026-07-04 after the P0-P2 infra program ([[project_infra_audit_2026-07-04]]). Report: `study/ops/deep-audit-2026-07-04.md`. Method: 12 finder agents + adversarial refuters; 45 raw -> 21 confirmed CRITICAL/HIGH.

**Remediation SHIPPED same day** to erp main (5 commits `81a3673b..669ee447`, pushed): fc30c92f auth (#1 request-time active-membership guard in TenantResolverGuard + revoke on suspend/deactivate; #2 owner system-role sync on demotion; new reusable `TtlCache` in packages/tenant-context), ace986a4 pos money-path (#11 retryable 401/408/429, #12 discount PIN fail-closed + 5s timeout, #13 orphaned-Syncing reset for sales/shifts mirroring the movement fix), 92b10696 security (#3 mira-voice TTS auth+canned-utterance allowlist, #4 shared escapeSpreadsheetField, #5 shared assertSafeXlsxBuffer zip-bomb guard on 5 load sites, #6 admin_audit_log table mig 0016, #16 private signed-URL exports), 0a3b0dcd perf (#7 catalog date_trunc removed, #8 reporting date indexes mig 0151 + sargable predicates via localDateRangeBoundsUtc, #9/#10/#17 valuation/reconciliation/stock-levels pagination+statement-timeouts), 669ee447 obs (#21 pg-boss down-too-long Sentry alert via new pg-boss-monitor).

Verified: api+web typecheck clean, i18n sync, AppModule boot smoke green, all touched suites pass; 13 API + 8 web pre-existing failures confirmed identical on clean main (no regressions). Migs auto-apply on Railway pre-deploy.

**Founder to-dos (non-code, NOT done):** #14 Sentry metric alerts (error-rate + p95/p99) to a real-time channel; #15 raise Neon history_retention_seconds 6h->7-30d + set prod branch protected:true. **Deferred backlog** (gated on register/tenant count): #18-#20 pos-transactions pay() lock-contention/fan-out, connection-pool metrics, remaining MEDIUM/LOW.

Landmine hit: a concurrent session pushed 3 commits mid-work (sales 3dp, reserved-stock, shift-close JE) onto the ba24b032 baseline; verified zero file overlap with my changes before committing. Commit by explicit pathspec held.
