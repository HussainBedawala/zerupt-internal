---
name: project_ai_model_reliability_2026-06-18
description: "Reliability-first AI model routing — Gemini 2.5 Flash workhorse, DeepSeek json_schema bug fix"
metadata: 
  node_type: memory
  type: project
  originSessionId: 48426466-e97c-4832-a256-d55fc518a713
---

2026-06-18 founder mandate during prod TB/product import debugging: stop fragile cost-cutting model routing; use the most reliable model even if costlier. Supersedes the cost-first split in [[project_ai_cost_routing_philosophy]].

**Root causes found in prod (Railway AI service logs):**
- `/ai/embed` → 502: `OPENAI_API_KEY` was unset (text-embedding-3-small, no fallback; dim-locked to pgvector 1536). Founder set the key. This 502 broke BOTH product/stock import (direct embed) AND the TB resolver's T3 step.
- `coa-resolver` deepseek/deepseek-chat failed: `response_format type is unavailable now`. **DeepSeek only supports `json_object`, NOT strict `json_schema`.** Router used `litellm.supports_response_schema()` which returned True for deepseek → sent json_schema → hard reject; limped on groq fallback.
- `tb-diagnoser` gemini-2.5-flash-lite intermittently DROPPED required fields (omitted `asOfDate`) → JSONSchemaValidationError → flash fallback.

**Changes shipped (apps/ai, uncommitted as of this note; AI service needs redeploy to take effect):**
- `app/llm/router.py`: replaced `supports_response_schema` probe with explicit `_JSON_SCHEMA_PROVIDERS` allowlist (openai/azure/gemini/vertex_ai/groq/anthropic/bedrock/xai/databricks/ollama). DeepSeek + unknown → `json_object`. Fixes deepseek as primary AND fallback; immune to litellm metadata drift.
- `app/llm/task_routes.py`: **Gemini 2.5 Flash is now the workhorse primary for every text/structured task** (was flash-lite + deepseek). flash NOT flash-lite (lite dropped required fields). Capability exceptions only: Arabic COA + entity/party name matching → Qwen3-32B on Groq; invoice VLM → Gemini Flash (multimodal); embeddings → OpenAI (separate). **Fallbacks must be a DIFFERENT provider than primary** (a gemini→gemini fallback can't survive a provider outage) — enforced by `test_fallbacks_are_different_provider_than_primary`. DeepSeek demoted to fallback-only (works now via json_object).
- All 497 AI tests pass; ruff clean on edited files.

**Interim no-deploy mitigation** (Railway deploy was flaky): per-task env overrides `ZERUPT_LLM_ROUTE_<TASK>=gemini/gemini-2.5-flash` change the PRIMARY without a code deploy (e.g. ZERUPT_LLM_ROUTE_COA_RESOLVER). Override only swaps primary, not the router json_schema fix — but pointing primary at allowlisted gemini sidesteps the deepseek bug.

**Gemini resolver truncation (fixed, commit 40b68688, pushed to main):** after redeploy, `coa-resolver` gemini-2.5-flash still failed once per import with `JSONSchemaValidationError` on a JSON array cut off mid-emission, limping onto a ~21s deepseek fallback. NOT a gemini reliability problem — two compounding config bugs: (1) `resolve_batch` (app/llm/resolver.py) called `complete_task` WITHOUT `max_tokens`, so it used the 4096 `llm_token_budget` default instead of the 8192 `coa_token_budget`; a 50-item chunk (each emitting a `reasoning` string) overran it. (2) **Gemini 2.5 Flash has thinking ON by default and those hidden reasoning tokens are billed against `max_tokens` before any visible JSON** → array truncated. Fix: added `reasoning_effort` field to `TaskRoute`, set `"none"` on the deterministic pick-from-candidates/classification tasks (coa-resolver, column-resolver, column-mapper, coa-classifier-en, schema-infer, import-classifier, location-mapper) — litellm maps `"none"`→thinkingBudget=0 for gemini, drop_params strips it elsewhere; tb-diagnoser KEPT thinking (layout reasoning helps, small output). Router threads `route.reasoning_effort` into acompletion only when set. Resolver now passes `max_tokens=coa_token_budget`. Regression tests added. Reversible per-task — not a global kill switch.

**Still open:** optional API-side resilience — wrap resolver-engine T2 `lookupExact` + T3 `nearest`/embed in try/catch so a memory/embed failure degrades to a populated decision card instead of crashing the whole import (see [[project_resolver_engine_tb_import]]). Founder TODO: update `agent-os/product/ai-engine/05-model-strategy.md` to match.
