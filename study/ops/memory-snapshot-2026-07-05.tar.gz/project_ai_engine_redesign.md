---
name: ai-engine-redesign
description: "2026-06-07 from-scratch AI engine redesign — Zee persona + team, own-the-brain strategy, invoice scanner in MVP, money-found engine next"
metadata: 
  node_type: memory
  type: project
  originSessionId: 01775f77-7355-463b-9ac2-1830d143d861
---

2026-06-07 brainstorm (Hussain + dad validation) replaced the old AI spec wholesale. Canonical spec: `agent-os/product/ai-engine/` (old `agents/` → `archive/agents-2025/`).

Key decisions:
- **Identity:** staged — fabric (day 1) → analyst (wk 2+) → employee (mo 3+). Persona: **Zee** (master, "your AI partner") + named team: Sami (invoice scanner), Noor (dead stock), Arjun (stockout), Tariq (shrinkage), Maya (margin). Whoop-style progressive unlock framed as *hiring* ("Noor starts in 18 days").
- **Model strategy:** own the brain (classic ML, CPU, our infra — all prediction/detection), rent the mouth (cloud LLM, language only), borrow extraction (cloud VLM → self-hosted fine-tuned later), train SLMs later from correction capture. Privacy promise (hard constraint): "your numbers never leave Zerupt."
- **Architecture:** `apps/ai` grows into the ML brain; **Python thinks, NestJS acts**; brain reads tenant DBs read-only, never writes business tables.
- **MVP (June 15!):** Sami invoice scanner in MVP — purchase invoices only, photo+PDF, draft + 1-tap approve & post, correction capture from day 1. 8-day plan in `02-invoice-scanner.md`.
- **Post-MVP build order:** substrate → Noor (validated ⭐ by dad interview) → Maya → Tariq → Arjun. Copilot demoted to last phase. WhatsApp channel deferred (complexity).
- Validation: dead-stock angle + photo→posted confirmed strongest in retail-owner interview; $5/day ad tests per angle planned, WhatsApp-start = intent metric.

Update 2026-06-07 (later): another agent added **Mira** (migration brain, agent #0, `07-mira-migration-brain.md` — vendor-agnostic pathology detectors, no per-vendor adapters EVER, 11-file Kuwait fixture, matching-UX doctrine: create-by-default + bulk-accept) and locked the model matrix in `05` (Gemini 2.5 Flash/Flash-Lite, DeepSeek V4-Flash, Qwen3-32B on Groq, Cerebras free tier; Gemini 2.0 Flash is deprecated — don't use). Code audit + foundation plan written to `08-foundation-plan.md`: F0 bedrock (routing, health/no-silent-degradation, file retention, read-only tenant role + Python db access, scheduler, SSE, generic ai_corrections table) → F1 Mira → F2 Sami → F3 detector substrate. June-15 honest cut: F0 subset (~3d) + Mira slices 1–3 OR thin Sami.

**Why:** user was unhappy the import flow "doesn't feel like AI"; wants AI at the core, not invisible rung-5 assists; long-term-right over easy.
**How to apply:** all AI work reads `agent-os/product/ai-engine/` first; never propose cloud-LLM processing of transaction data; frame AI features in Zee/team/money language. Related: [[mvp-status]]
