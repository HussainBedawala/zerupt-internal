---
name: project_pricing_offer
description: Zerupt GCC pricing structure + Grand Slam Offer decisions (locked 2026-06-01)
metadata: 
  node_type: memory
  type: project
  originSessionId: 4e0aab3e-bc5f-4bad-9224-83e53cf60d14
---

Pricing + offer strategy locked 2026-06-01. Canonical doc: **Linear → Customer Acquisition project → "Grand Slam Offer — Zerupt GCC (v2, 2026-06)"** (https://linear.app/zerupt/document/grand-slam-offer-zerupt-gcc-v2-2026-06-f527d29da2d7). Supersedes the March per-user offer in `agent-os/grand-slam-offer.md` (now stale — flagged for replacement with a pointer).

**Decisions:**
- **Beachhead:** GCC only (Kuwait, Saudi, UAE, Bahrain, Oman, Qatar). India/SEA = phase-2 PPP-priced. India is a premium-ARPU trap (Tally/Vyapar anchored WTP near zero).
- **Pricing axis:** per OUTLET, unlimited staff logins bundled. Per-seat rejected (high-churn cashiers, login-sharing, fights agentic product).
- **Tiers (SAR/mo, 1 outlet base):** Starter 149 (~$40, AI = basic alerts only) · **Growth 349 ⭐ Most Popular** (full "Your Next Move" AI advisor, 50 actions/mo) · Pro 699 (unlimited AI, anchor) · Chains (custom). Extra outlet add-on: +99/+149/+249. Core ERP + ZATCA never gated — only scale + AI depth gated. Annual = 2 months free. Bill in local currency. KWD anchors: 12/29/55.
- **AI advisor ("Your Next Move") = the upsell lever**; metered as predictable "AI actions/mo", never raw credits.
- **Guarantee (2 parts, both on the 2-hour USP):** (1) Speed — live in <2hrs or we do setup+migration free, don't pay until running; (2) 30-day clarity-or-full-refund. Dropped the confusing 24-48h language.
- **Founding 50** — lifetime-locked founder pricing, public seat counter for urgency.
- **GTM motion:** no card at signup → concierge onboarding = activation event → capture card after live. Reverse trial, never permanent freemium.

**Cost reality:** all-in cost-to-serve ~$0.80–1.70/tenant/mo (Neon usage-based + scale-to-zero makes per-tenant DBs cheap, NOT ruinous; shared Railway/Vercel; cached daily AI advisor). → 95%+ gross margin → price purely on value.

**Positioning fix (ties to [[founder positioning]]):** brand leads emotional ("Your business, handled. Know your next move."); category words (POS, accounting, inventory, ZATCA) live one layer down for comprehension + SEO. Never lead a customer surface with "ERP" — but BE the ERP in metadata/comparison pages so intent-searchers find us.

**Status:** v1 hypothesis. Validate numbers with first 5–10 GCC prospect calls (checklist in the Linear doc) before locking.

**Offer doc in repo:** `agent-os/offer.md` (mirror of the Linear "Offer" doc, so we don't have to call Linear; Linear wins on conflict). Old `grand-slam-offer.md` deleted.

**Pricing page — BUILT (2026-06-01):** `apps/website/src/app/[locale]/pricing/page.tsx` + `src/components/pricing/*` + `src/lib/{pricing,links,utils}.ts` + `messages/{en,ar}/pricing.json`. Brand-led hero + category doorway, currency selector (6 GCC + timezone auto-detect, default SAR), monthly/annual toggle (annual = 2mo free, NumberFlow animated), Growth badged Most Popular, Chains band, Founding-50 scarcity band w/ seat counter, two-part guarantee. CTAs: "Start free"→`{APP_URL}/{locale}/signup` (no card), "Book setup"→themed Cal.com popup `zerupt-onboarding/zerupt-onboarding` (env `NEXT_PUBLIC_CAL_LINK`, signup fallback). Reverse-trial confirmed: card captured AFTER onboarding/go-live, not at signup. Founding-50 UX: signup→account→booking. Brand tokens added to website `globals.css`. Deps added: motion, @number-flow/react, lucide-react, clsx, tailwind-merge, @calcom/embed-react. Typecheck/lint/i18n/build all green; reviewed (frontend + code), findings fixed. See [[defensive_ux]].

**Redesign + DB shipped (2026-06-01, uncommitted):** Refined editorial/luxury redesign done via parallel subagents. Site-wide navbar (`components/layout/navbar.tsx`) + founding announcement bar (`announcement-bar.tsx`) in `[locale]/layout.tsx`; slop hero pill removed. Compact flag currency selector (6 GCC, emoji flags + ISO country in `lib/pricing.ts` `CURRENCY_META`). Country-specific tax line in tier cards (`compliance` map in pricing.json by ISO: SA=ZATCA+15%, AE/OM=5%, BH=10%, QA/KW="no VAT yet") — ZATCA no longer shown globally. Guarantee moved up under grid, restyled editorial. Homepage rebranded violet→brand (styling only, copy untouched). Cal popup themed (cal-brand=ink/light). **Zero em/en dashes anywhere** (standing rule, enforced incl. comments).

**Live seat counter:** NestJS public endpoint `GET /api/v1/public/founding-seats` → `{seatsLeft,total}` (admin DB count of subscriptions in trial/active/past_due; founding total=50; fail-open; `@Throttle 10/60s`; `@Public`). Website `lib/founding.ts` fetches it server-side (revalidate 60s) with env fallback. TODO: switch count to explicit `is_founding` flag when cohort schema lands.

**is_founding flag (scalable, the right way):** `subscriptions.is_founding boolean default false` + partial index `idx_subscriptions_is_founding WHERE is_founding=true`. Founding seat = permanent property, NOT released on churn; cohort capped at first 50 grants ever. Granting rule (documented in schema + service, implement at signup): in a txn, `SELECT count(*) WHERE is_founding FOR UPDATE` (or `pg_advisory_xact_lock`) and if <50 set is_founding=true + lock price. Seat counter endpoint now counts `is_founding=true` (was status proxy). Migration `0003_salty_captain_flint`.

**Neon — APPLIED TO BOTH DEV AND PROD (2026-06-01), verified identical:** Neon project `restless-hill-33464873`, branches: production=`br-red-term-a1vs9ndl` (default), development=`br-old-recipe-a1d3dw26`; admin DB = `zerupt_admin`. Prod was at base schema with OLD USD 29/79/199 plans; migrated via Neon MCP `run_sql_transaction` (idempotent, additive): applied 0002+0003 DDL, plans→SAR anchors, 18 plan_prices, journal rows. Verified prod = 3 plans SAR, 18 plan_prices all matching dev, is_founding present, seats_left=50, journal 0000-0003. NOTE: prod uses `public.__drizzle_migrations` (hash=tag-name convention); dev uses `drizzle.__drizzle_migrations` (hash=SHA256) — different, both reconciled. Skipped the cosmetic provisioning-index drop/recreate on prod (already correct).

**Live seat counter — prod gap:** `@zerupt/api` (Railway, project `324fdb75-...`, svc `8e4421f7-...`, prod env `bd37f650-...`) has NO public domain (private `api.railway.internal` only). Website on Vercel can't reach it → counter falls back to env number until API is exposed. CORS_ORIGINS change NOT needed (seat fetch is server-side/ISR, not browser). When API gets a public domain (api.zerupt.com) for launch: set `NEXT_PUBLIC_API_URL` on the website Vercel project; add website origin to CORS_ORIGINS only if any client-side API call is added.

**Neon plans schema (Part F) — applied to DEV+PROD:** new `plan_prices` table (3 tiers × 6 currencies = 18 rows) + `plans.aiActionsLimit` (starter 0 / growth 50 / pro null) + `plans.includedOutlets`. Canonical `packages/db-admin/src/scripts/sync-plans.ts` (idempotent, single batch insert, `pnpm db:sync-plans`), seed-dev updated. Migration `0002_sour_colonel_america.sql`; drizzle `__drizzle_migrations` journal reconciled on dev (0000/0001/0002 backfilled) so a fresh PROD `drizzle-kit migrate` applies cleanly. **PROD DB write still PENDING explicit user confirm.**

**Reviewed:** frontend + security + code reviewers ran; all CRITICAL/HIGH/MEDIUM fixed (citron-on-dark contrast, nav/announcement i18n en+ar, a11y focus return, rel=noopener, batch insert, journal reconcile). Security clean.

**Still TODO:** commit (all changes uncommitted on `main` working tree); apply schema + sync-plans to PROD after confirm; set `CORS_ORIGINS` to allow website origin on Railway; validate price anchors with 5 to 10 GCC prospect calls; wire app billing/checkout to read `plan_prices` by tenant currency.
