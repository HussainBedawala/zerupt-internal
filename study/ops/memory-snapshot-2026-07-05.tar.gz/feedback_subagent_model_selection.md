---
name: feedback_subagent_model_selection
description: Always assign subagent models by task complexity — never leave default (cost)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3742979c-91a7-4026-9e5b-d1a5d3d1af4a
---

When spawning subagents (Agent tool / Workflow agents), do NOT use the default/inherited model blindly. Assess each task's complexity and assign the cheapest model that can do it well: Haiku for mechanical/search/lookup, Sonnet for standard implementation/review, Opus only for genuinely hard reasoning or synthesis.

**Why:** Defaulting to the inherited (often Opus) model for every subagent burns credits fast, especially in `/work` which delegates heavily (research, TDD, reviewers).

**How to apply:** Pass `model:` on every Agent/`agent()` call. Read-only Explore/search → haiku or sonnet. Code review / TDD / implementation → sonnet (escalate to opus only if the diff is subtle/financial). Reserve opus for cross-module synthesis or correctness-critical accounting logic. Pairs with [[feedback_delegate_subagents]].
