---
name: project_decimal_precision_hardening
description: App-wide decimal-precision fix — canonical money/quantity primitives + quantityDecimals column + ESLint guardrail (2026-07-03)
metadata: 
  node_type: memory
  type: project
  originSessionId: a2d929ec-8b25-44a8-85fc-4ea5ce9884b1
---

2026-07-03 overnight: killed the recurring "decimals hardcoded to 2/6dp, ignores currency/unit" bug class across the whole web app.

**Source of truth (use these; do NOT hardcode fraction digits):**
- Money display: `formatMoneyAmount(raw, currency, locale)` / `formatMoneyWithSymbol(...)` in `apps/web/src/lib/money-format.ts` — precision derives from ISO 4217 (KWD/BHD/OMR=3dp, JPY=0dp, else 2dp). Returns "—" for null.
- Money input: `<MoneyInput value onChange currency />` (`apps/web/src/components/money-input.tsx`) — blur-normalizes to currency precision.
- Quantity display: `formatQuantity(raw, quantityDecimals ?? null, locale)` (`apps/web/src/lib/quantity-format.ts`) — pass the item's `quantityDecimals`; pass `null` for transaction-line rows that don't carry it (shows natural precision ≤6dp, trimmed, never truncates).
- Quantity input: `<QuantityInput value onChange quantityDecimals={item?.quantityDecimals ?? null} />` — unknown precision = permissive ≤6dp; a known integer item passes 0.
- Existing correct helpers kept: `getCurrencyDecimals`/`formatToDecimals` (`lib/currency-precision.ts`), `currencyDecimals` (`@zerupt/shared`), `displayMoneyByCurrency` (purchase/customers lib). Deleted the forked `displayMoney`/`displayMoney3`/`displayMoney3dp`/`displayQuantity` helpers in purchase/sales/invoices/customers/sales-overview.

**New data model:** `items.quantityDecimals smallint NOT NULL DEFAULT 0` (range 0..6), migration `packages/db/drizzle/0147_opposite_power_pack.sql` (additive, no backfill). Flows schema → `ItemResponse`/`ItemListItemResponse` → web `Item`/`ItemListItem`/`PickedItemFull` → item-form-panel "Quantity Decimal Places" Select (0..3). 0 = integer/pcs, 2-3 = weighed/kg.

**Guardrail:** ESLint `no-restricted-syntax` in `apps/web/eslint.config.js` (DECIMALS_SELECTORS) bans hardcoded `min/maximumFractionDigits` literals and `.toFixed(n)` in money/quantity feature dirs (pos, sales, invoices, purchase, inventory, customers, journal-entries, bank-reconciliation, cheques). Percentages/exact-math/intentional-fallbacks opt out via `// eslint-disable-next-line no-restricted-syntax -- <reason>`.

**Status:** SHIPPED — committed `bcc9da7f`, pushed to main 2026-07-03 (all pre-commit gates green: lint-staged, turbo typecheck x14, console.log). Prod tenant DBs get `quantity_decimals` automatically via Railway pre-deploy `migrate-tenants --apply` on this deploy. Verified pre-push: web/db/api typecheck green; primitives 75 tests; web suite 2437 pass / 13 pre-existing-unrelated fail; api items 167 pass. OUTSTANDING: **dev** tenant DBs (`al_asala`, `merpec`) not yet migrated — auto-mode blocks tenant-DB migrations, so run manually: `cd packages/db && for DB in zerupt_tenant_al_asala_auto_parts_mqy1wpk2 zerupt_tenant_merpec_inc_mr1rlebl; do URL=$(...swap /zerupt_tenant_dev -> /$DB in DIRECT_URL_TENANT...); DIRECT_URL_TENANT=$URL npx drizzle-kit migrate; done`. See [[project_manual_tenant_migration]], [[feedback_never_hand_edit_migration_journal]].
