---
name: feedback_subagents_no_nested_spawn
description: Subagents must never spawn their own subagents — one level only
metadata: 
  node_type: memory
  type: feedback
  originSessionId: cf3f94bb-fb4f-4033-a828-fe0f62cb5f2a
---

I (main loop) may spawn subagents, but any subagent I spawn is NOT allowed to spawn further subagents. One level of delegation only.

**Why:** On 2026-06-15 a general-purpose agent tasked with investigating a bug went into a runaway loop and spawned 69 nested subagents ("Investigate tax setup 422…" repeated), which the founder had to kill manually. Nested spawning can fan out uncontrollably and burn cost/context.

**How to apply:** When delegating, prefer read-only agents (Explore) or explicitly instruct the agent in its prompt: "Do NOT spawn any subagents — do the work yourself inline." Never use a general-purpose/`claude` agent for open-ended investigation without that constraint. Relates to [[feedback_delegate_subagents]] and [[feedback_subagent_model_selection]].

**Canonical ruling (founder, 2026-07-02, inventory promotions — supersedes all below). Two exceptions only:**

1. **Subagents may NOT spawn subagents** — with ONE exception: an implementer subagent MAY spawn a sub-subagent for **pure recon/explore only**. That recon sub-subagent can NEVER spawn further — it does all its exploring itself. (So: implementer → recon child is allowed; recon child → anything is NOT.) Any other nesting (delegating the actual implementation, spawning reviewers, etc.) is forbidden.

2. **Test writing/fixing is ALWAYS a separate main-loop-spawned agent AFTER implementation finishes.** The implementer does NOT write/fix tests. Flow: main loop hands the task to an implementer subagent → implementer may spawn ONE recon child, then implements everything itself → implementer returns a report saying it's done + **which tests need fixing/writing**. The MAIN LOOP then spawns a completely separate test-fixing agent (right model for the job) that runs in the BACKGROUND while the main loop moves to the next task. This test agent fixes the named tests plus any other failing relevant tests. Never block waiting on tests — decouple them.

**Why:** parent isn't "done" until its child finishes, so nested implementation-spawning makes the main loop wait on grandchildren (defeats decoupling); and runaway nesting (69-agent incident 2026-06-15) burns cost/context. Founder does NOT want to repeat this instruction again — every session and every delegated agent must honor it by default.

**How to apply:** every implementer prompt states: "You MAY spawn ONE recon/explore sub-subagent (which must NOT itself spawn anything); otherwise do all implementation yourself and spawn nothing. Do NOT write or fix tests — instead return a report of what changed and which tests need fixing/writing." Then main loop spawns the background test agent + reviewer panel itself.

~~Prior (rescinded): implementer must spawn NOTHING at all.~~ Recon-child exception now permitted per above. ~~Prior (rescinded): implementer MAY spawn one test child.~~ Tests are main-loop-owned, post-implementation.
