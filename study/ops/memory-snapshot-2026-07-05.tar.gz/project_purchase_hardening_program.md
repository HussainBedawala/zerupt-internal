---
name: project_purchase_hardening_program
description: Overnight layer-by-layer audit + hardening of the purchase module (repeat of accounting/inventory programs); study + log in study/purchase/
metadata: 
  node_type: memory
  type: project
  originSessionId: fabc3982-7f28-4ce6-9184-3af647079bb9
---

Started 2026-06-29. Founder mandate: accounting + inventory are perfected
([[project_accounting_hardening_program]], [[project_inventory_hardening_program]]) — repeat the
SAME process for the ENTIRE purchase module so a purchaser/shopkeeper can run procurement for the
next 10 years.

**Two founder-specific requirements (differ from prior programs):**
1. **Dual path, first-class every layer:** an inventory-ONLY shopkeeper must bring stock in via the
   **direct-purchase** (no-PO) path; a full shopkeeper uses the **PO→GRN→invoice→payment** chain.
   Both must be complete + correct; every audit checks both.
2. **Verify backend AND frontend each layer** (not code/test only — the web purchase/suppliers/AP
   UI must support the hardened behaviour).

**Migrations:** push to **dev** tenant DB only; **prod auto-applies via the fixed Railway pre-deploy
migrator** on push to main (see [[project_migration_deploy_hardening]]). Run AUTONOMOUSLY end-to-end.

**Per-layer loop:** subagent writes study under `study/purchase/` → full audit (gaps) → harden
(think like a purchaser) → migrate dev → reviewers + real `node dist/main` boot DI gate → commit +
merge to main → next layer. No tech debt. Subagents must NOT spawn subagents
([[feedback_subagents_no_nested_spawn]]); write detail to /tmp/purchase-hardening/, return terse
summaries ([[feedback_delegate_subagents]]).

**Modular packaging note:** purchase is NOT a self-contained core — it sits ABOVE inventory +
accounting and depends DOWN into them; never depended on UP-ward. Verify the inventory program's F12
(reorder→purchase UP violation) here. Honor [[project_modular_packaging_vision]].

**Layers (locked, document-chain order):** 0 Supplier master + AP subledger foundation · 1 PO
lifecycle + direct-purchase intake · 2 GRN receipt + stock handoff + GR/IR accrual · 3 Purchase
invoice (3-way + 2-way match + input VAT + AP post) · 4 Landed cost + inventory revaluation · 5
Supplier payments + returns + AP aging/period integrity.

**Source of truth / resume point:** `study/purchase/_hardening-log.md` (layer status table +
principles + map). Progress: **Layer 0 COMPLETE** (main 33c7a688, migration 0124 — AP balance
derived from immutable party-tagged 2111 ledger, not SUM of invoice balances; per-currency +
functional-in-SQL; reconcile drift invariant; supplier default_currency/credit_limit/blocked
fields + transition guards; tax-number dup guard + normalization; supplier_item_codes FKs;
blast-radius helper moved inventory/items→graph; opening-bill CHECK; frontend hardened; 6-reviewer
panel, accounting validated AP derivation sound; dev migrated, boot DI gate passed, 45 tests).
**Layer 1 COMPLETE** (main 53b0de52, migration 0125 — direct purchase at governance parity with PO
path; reuses real GRN/bill/payment engine atomically (dual path verified first-class); client
exchangeRate dropped; pack-unit invariant; order events→transactional outbox; F12 reorder→purchase
boundary inverted to event (circular dep gone); SoD generic 422; frontend tax preview. 6-reviewer
panel 0 CRIT/0 HIGH; dev migrated, boot gate passed, 478 tests). **Layer 2 COMPLETE** (main e5635748, migrations 0126+0127 — GRN confirm re-validates PO under FOR
UPDATE; PO FX frozen onto GRN + functional-currency accrual/WAC; over-receipt backstop; NEW GRN
void/reversal (reverses stock+accrual net-zero, deletes confirm serials for re-receipt, 409 once
billed, locks grn_lines vs bill-match race); canVoid + void UI; PIN lockout→generic 422. Dual path
PASS, idempotency SOUND. 7-reviewer panel 0 CRIT, accounting CLEAN; 462 tests. GOTCHA: Drizzle
migrate() = ONE tx for all pending → cast status::text in CHECK to use a just-added enum value.)
**Layer 3 COMPLETE** (main 2fc7d4b8, migration 0128 — C1 CRITICAL reverse-charge bills fixed
(payable_total split); 3-way PPV price match (5210); expense/service bills; bill void/reversal
(read-only immutable contra); dup-guard normalized; FX fail-loud (full FX = follow-up). 7-reviewer
panel 0 CRIT, accounting 5 balance proofs balance; dev migrated + system-accounts re-seeded; 262
tests). **Layer 4 COMPLETE** (main 8cefc2ad, migration 0129 — CRITICAL double-GL-post fixed (inventory
listener = sold-portion COGS reclass only; JEs tie by construction); per-receipt FIFO COGS split
(itemId-scoped); WAC reversal clamp; durable outbox; NEW landed-cost reversal net-zero; FX fail-loud;
period-correct. 7-reviewer panel 0 CRIT, accounting balance proofs tie; dev migrated; 227 tests).
**Layer 5 COMPLETE** (main f63a230d, migration 0130 — 3 CRIT fixed: C1 payments persist balanceFn
(reconcile invariant); C2 returns decrement bill balance net-of-landed-cost + AP-value guard (no
over-pay/money-loss, GL==subledger); cheque JE posts (was DLQ'd). C3 payment reversal + return void
(net-zero contra, outbox-durable, frozen tax). H1 advance FX; H2 bill-sourced returns (dual path);
H3 AP aging buckets + reconcile endpoint. 7-reviewer panel: accounting proved reconcile holds after
every pay/return/reversal; 221 tests).

🏁 **PROGRAM COMPLETE (2026-06-30).** All 6 layers shipped to main (33c7a688 · 53b0de52 · e5635748 ·
2fc7d4b8 · 8cefc2ad · f63a230d), migrations 0124-0130 (dev applied; prod auto via Railway). Purchase
runs standalone + AP-true 10yr: dual path first-class; AP subledger-of-record reconciles after every
op; full reversal coverage (PO/GRN/bill/landed-cost/payment/return — no dead-ends); RC+VAT+PPV+GR-IR+
landed-cost GL-correct (accounting balance-proofed each layer); backend+frontend hardened. FOUNDER
TODO before go-live: verify a full purchase cycle on a real dev tenant; confirm prod provisioning
seeds new mappings (5210/2122). Biggest deferral: full FX (non-1 rate) is fail-loud module-wide.
Resume/detail: study/purchase/_hardening-log.md.

**FOUNDER DIRECTIVE 2026-06-30 (UPDATED):** finish ONLY purchase (Layers 3-5) in this session. Do
NOT continue into sales — founder will run sales hardening themselves. Same conflict warning stands
for ANY parallel module run in the SAME checkout: shared erp/ working tree auto-stashes concurrent
sessions (vanished-edits risk), shared migration journal/snapshot chain + sequential numbering,
shared main branch + dev-tenant DB. The framework + 4-verdict audit template here is the reference
for sales/reports hardening. Speedup pattern in use: pre-run the NEXT layer's read-only study+audit
in parallel while the current layer hardens (Layer 4 audit banked at
/tmp/purchase-hardening/layer-4-audit.md).
