---
name: project_import_pipeline_fixes_2026-06
description: "2026-06-10 import pipeline bug hunt — AI model ids, currency parsing, chunk recovery, matcher robustness, bucket + opening-balance design"
metadata: 
  node_type: memory
  type: project
  originSessionId: bbb862b3-1e5e-4b0a-a3ee-25acc1d09875
---

Overnight 2026-06-10 debugging of the data-import/onboarding flow (Al-Noor Mobiles / Yousef test tenant `zerupt_tenant_al_noor_mobiles_mq6hogbe`, Neon project `restless-hill-33464873`).

**Shipped — PR #148 (merged to main, `041ace7`):** AI router had stale LLM model ids. `column-mapper` route (used by `/ai/import/suggest-mappings` + `/ai/import/suggest-fixes`) pointed at retired `gemini-2.5-flash-lite-preview-06-17` (404) + un-deployed fireworks `deepseek-v3` (404) → all import AI auto-mapping/fix-suggestions silently failed. Fixed to `gemini/gemini-2.5-flash-lite` + `deepseek-v3p1`; same retired gemini was also `invoice-vlm` fallback. Added per-model provider-key skip + suggest_fixes degrade logging. Verify model ids against LiteLLM live registry (`model_prices_and_context_window_backup.json`).

**Open — PR #149 (tested green, awaiting morning merge):** three import bugs found via DB forensics (2,898 valid product rows applied only 1,500; `error_messages:["Failed chunks: 3,4,5"]`):
1. Currency-prefixed numerics (`"KD 11.172"` in Purchase Rate) passed validation then hit numeric `cost_price` → Postgres threw → one poison row rolled back its whole 500-row chunk transaction → 1,398 rows lost. Fix: `stripCurrencyTokens` at validation (CURRENCY_STRIPPED warning) + apply.
2. Chunk recovery: on batch-insert throw, recover row-by-row in FRESH per-row `db.transaction`s (NOT the aborted tx — Postgres aborts whole tx on first error; an earlier in-tx fallback was silently broken and only caught because the mock didn't simulate abort). Errors captured to `ApplyResult.errorMessages`.
3. Column matcher: `Payment Terms (Days)` was set aside (exact-alias-only). Added token-containment matching in resolver (≥2-token alias ⊆ header tokens → 0.9 auto) as a free deterministic fast-path only.
4. AI owns semantic column mapping (the real fix per founder: "we can't keep creating custom auto maps; AI should figure it out if the field exists"). Canonical field schema is now single source of truth: `entity-fields.ts` CanonicalField gained `label`+`description` for all 36 fields; `targetFieldsFor()` emits `{key,label,description,dataType,required}`; `ai-import.client.ts` sends `targetFields` to `/ai/import/suggest-mappings`; FastAPI `SuggestMappingsRequest.target_fields` (alias targetFields) builds a rich prompt (`paymentTermDays (Payment terms (days), number): Supplier credit period…`) and validates against sent keys, with hardcoded fallback so api/ai deploy order is irrelevant. Adding a field now auto-teaches the AI — no new alias ever. Architecture was already sound (rung5 fires for all unresolved cols, auto-applies at ≥0.92 `RUNG5_AUTO_THRESHOLD`); the only past failure was the dead models (#148). Fixed stale `confidence.ts` comment.

**Recovery for the lost 1,398 products:** after #149 deploys, re-import `02-products.csv` — existing 1,500 skip via ON CONFLICT, rest apply.

**Still TODO (investigated, not done):**
- Supabase bucket `import-files` does NOT exist → `ImportFileRetentionService` logs "Bucket not found" (non-fatal, original CSV not retained). Create manually in Supabase dashboard: name `import-files`, **private**, 25 MB (26214400), mime `text/csv` + xlsx/xls. API uses service-role key so no RLS policies needed. Code: `apps/api/src/supabase/supabase-storage.service.ts:71`.
- Opening balances: do NOT add `openingBalance` field to the CSV entity importer. Correct flow already exists — `OpeningPartyImportService` + `/tenant/import/opening-receivables` & `/opening-payables` (DTO: partyCode/partyName/invoiceNumber/invoiceDate/dueDate/amount), posts double-entry vs AR(1131)/AP(2111) control accounts, backed by `opening_balance_import_runs`. Customer/supplier master tables have NO opening_balance column by design. Yousef's lump per-party balances in `03-customers.csv`/`04-suppliers.csv` were dropped on import (no target field) — to load them, reshape into the opening-receivables/payables format (the test data has no per-invoice aging file = the AR/AP aging wedge gap).

Mira IS wired into the import column-mapping UI ("MI" avatar, first-person narration) — earlier "where's Mira" concern was unfounded; she also lives in `features/migration-matching` + `features/zee`.

Observability: AI service (Railway `zerupt-ai`) logs `llm_call task=.. model=.. success=True/False` per call; failures → Sentry `ZERUPT-AI-1`. Resolved mappings persist in tenant `import_learned_mappings.mapping`.
