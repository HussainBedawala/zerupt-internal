---
name: project_books_import_template
description: "Books import — Zerupt-generated TB+Customers+Suppliers workbook, deterministic parse (no AI on launch path); 2026-06-27 'form not data file' redesign SHIPPED to main (commit 4a578ab1)"
metadata: 
  node_type: memory
  type: project
  originSessionId: d28a2e1c-40aa-414d-9c9d-e478e88054c1
---

**2026-06-27 — "FORM NOT DATA FILE" REDESIGN SHIPPED (main, commit 4a578ab1; pushed → Railway+Vercel auto-deploy).**
Root cause of the dead-end: Apple Numbers (and other editors) DELETE the hidden `_zerupt_meta` sheet on
re-export, so the marker gate rejected filled files. Permanent fix = a single durable invariant: **the
workbook carries ONLY visible cell content; everything structural is derived from the LIVE tenant at import
time** (import is tenant-scoped, so the server already holds the COA/currency/decimals/languages/control
flags). This is a DELETION, not another redundancy layer — breaks the patch treadmill.
- REMOVED: hidden `_zerupt_meta` sheet, hidden anchor column (TB_ANCHOR_COL/writeTbAnchor/sentinel),
  on-sheet formulas (AR/AP auto-feed + balance-check), and the marker identity gate.
- NEW: sheets recognized by **header-row sniffing** in tenant languages (not sheet name/position; works with
  or without old hidden bits = backward compatible); rows matched by **visible Code then Name** against live
  COA; unknown non-blank Code OR blank-Code-ambiguous-Name → surfaced in preview, NEVER posted/auto-created
  (the permanent ambiguity rule). As-of date now a **UI date picker** sent as validated query param (not read
  from a cell). Numeric cells trusted directly; ambiguous TEXT amounts (e.g. "1,500") surfaced, never posted
  guessed. Uniform currency numFmt across all balance cells (fixed 12400.82→not-padded display bug).
- Context seam: controller builds `BooksParseContext` (BooksTemplateContextService.build + loadAccountInfos)
  and passes to `parseBooksWorkbook`; apply takes asOfDate+legalEntityId from request, not file.
- Built via parallel subagents (API opus / web sonnet), reviewed (accounting 0 crit/high + code review),
  all findings fixed. 13 jest suites / 93 tests, api+web+shared typecheck + i18n green.
- Design doc (the durable invariant + longevity audit): `erp/docs/books-import-redesign.md`.
- FOUNDER TODO: confirm the real-editor round-trip on PROD (fill template in Apple Numbers / Google Sheets /
  Excel, re-upload) — can't be driven headlessly; everything provable in code is proven.

2026-06-22: designing the launch books-import flow. Replaces the flaky AI file-comprehension
TB import with a **Zerupt-generated workbook** the customer fills + re-uploads. ONE workbook,
3 optional sheets: **Trial Balance** (pre-filled canonical COA, user adds leaf accounts +
balances under our groups), **Customers** (master + opening AR), **Suppliers** (master + opening AP).

**Core decisions (founder-locked):**
- COA canonical & ours; NO bring-your-own-COA. Human files leaves under our groups → deterministic
  placement, no AI guessing. AI path (`/ai/diagnose`, T0-T5 resolver) stays in repo but OFF launch
  path; re-enable post-launch (DEV-431). Files without our hidden `_zerupt_meta` marker = polite refuse.
- Workbook generated SERVER-SIDE per tenant: country COA overlay + tenant currency + primary/secondary
  languages from supported-languages registry (NEVER hardcode en/ar — [[feedback_language_agnostic_names]]).
- Universal posting rule: post every provided balance, sum Dr/Cr, plug diff to **OBE 3900**. Handles
  complete/partial/AR-AP-only/unbalanced uniformly. Controls: AR 1131, AP 2111, Inventory 1141 — LOCKED
  on TB sheet; AR/AP auto-fed from Customers/Suppliers sheets (cross-sheet sum) → no double-count.
- Customers/Suppliers = holistic master-data import + opening balance, REUSING existing
  buildCustomerInsert/buildSupplierInsert + per-party opening posting.
- Defense stack (assume dumb user — [[feedback_assume_dumb_customers]]): hidden anchors (parse by
  canonical code not visible text) · sheet-protection + dropdowns · defensive parser (leaf→parent by
  nearest preceding anchor) · orphan/sanity review dropdown (only "question", deterministic) · tie-out +
  preview-before-commit + free re-download. Balance-but-no-name = flag+hold, never drop.

**Scope v1:** TB+Customers+Suppliers. Inventory/opening-stock = NEXT flow (DEV-430; see
[[project_inventory_import_design]]). Deferred (Linear): DEV-431 BYO-TB AI, DEV-432 multi-currency party,
DEV-433 advance/prepayment reclass, DEV-434 party logos (SSRF), DEV-435 multi-address/contact.

**Design doc:** `erp/docs/tb-template-import-design.md` (detailed, founder verifying). **Linear:** DEV-428
(main, MVP project "The Working Retail Shop", team Development). Supersedes the unreliable
[[project_tb_import_zero_question_session]] AI flow on the launch path.

**DONE this session:**
- `supplier_addresses` child table (mirrors sales_customer_addresses) — migration 0110, schema+relations,
  branch `phase-2/supplier-addresses` commit 6518a037, typecheck green. Applied to ALL 4 dev test tenant
  DBs (zerupt_tenant_dev via drizzle; al_asala/gulf_hardware/layla via Neon MCP CREATE IF NOT EXISTS, verified 11 cols).
- Linear issues DEV-428..435 created.

**KEY INFRA FINDING (supersedes old topology notes):** Neon project `restless-hill-33464873`. Prod branch
`br-red-term-a1vs9ndl` has NO live tenant data DBs — only zerupt_admin. The 3 prod tenant_databases registry
rows (Gulf Hardware/Kutbee Shamalai/Hakimi cosmetic) point to DBs that DON'T EXIST (404 verified). Stale rows
can make Railway pre-deploy `migrate-tenants.cli` abort a deploy → ops issue **DEV-429** (clean rows + make
MigrateAllTenantsService skip missing DBs). All 4 per-tenant DBs live on DEV branch `br-old-recipe-a1d3dw26`.

**ARCHITECTURE LOCKED (Option 1 = ingestion layer, founder approved):** three separable layers —
**Ingestion** (server-side .xlsx BYTES upload, lossless, authoritative) → **Comprehension**
(deterministic marker-driven template parser now; AI pluggable later) → **Application** (existing
engines, unchanged). Mira UI calls it under the hood ("Mira's import" stays the face). The unified
Mira JSON pipeline (migration-session /plan /commit-unified) CANNOT carry the workbook — it takes
pre-parsed single-grid JSON, no bytes, no hidden sheets, AI-classified — which is exactly WHY we build
the bytes ingestion layer. Future templates = new parsers; AI re-enable = alt comprehension; old
tb-import/opening-import byte controllers absorbed over time. xlsx ONLY (reject csv: can't hold
multi-sheet/marker). Marker = hidden `_zerupt_meta` sheet + visible signature cell + structural
fingerprint; identify by "our format+version", NOT byte-checksum.

**FULL HANDOVER (build from this):** `erp/docs/tb-template-import-handover.md` — has the reuse manifest
(exact signatures+file:line), gotchas, build plan. Key gotchas: buildCellGrid reads sheet 0 only
(iterate worksheets); postGlOpeningBalances takes accountId UUID not code (resolve from live accounts);
TB sheet built from LIVE `accounts` table not buildCoaTemplate; bulk import writes NO addresses
(post-create step); tax-group column DROPPED v1; party master BEFORE party-openings; controls posted via
ob_ar/ob_ap (TB ob excludes 1131/2111). Build: contract file first (new module apps/api/src/books-import/)
→ fan out 4 sheet builders + ingestion/parser/gate agent → lead assembles workbook+meta+download endpoint
→ wire apply to engines.

**DONE this session (on main, uncommitted):** AI-diagnose deactivated (tb-diagnosis.client.ts
AI_DIAGNOSIS_ENABLED=false, code preserved, fallback intact; typecheck+tb-import.service 42/42+coa 15/15
green); cosmetic QA/KW Arabic VAT-label fix (coa-bilingual.ts NO_VAT_ARABIC_NAMES). GCC COA audit (opus):
AE/SA/BH/OM/QA/KW all PASS, zero critical/high/medium (VAT rate breakdown driven by tax-codes, single
GL output/input pair + RC import pair sufficient). NOTE: supplier_addresses landed on stray branch
phase-2/supplier-addresses (6518a037) — founder wants all on main, replay/carry forward.

**BACKEND BUILT 2026-06-22 (on main, uncommitted; typecheck + 24 jest tests green):** new module
`apps/api/src/books-import/`. (1) `books-template.contract.ts` + `.styles.ts` + shared catalog
`packages/shared/src/books-import-labels.ts` (en/ar, RTL, single source of truth for ALL workbook chrome
AND parse/apply warnings — full locale-awareness, founder-mandated). (2) 4 sheet builders
(`sheets/*`): TB pre-filled from LIVE accounts with hidden code anchors (col 20) + locked auto-fed AR/AP
control formulas + balance-check; Customers/Suppliers via shared `party-sheet.ts`; Instructions w/ signature.
Visible tab names LOCALIZED; parser resolves sheets via `meta.sheetNames`. (3) `books-template.generator.ts`
+ `books-template-context.service.ts` (reads live accounts, legalEntities currency/country, TenantSettings
languages, SystemRoleBindingService control codes, fiscalSettings for asOfDate). (4) Deterministic parser
(`books-workbook.parser.ts` + `parse/{identify,tb-parser,party-parser,cell}.ts`): marker-only identity
(REMOVED unsafe synthetic-meta fallback — stripped marker → "download fresh template"); magic-byte (PK) +
.csv reject; anchor-based leaf→parent; Dr/Cr normalize via decimal.js; duplicate-name aggregate (immutable);
balance-no-name held. (5) Apply orchestrator `books-import.apply.service.ts` + pure planner `apply/plan.ts`:
mint leaves (codes `parent.NN`, type/subType inherited) → TB GL opening JE EXCL 1131/2111 via
postGlOpeningBalances (OBE auto) → master+AR/AP openings via `ImportApplyService.apply` (opening ON) →
primary addresses (idempotent) → tbImportRuns status=applied. (6) Controller: GET template (download),
POST preview, POST apply (multipart).

**APPLY-PATH DECISION (founder delegated → "most stable/permanent"):** chose the single-`ImportApplyService`
path over the OpeningPartyImportService run-pipeline, because the latter's `upload()` parses its OWN file
(would require writing parsed data back to a file to re-parse). Money math = decimal.js everywhere.
`sourceControlTotals.tbTotal` = the POSTED journal's totalDebit (incl OBE) so the recon gate ties out.

**REVIEWS DONE (code+nestjs+accounting reviewers, all blocking findings fixed same session):** float→decimal.js;
@Res download returns reply (was void→hang); localized warnings; immutable aggregate; address idempotency +
warn-on-miss; unique jobId; asOfDate validation; magic-byte check. Also added `exports:[TenantSettingsService]`
to tenant-settings.module; registered BooksImportModule in app.module.

**STILL OUTSTANDING before go-live:** (a) REAL-tenant-DB integration verification of the apply path (mint+
postGlOpeningBalances+ImportApplyService against a DEV Neon tenant on `br-old-recipe-a1d3dw26`) — pure logic is
100% unit-tested but engine orchestration not yet run against Postgres; (b) frontend (download button + Mira
reject messaging); (c) go-live checklist: KWD `1,500` comma reads as 1500 (locale-free limit), OBE parking gate.
Uncommitted — commit with founder's other intentional working-tree deletions when instructed.

**RECON — what the new flow REPLACES vs KEEPS (onboarding + modules):**
- Onboarding today = 4-card "Mira" AI screen (books/products/customers/suppliers) via
  `/tenant/migration/sessions/:id/plan`+`/commit-unified`. Our workbook collapses 3 of 4 cards
  (books+customers+suppliers); products stays on Mira until inventory flow.
- REPLACE: web `features/tb-import/*` (12 files), api `tb-import/extraction/*` (10 files) +
  `tb-diagnosis.client.ts`, old `opening-import/opening-balance-import.controller/service` (retire after
  confirming no live runs), the AI classify call for trial-balance/opening-receivables/opening-payables in
  `unified-import-plan.service.ts`.
- KEEP/REUSE (engines + primitives): `OpeningPartyImportService` (AR/AP posting), `tb-import.service` apply
  logic (swap extraction only), `UnifiedOpeningApplyService` routing, `ImportHubStatusService`+`ControlBalanceService`
  (read tbImportRuns — new flow writes same table), go-live readiness schema, `CsvDropzone`, `FileDropSurface`,
  unified preview/outcome panels, `Step2CsvImport` (locations, unrelated).
