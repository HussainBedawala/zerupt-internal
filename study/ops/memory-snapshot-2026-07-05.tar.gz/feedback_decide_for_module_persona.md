---
name: feedback_decide_for_module_persona
description: "During testing/fixes, decide design tradeoffs yourself by the module's target persona — don't ask"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 365ddfcb-4739-44e5-b741-a583bd3ed566
---

When testing/hardening a module and a design decision comes up (e.g. should X be added/changed), do NOT stop to ask — make the call that is the right LONG-TERM fix for that module's target persona, then log the rationale.

**Why:** Founder wants momentum during dogfooding passes; he trusts persona-driven judgment over option-surveys.

**How to apply:** Identify the module's persona (Accounting → an accountant; Inventory → storekeeper; POS → cashier; etc.). Pick the choice that serves that persona's real workflow over the long term, even if it's more work than a quick patch. Record the decision + reasoning in the module's `_findings.md`. Example: COA toolbar "Add Account" created orphan roots → added an optional parent picker because an accountant expects to place an account in the hierarchy at creation. See [[feedback_assume_dumb_customers]] and [[feedback_defensive_ux]].
