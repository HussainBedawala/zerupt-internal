---
name: feedback_assume_dumb_customers
description: "Always assume customers are non-technical, will break things, and will give the worst review over one missing detail — design accordingly"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 16f7e82d-af8d-4381-b4b8-beff40deabb9
---

Always assume the customer is **dumb** (founder's word), non-technical, and will make mistakes constantly. They will throw garbage/messy/mislabeled files at the product, break things, and abandon the product + leave the worst possible review over a SINGLE missing field or one mistake.

**Why:** Zerupt's users are MENA/India/SEA retail shopkeepers, not tech-savvy. The product's survival depends on never punishing the user for their mess — the software must absorb chaos gracefully.

**How to apply:**
- Never build deterministic "only these columns are valid, everything else is thrown away" logic. Discarding data the user clearly cares about (e.g. an opening-balance column in a supplier file) is a failure, even if "technically" out of scope for that importer.
- The AI (Mira) must figure out what any given file is and route every meaningful column somewhere useful — being smart means tolerating and understanding mess, not rejecting it.
- Every feature: ask "what's the dumbest thing a user could do here?" and handle it with a friendly, non-alarming path. No dead-ends, no scary errors, no silent data loss.
- One missing detail or one confusing error can lose the customer forever. Treat each as launch-blocking.

Extends [[feedback_defensive_ux]]. Drives the ingestion-brain strategy in [[project_mira_ingestion_brain]] and [[project_ai_cost_routing_philosophy]].
