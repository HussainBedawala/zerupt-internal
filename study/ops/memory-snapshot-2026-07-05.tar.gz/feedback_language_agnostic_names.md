---
name: feedback_language_agnostic_names
description: Never hardcode English/Arabic for bilingual data; use tenant primary/secondary content-language pair driven by a supported-languages registry
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 49220ff3-42fd-4eea-9eb0-db84a73f4b88
---

Bilingual data fields (`name`/`nameAlt`, `description`/`descriptionAlt`, account `accountName`/`accountNameAlt`, scanner supplier names) are **language-agnostic**: `name`/primary and `nameAlt`/secondary, NOT English and Arabic. Two hard rules:

1. **Never pick which name to show based on UI locale.** Display is ALWAYS primary-first (`name`), secondary alongside (`nameAlt`) — independent of `useLocale()`. Helpers: `apps/web/src/lib/bilingual-name.ts` (`primaryText`/`secondaryText`) + `<BilingualName>` component. `locale === "ar"` is only acceptable for static UI chrome labels, number/date formatting (`ar-SA`), and RTL direction — never for entity names.
2. **Which languages a tenant uses is stored, not inferred.** `tenant_identity.primaryLanguage` + `secondaryLanguage` (nullable). Selected at onboarding (step 1) AND editable in Settings (company identity), from `contentLanguages()`. Labels come from `useBilingualLabels()` (endonym of the configured language), never the hardcoded word "Arabic".

**The coupling rule (founder mandate):** a language is offered as a *content language* only if its *UI locale* ships too — they are added together, never separately. Single source of truth: `packages/shared/src/languages.ts` (`SUPPORTED_LANGUAGES` with `hasLocale`). `routing.locales` and the content-language pickers both derive from it. Adding Thai = one registry entry (`hasLocale: true`) + one `messages/th/` folder; locale + content-language light up at once. A code without a shipped locale (e.g. Malay `ms`) stays `secondaryLanguage = null` until its locale ships — do NOT seed it as a default.

**Why:** the old code assumed `name`=English, `nameAlt`=Arabic and toggled on screen language, so a Korean/Thai shop's second name never showed. This broke the moment a customer's two languages weren't en/ar.

**How to apply:** any new bilingual field follows this pattern — store primary+alt, display primary-first via the helper, label via the registry endonym, gate selectable languages on `hasLocale`. Built on branch phase-3/pack-units-uom (DEV bilingual de-hardcode). Related: [[feedback_assume_dumb_customers]].
