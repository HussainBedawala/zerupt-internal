---
name: e2e-pom-infrastructure
description: "E2E page-object infrastructure (2026-06-06) — testid registry, page objects, fixtures; how to test any flow; env gotchas"
metadata: 
  node_type: memory
  type: project
  originSessionId: 06c0f154-99ff-4843-a626-aa77d81f1cd4
---

Built 2026-06-06 on branch `phase-0/e2e-pom-infrastructure` (commit 2843bf6, local — not pushed). Architecture guide: `erp/apps/web/e2e/README.md` (canonical, AI-friendly — read it before any E2E work; CLAUDE.md points to it).

- Testid registry `apps/web/src/lib/testids/` = component↔test contract; page objects in `e2e/pages/`; fixtures `e2e/support/test.ts`; fresh users minted per run via `e2e/support/supabase-admin.ts` (static fresh users rot — they're consumed by the journey).
- E2E env users fixed in `erp/.env`: primary + import user = `yousef.test+1780594447446@zerupt-e2e.com` / `YousefTest!2026` (live Kuwait tenant from journey run). Old `hussain@zerupt.com` etc. never existed in Supabase.
- Cheap suites (setup/smoke/auth/settings, 54 tests) green and stable ~1 min.

**Why:** any flow is now testable in a few lines of page-object calls; selectors solved once.

**How to apply / gotchas:**
- Local tenant DBs drift behind migrations (only migrated on deploy/provisioning) → API 500s on items etc. Fix: `pnpm --filter @zerupt/api migrate:tenants --apply` (permission-classifier blocks agents; user must run).
- `nest start --watch` restarts the API on ANY api/packages src edit → kills in-flight tenant provisioning. pg-boss zombie `active` jobs block the single worker slot until 10-min expiry; recovery is slow/unreliable (observed a job active 17+ min without completing, tenants stuck `pending_provisioning`). Never run fresh-tenant E2E journeys while another agent edits backend code; this also explains past "infinite Loading your setup..." findings. Provisioning resilience (resume-after-restart, dead-job sweep) is an open product gap worth a DEV issue.
- Fixed product bug: `signOut()` was global-scope (killed all devices' sessions); now `{ scope: "local" }` with TODO for admin forced-revocation path ([[defensive-ux]]).
- Lint trap: root lint-staged uses root eslint config (no react-hooks plugin) while apps/web config has react-hooks v6 — `eslint-disable react-hooks/set-state-in-effect` comments fail pre-commit with "rule not found". Fix the code, not the comment.

**2026-06-07 finish (commit 182de85 on main, pushed):**
- Full reset: ALL Supabase users + Neon tenant DBs (dev AND prod) wiped at user request. New primary E2E user in `erp/.env`: `e2e.primary+1780849366@zerupt-e2e.com` / `ZeruptE2e!Fresh2026`, owns live KW tenant `zerupt-e2e-co-mq3zsaaj` (provisioned through the real wizard). Dev branch keepers: that tenant DB + `zerupt_tenant_dev` + `zerupt_admin`.
- LAUNCH-BLOCKER found+fixed: 7 purchase enums (grn_status etc.) were drizzle-pushed to live DBs but never in migrations → every fresh-tenant provision failed at 0047. Fixed with guarded CREATE TYPE prepended to 0047. Rule now in /work + e2e/README: any schema change needs a fresh-DB `drizzle-kit migrate` against a scratch DB.
- New infra: `e2e/support/viewports.ts` + `locales.ts` (`pinLocale`), `e2e/responsive/responsive.spec.ts` (en/ar × desktop/tablet/mobile × 5 routes), `responsive` project. `workers: 1` + local `retries: 1` forced — parallel headed browsers starve the Next dev server (root cause of chronic setup/smoke flakes). "Agent quickstart" section at end of e2e/README.md = how agents run targeted suites.
- Suite tally 2026-06-07: 90 passed / 6 skipped; onboarding EN+AR failed only at fresh-user LOGIN (Supabase sign-in rate limit after dozens of logins in one session — cooldown, then rerun).
- Queue gotcha (extends nest-watch one): a second API instance that boots and dies (EADDRINUSE) STEALS the pg-boss job in its boot drain → orphaned `active`, signups spin on "stale queued job" until the 15-min sweep. Worker serial drain also wedges in-process on a hung step (no step timeout — open product gap). Recovery: kill all API instances, restart ONE from current build with `NODE_OPTIONS=--network-family-autoselection-attempt-timeout=2000`.
- Onboarding step 7 was redesigned (single "what are you moving from" radio, default "Nothing yet") + new import-choice screen before go-live; page objects updated shape-tolerantly; lifecycle spec now dispatches wizard steps from the selected tab position (resume-safe).
