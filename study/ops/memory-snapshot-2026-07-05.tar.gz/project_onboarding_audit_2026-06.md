---
name: onboarding-audit-2026-06
description: Onboarding wizard full audit + fixes merged to main (PR
metadata: 
  node_type: memory
  type: project
  originSessionId: 1d64d858-484a-44a9-a05d-8caef181ea93
---

Onboarding wizard fully audited (UX/security/consistency/i18n) and fixed; merged to main as PR #137 (commit b9874dd, 2026-06-04). Verified by live headed Playwright: two fresh tenants taken signup→provisioning→wizard→pipeline→go-live→dashboard in EN and AR.

Key durable facts:
- **E2E fresh-user pattern:** wizard is unreachable for live tenants (proxy redirects to dashboard). Fresh confirmed Supabase users are created via admin API (user authorized this); creds in `erp/.env` as `E2E_FRESH_USER_*` (EN, used) and `E2E_FRESH_AR_USER_*` (AR, used). Specs: `apps/web/e2e/onboarding/onboarding-audit{,-ar}.spec.ts`, project `onboarding`, skip when env unset. Provisioning takes 3–5 min on localhost (Neon ap-southeast-1).
- **Resume-integrity bugs class:** the live runs caught silent step-save loss on remount, stranded resume, and stale-validity disabled Continue — all fixed; hydrate now self-heals to first missing step. Watch for this class in other multi-step flows (import wizard).
- **Intentionally-unused wizard fields** (documented in onboarding.dto.ts, don't "fix"): step5 expectedUserCount (capacity analytics), step7 currentSystem(Name) (migration/competitor intel), step3 usePostDatedCheques (future PDC module).
- Test users live in shared Supabase Auth + Neon dev branch: hussain@zerupt.com (live), e2e-fresh-onboarding@, e2e-fresh-onboarding-ar@ (stuck mid-state, abandoned), e2e-fresh-onboarding-ar2@ (live, AR). Clean up before launch.
