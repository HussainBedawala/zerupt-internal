---
name: pos-hardening-2026-06
description: "DEV-389–395 POS hardening batch — ALL DONE, squash-merged to main 2026-06-06 (PR #142, 4b7c036)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 84481297-5272-4b28-ae64-7d17c9121ab0
---

# POS hardening batch (DEV-389–395) — COMPLETE

All seven issues built on one branch `phase-4a/DEV-389-395-pos-hardening`, squash-merged to main as `4b7c036` (PR #142) on 2026-06-06 during an autonomous overnight run. All Linear issues → Done with per-issue commit + review-summary comments.

- **DEV-394** offline-first POS: IndexedDB cart (Dexie per-register), idempotent sync ingest (clientId, advisory-locked numbering, 200-on-replay), catalog snapshot/delta API, sync engine (Web-Lock single engine, ordered drain, backoff), offline thermal receipts + post-sync reprint.
- **DEV-389** line editing: shared `NumericKeypad` (currency-decimal aware), tap-to-edit qty/price/discount; new `pos.transaction.price-override` permission enforced on all 3 write paths (PATCH price, addLine, sync ingest).
- **DEV-390** product images: `items.image_url`, Supabase upload w/ magic-byte validation (SVG-XSS blocked), POS tiles/search/inventory thumbnails, offline cache threading.
- **DEV-391** receipt settings page w/ live preview; printer enum +`a4`/`dot_matrix`; 58/80mm/A4 widths.
- **DEV-392** local print agent (decided: custom Node agent over QZ Tray): `apps/print-agent` ws 127.0.0.1:9723, CSWSH origin check, SSRF-restricted raw TCP 9100; web ESC/POS raster (browser shapes Arabic → 1bpp) + ESC/P renderers, drawer kick, agent→window.print fallback.
- **DEV-393** A4 bilingual tax invoice — render-only over pos_transactions, same transaction number, reuses sales `TaxDocument` (`suppressPrintStyle` prop); 80-col ESC/P continuous-form multi-copy invoice; receipt API enriched (tax rates/taxable amounts/customer block).
- **DEV-395** touch polish: 44px targets, visible search submit, scoped touch-action/select-none.

**Migrations 0036–0041** applied to dev tenant DB during the run; fleet apply via Railway pre-deploy on the merge deploy. ~80 review findings fixed in-session (4 CRITICAL: shift-number race, replay status code, addLine permission bypass, fractional-qty keypad). Spec addition appended to `agent-os/product/pos/07-receipt-model.md`; study notes `study/phase-4a/`; codemaps refreshed (`c36744b`).

**Merpec-parity workstream** (other agent, same branch, merged with it): back-office POS transactions list + return account-mapping fix (store-credit refund 2151→2153 symmetry). `pos.return.completed` mappings ready but no emitter yet (POS returns not built). Re-run account-mappings seed-defaults on existing tenants at deploy.

**Outstanding (manual, no Linear issues per founder instruction):** real-device tablet pass (Android Chrome + iPad Safari); E2E pos offline journey spec needs a seeded register/shift/catalog to run; confirm Railway pre-deploy migrated the fleet after this merge.

**How to apply:** future POS work must respect: agent print architecture, offline-safe numbering, cashier-allowed-but-gated price override, render-only document pattern (no parallel invoice model).
