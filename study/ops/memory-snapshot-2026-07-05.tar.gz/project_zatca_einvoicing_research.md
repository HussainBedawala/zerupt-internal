---
name: project_zatca_einvoicing_research
description: "ZATCA (Saudi e-invoicing/Fatoorah) deep research + Zerupt integration brief — scope, phases, technical specs, vendor/India regulatory position"
metadata: 
  node_type: memory
  type: project
  originSessionId: 600d56d0-ed2f-4003-b9ed-3579f9839c3e
---

Deep research on **Saudi Arabia ZATCA e-invoicing (Fatoorah)** completed 2026-06-10. Full brief: `agent-os/product/zerupt-specs/zatca-einvoicing/RESEARCH-ZATCA-2026-06-10.md`.

**Key verified facts:**
- Two phases: **Phase 1 "Generation"** (live 4 Dec 2021 — structured invoices + QR on B2C, no transmission). **Phase 2 "Integration"** (since 1 Jan 2023, waves — real-time API to Fatoora platform, CSID crypto stamp, XAdES signing, UBL 2.1 XML).
- **Wave 24 (1 Apr–30 Jun 2026): threshold SAR 375k** → nearly all SME retailers (Zerupt's market) now need **full Phase 2**, not just Phase 1.
- **Standard (B2B/B2G) → Clearance** (real-time, blocks delivery). **Simplified (B2C) → Reporting** (within 24h, non-blocking) — fits Zerupt POS + BullMQ.
- **No ZATCA vendor certification exists** — Solution Providers Directory is non-binding; compliance liability is the **taxpayer's**, not the software vendor's.
- **No nationality restriction** — Malakstar (India Pvt Ltd, see [[project_corporate_structure]]) can lawfully sell the SaaS to KSA taxpayers; **no KSA entity needed to be a vendor**. Taxpayer self-onboards per EGS device via OTP→CSR→CCSID→PCSID.

**Open / needs legal sign-off:** (1) data residency — must invoice XML live on KSA-physical servers? affects Vercel/Railway/Neon. (2) can a SaaS centralise CSID onboarding for tenants. (3) PCSID validity/renewal. (4) exact penalty schedule.

**Caveat:** ZATCA's official technical PDFs (XML Implementation Standard, QRCodeCreation.pdf, Detailed Technical Guideline, Security Standards, SDK) were NOT machine-fetchable — the deep technical layer (QR TLV tags 1–9, XAdES-EPES/SHA-256/secp256k1, API paths) is marked [TECH] in the brief and MUST be confirmed against those PDFs + ZATCA SDK before coding.

**Why:** Likely a post-MVP epic; Phase 1 (QR + generation) is MVP-sized and unblocks any KSA pilot, Phase 2 (API+CSID+signing) is a larger separate epic.
