---
name: pgboss-queue-architecture
description: DEV-388 — BullMQ/Upstash Redis replaced by pg-boss on Neon admin DB; zero-polling trigger-driven design; deploy steps pending
metadata: 
  node_type: memory
  type: project
  originSessionId: 2f837b77-0dd6-44e9-a728-2eec32e94148
---

DEV-388 (2026-06-04, PR #141): queue layer is **pg-boss v10 on the Neon admin DB** — BullMQ + Upstash Redis removed (Upstash 500k req/mo cap was hit by BullMQ idle polling, bricking signups).

Key invariants (do not regress):
- pg-boss runs with `supervise: false`, `schedule: false`, NO `work()` pollers — any periodic query ≤5 min keeps Neon compute awake 24/7 (~$19.35/mo at 0.25 CU). All periodic work lives in ONE 15-min sweeper tick (`ProvisioningWorkerService.sweep`): maintain() + outbox repair + stuck-job recovery + drain.
- `provisioning_jobs` is a transactional outbox: written atomically in the signup `db.batch()`; queue send is best-effort; job id = outbox row id; queue policy `singleton` per tenantId.
- neon-http `db.batch()` IS transactional (verified against @neondatabase/serverless types) — don't believe claims otherwise.
- pg-boss must stay on **v10 (CJS)** — v12+ is ESM-only and breaks the NestJS CJS build/Jest.
- `@upstash/redis` REST tenant connection cache is a SEPARATE concern and stays.
- Frontend provisioning timeout is 10 min because real provisioning takes ~5 min (CreateDB+RunMigrations on Neon).

Deploy steps still pending at time of writing: Railway env `DIRECT_URL_ADMIN` (add) + `REDIS_URL` (delete); admin migration 0006 (`packages/db-admin && npx drizzle-kit migrate`). Stuck Redis-outage signups self-heal on first sweeper tick after deploy.
