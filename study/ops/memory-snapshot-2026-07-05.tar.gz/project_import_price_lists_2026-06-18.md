---
name: project_import_price_lists_2026-06-18
description: "Import captures extra product price columns into price_lists; customer-group auto-assign still unbuilt"
metadata:
  node_type: memory
  type: project
  originSessionId: 48426466-e97c-4832-a256-d55fc518a713
---

2026-06-18 (pushed to main, commit 921e8a3f): product import now captures ANY extra price column (Wholesale/Retail/VIP/Trade/Special — AI-flagged via new `additionalPrice` field in entity-fields + prompts.py, NOT hardcoded). Because one file can have many extra-price columns and the 1:1 column→field mapping can't hold duplicates, they ride a SEPARATE `priceListColumns` channel (sourceColumn + derived listName), excluded from mapping/unresolvedColumns/missingRequired. On product apply, `PriceListImportService` (apps/api/src/migration/unified-import/price-list-import.service.ts) upserts one `price_lists` row per list name + one `price_list_items` per (list,item) at minQty 1, idempotent (ON CONFLICT DO NOTHING), best-effort (never aborts item import). Item join is case-insensitive `lower(btrim(sku))` — a raw sku compare silently no-ops on upper-cased SKUs (caught + fixed before commit).

**KNOWN GAP (intentional, not a bug):** price lists are captured but NOT auto-assigned to customer groups — no schema exists for customer→price_list association. So "wholesale customers automatically get wholesale price" is unbuilt. Founder accepted capture-now, auto-apply-later. Next step if revisited: add customer-group→price-list link + POS/Sales price resolution by customer.

Same session also shipped: import column-mapping display fix (prune AI-bound cols from unresolvedColumns, commit d07dfea1), fastify bodyLimit 25MiB for multi-file imports (e066755c), bounded per-file AI concurrency + review-UX mapped-summary/disabled-with-reason pickers (014d8d01). See [[project_ai_model_reliability_2026-06-18]] for the parallel Gemini resolver fixes.
