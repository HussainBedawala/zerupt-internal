---
name: project_auth_jwt_tenant_claim
description: How tenant_id (and onboarding state) get into the Supabase JWT — hook + updateUserById mechanics
metadata: 
  node_type: memory
  type: project
  originSessionId: 3742979c-91a7-4026-9e5b-d1a5d3d1af4a
---

The Supabase JWT's `app_metadata.tenant_id` is what drives the web `proxy.ts` guard chain and the API's JWT/tenant guards. Mechanics (verified 2026-06-03):

- A Postgres function `public.custom_access_token_hook(event)` runs on every token mint/refresh in the **Supabase** project (vvctlopwozfhqxlvcpky), NOT in the repo. It does `claims := event->'claims'` (preserving ALL existing `app_metadata`) and only `jsonb_set`s `tenant_id`, looked up from `public.user_tenant_map` (Supabase-side, `is_active=true`).
- That Supabase `user_tenant_map` is effectively **vestigial/empty** — the real mechanism is `SupabaseAdminService.setUserTenantMetadata()` (`updateUserById app_metadata:{tenant_id}`) called by `mark-ready.step.ts` at provisioning. The hook passes that stored value through. So any extra `app_metadata` key set via `updateUserById` **survives** token refresh.
- Practical consequence: to add a JWT claim (e.g. `onboarding_complete`), set it via `updateUserById` server-side, then have the frontend call `supabase.auth.refreshSession()` (pattern already in `setup-form.tsx:113`). The hook will not strip it. The hook cannot derive per-tenant facts like `wentLiveAt` (those live in the per-tenant Neon DB, unreachable from Supabase).

**Neon branches gotcha:** the API/Playwright run against the Neon **development** branch (`br-old-recipe-a1d3dw26`), while `run_sql` defaults to **production** (`br-red-term`). Always pass the dev branchId when inspecting admin/tenant data for local runs. See [[project_dev294_onboarding_wizard]].
