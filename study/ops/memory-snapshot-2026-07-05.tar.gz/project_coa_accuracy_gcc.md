---
name: project-coa-accuracy-gcc
description: "COA template accuracy overhaul for GCC MVP — what was fixed, decided, and deferred (2026-06-02)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 92e0de39-81d4-4501-a744-3f7a89cd6858
---

COA template accuracy work (2026-06-02). The accounting module is the spine — every module posts through it, so it must be 100% accurate. Ran 4 parallel accounting audits (GCC scope: AE/SA/BH/OM/QA), found 4 CRITICAL + 12 HIGH, fixed all via TDD, re-audited to **zero CRITICAL/HIGH**.

**Done (staged, NOT yet committed — all in `erp/` repo):**
- Arabic: 18 terms → SOCPA standard (مصاريف→مصروفات, المحتجزة→المبقاة, الاستهلاك→الإهلاك for depreciation, etc.)
- Cash-flow tags (IAS 7): 1210/1220/1230 + unrealized FX 4830/7220 → `none`; overdraft 2220 → current liability
- New accounts: IFRS 9 ECL pair `1133`/`6430`, income-tax pair `7800`/`2160` (UAE CT 9% live), deferred-warranty `2156`
- GCC VAT: reverse-charge import accounts `1162.10`/`2131.10`, "VAT" naming for AE/SA/BH/OM, Malay 1133 fixed
- Files: coa-base-template.ts, coa-industry-overlays.ts, coa-country-overlays.ts, coa-bilingual.ts, materialize-tax.ts + 4 new spec files. **337 tests pass, typecheck clean.**

**Key decisions:**
- **Qatar = dormant VAT accounts, NO gate surgery.** QA onboards `taxSystem: None`, charges no VAT; suppressing accounts would break the onboarding reconciliation gate for all 5 countries. Accounts present-but-unused is correct.
- **WAC-only category scoping** (both WAC+FIFO engines exist; this is a template-selection filter, not an engine limit). Locked 5 launch retail templates: hardware_building, auto_parts, general_merchandise (broad catch-all, UI mentions cosmetics/gifts/toys/pet), stationery_office, electronics_mobile. **Dropping** grocery/fashion/furniture/wholesale (FIFO/FEFO-native).

**Deferred → Linear:** DEV-361 (Cash Flow Statement report — no CFS exists yet, cashFlowCategory is currently metadata-only), DEV-360 (wire GCC reverse-charge routing in resolveCoaCodes + seed RC tax codes), DEV-362 (the category restructure itself: new IndustryTypes + frontend cards + auto-parts core-charge 2157).

See [[project_mvp_status]]. Pattern that worked: serialize edits to shared accounting files (conflict risk), parallelize only read-only audits/verification.
