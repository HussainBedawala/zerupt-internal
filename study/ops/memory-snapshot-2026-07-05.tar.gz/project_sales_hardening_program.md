---
name: project_sales_hardening_program
description: Overnight layer-by-layer audit + hardening of the sales module (mirror of purchase program); study + log in study/sales/
metadata: 
  node_type: memory
  type: project
  originSessionId: 1d91b183-dd4c-49f4-9678-5350588303ac
---

Started 2026-06-30. Founder mandate: accounting + inventory + purchase are perfected
([[project_purchase_hardening_program]]) — repeat the SAME process for the ENTIRE sales module so
a seller/shopkeeper can run selling for the next 10 years. Sales is the MIRROR of purchase:
customer/AR not supplier/AP, OUTPUT VAT not input, revenue + COGS-on-sale not inventory receipt,
money IN not OUT.

**Two founder requirements (same as purchase):**
1. **Dual path, first-class every layer:** inventory-ONLY shopkeeper sells via the DIRECT/EXPRESS
   SALE (POS-style, no SO); full shopkeeper uses SO → delivery → invoice → receipt. Both complete,
   both audited.
2. **Backend AND frontend each layer** (web sales/customers/AR UI must support hardened behaviour).

**Core invariant:** AR balance DERIVED from the immutable party-tagged receivables-control (1131)
ledger, NOT a SUM of invoice balances; per-currency, functional-in-SQL; reconcile must HOLD after
every invoice/receipt/return/reversal. Full reversal coverage, no dead-ends. validatePeriod before
every posting. Money = Decimal. Documents immutable.

**Migrations:** dev tenant DB; prod auto-applies via Railway pre-deploy ([[project_migration_deploy_hardening]]).
Next migration after 0130 = 0131. Subagents must NOT spawn subagents
([[feedback_subagents_no_nested_spawn]]); write detail to /tmp/sales-hardening/, return terse summaries.

**Layers (locked):** 0 Customer master + AR subledger · 1 SO lifecycle + direct/express sale ·
2 Delivery/fulfillment + stock relief + COGS · 3 Sales invoice + output VAT + AR post · 4 pricing/
promotions (scope-dependent) · 5 Receipts + returns/credit notes + AR aging + period integrity.

**Existing code:** apps/api/src/sales/{customers,direct,invoices,orders,overview,receipts,
credit-notes,receivable-writeoff}; schema sales.ts + sales-orders.ts; web features/sales/.

🏁 **PROGRAM COMPLETE (2026-06-30).** All 6 layers shipped to main: **96d1c32d** (L0 customer+AR,
mig 0131) · **86ee163f** (L1 SO+direct/express sale, no mig) · **b04b2508** (L2 stock relief+COGS,
no mig) · **acb8c13f** (L3 invoice void+output VAT, mig 0132) · **e8508148** (L5 receipts reversal+
returns+aging, mig 0133). Layer 4 (pricing/promotions) folded into 3 + deferred (no separate
commission layer existed; priceOverrideById now fail-loud). Migrations 0131-0133 (dev applied; prod
auto via Railway pre-deploy).

Sales runs standalone + AR-true 10yr: **dual path first-class** (direct/express POS-style sale reuses
the SAME atomic idempotent invoice+receipt engine as the SO chain; governance parity, no drift);
**AR subledger-of-record DERIVED from the immutable party-tagged 1131 GL** (CustomerArBalanceService)
with reconcile invariant that HOLDS after every invoice/receipt/return/reversal/void; total_fn/
balance_fn GENERATED columns (drift structurally impossible); **full reversal coverage, never a
dead-end** (SO cancel, invoice void = net-zero contra + stock/COGS reversal at engine-realized cost,
credit note, receipt reversal — all PIN+SoD+period+idempotent+outbox); revenue+output-VAT+COGS
GL-correct (accounting balance-proofed each layer; oversell rolls back before revenue posts; COGS
ties by construction); credit-limit hard-block (advisory-locked in-tx, no TOCTOU) via dedicated RBAC
perm sales.invoice.credit-limit-override with override-with-reason; backend+frontend hardened each
layer; modular boundary protected (sales depends DOWN only). **Account-mapping note:** sales void/
reversal resolve via in-code DEFAULT_ACCOUNT_MAPPINGS system-role accounts (verified on dev: confirmed
has 0 DB mapping rows, engine falls back to code defaults) — NO per-tenant seed needed (cleaner than
purchase's 5210/2122). Every layer ran a 5-7 reviewer panel; all CRIT/HIGH fixed same session.

**FOUNDER TODO before go-live:** run a full sales cycle on a real dev tenant; confirm the next Railway
deploy auto-migrates 0131-0133 on prod tenants. **Biggest deferral:** full multi-currency FX is
fail-loud module-wide (foreign sales rejected not mis-posted) — shared with purchase.
Resume/detail: study/sales/_hardening-log.md.

**LIVE TESTING PASS (started 2026-07-03).** Distinct from the code hardening above: persona-driven
dogfooding like purchase/pos. Persona = Al-Asala Auto Parts (Kuwait, KWD/no-VAT). Testing pack at
`agent-os/product/testing/sales/` (README + 9 submodule checklists + _findings.md), mirroring
`agent-os/product/testing/purchase/`. Log real defects to `_findings.md`. Mode: user drives the app,
I log + fix by severity. **Prereq shipped first (commit f8811639, main):** sales submodule nav parity
with purchase — surfaced the Direct Sale route (was built but unreachable in sidebar), renamed nav
keys (salesOrders/salesInvoices), built Payments Received (/sales/payments) + Credit Notes
(/sales/credit-notes) screens reusing existing invoices/customers data layer, added missing
credit-notes GET-list + sales.creditNote.list perm. No migration. **Caveat:** sales.creditNote.list
granted to sales-manager+Owner only; existing non-owner roles need a sync. Sales relieves stock+COGS
at INVOICE confirm (sales.invoice.confirmed) — NO separate delivery doc. Receivable-writeoff stays
API-only (no UI, owner-rare).
