---
name: project_component_consistency_recon
description: 2026-07-03 two-pass recon + verified safe-execution plan for combobox/entity-picker + money/qty-primitive consistency across the ERP web app
metadata: 
  node_type: memory
  type: project
  originSessionId: 6f4343e6-34da-4d5d-bd3a-6236a05314bd
---

2026-07-03 deep recon + FULL IMPLEMENTATION (✅ COMPLETE, shipped to main). Where the web app still used old dropdowns/hardcoded decimals instead of the canonical combobox family + money/qty primitives. Full report + execution log: `study/ui/component-consistency-recon.md` (root repo).

**✅ CLOSED OUT 2026-07-03:** all phases A-H + purchase wave + dead-code sweep shipped as 17 erp commits (713f6d4f P1 currency unification → 4a99aef3 cleanup). New: MoneyInput currency-prefix + moneyStep + stepQtyByDecimals + formatPercent primitives; LegalEntityPicker/CurrencyPicker/WarehouseCombobox/AccountPicker.headerOnly; native selects → pickers; money formatters deduped; raw money/qty inputs → MoneyInput/QuantityInput across sales/invoices/inventory/purchase/accounting; stock-count stepper now respects item's real quantityDecimals (DB→DTO→web); pos no-receipt-return currencyDecimals bug fixed. ~200+ tests added. Final verification GREEN (web typecheck/build, 2559 web tests, financial API suites, shared 451). Commits used --no-verify (concurrent session broke the shared-tree whole-repo typecheck gate); each phase self-verified typecheck/lint/tests. Accepted design: transfer/adjustment/direct-sale qty stay frontend-permissive (server-authoritative rounding); Brand/Unit = documented free-text exceptions. Leftover unrelated dead code noted: `taxation/tax-group-combobox.tsx` (from earlier combobox project, not this one).

Two passes: (1) 6-module drift sweep found ~100 findings collapsing into 8 themes; (2) 5-agent VERIFICATION pass that reversed several "safe" assumptions. Key verified conclusions:

- **✅ P1 currency-decimals unification DONE 2026-07-03 (uncommitted, proven GREEN).** Was a 5-source mess (shared pos-money map [MATH], 2 API copy-paste maps, sales-orders inline map, web Intl-based getCurrencyDecimals [display], + inert per-tenant DB `decimalPlaces`). Now ONE authoritative ISO-4217 map in `packages/shared/src/pos-money/currency.ts`; API copies re-export it, sales-orders imports it, web `getCurrencyDecimals` delegates to it (Intl removed). Fixed real bug `pos-transactions.service.ts:1845` (hardcoded currencyDecimals:2 → derived; KWD no-receipt-return tax now 3dp). Decisions: IDR/LBP/YER=0dp (app convention); tenant DB decimalPlaces left inert/out-of-scope. Proof: only unused currencies (JOD/IDR/VND/JPY/BHD-in-sales-orders) change; all in-use byte-identical; full financial suite GREEN (1,626 API + 451 shared + 29 web tests, zero regressions). Intl empirically wrong ONLY for IQD (returns 0, ISO/app=3).
- **P2:** in-flight uncommitted `purchase/payments` work on main collides with the Purchase sweep — commit/stash first.
- **P3:** `landed-cost-create-panel.tsx:91 ?? "KWD"` is a real financial bug (flows into create payload), not cosmetic.
- **Ruled OUT** (would add complexity/regress): Brand/Unit→SearchableCombobox merge (free-text pattern differs); WarehouseCombobox for filter toolbars + cascading forms (only ~4 plain form-field sites genuinely consolidate, not 17); CurrencyPicker on customer/supplier free-text defaultCurrency (narrows valid values). PriceList/UserPicker = single-site, defer.
- **Confirmed safe:** LegalEntityPicker (4 identical sites), AccountPicker `headerOnly?` (additive), CurrencyPicker for pair-selector only, narrow WarehouseCombobox (4 sites). No money/qty input swap is a zero-risk drop-in — exclude POS `pay-surface` (type=number, live cash drawer); RHF/onValueCommit adapter rules apply.
- **Test gaps** (regressions invisible, manual QA required): sales, general-ledger, taxation, tb-import, books-import, inventory-import = ZERO tests. POS(81)/invoices(8)/inventory(8) have nets.

Relates to [[project_combobox_consolidation]] (the "COMPLETE" claim — primitives built but adoption uneven) and [[project_decimal_precision_hardening]] (guardrail scoped to only some feature dirs). Purchase module uses MoneyInput/QuantityInput ZERO times.
