---
name: project-context-pruning
description: "Session-start context trimmed — skills, plugins, and global rules pruned to /work essentials (reversible)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8c06ccc1-0c89-4cf7-a608-7cd5273ed7c9
---

On 2026-05-30 the session-start context was pruned to keep only what the `/work`
(and `/website` + deploy handoff) flow needs. All moves are REVERSIBLE.

**gstack skills** (`~/.claude/skills/`): 41 of 54 moved to `~/.claude/skills-disabled/`.
Kept: office-hours, plan-eng-review, autoplan, review, codex, qa, land-and-deploy,
canary, context-save, context-restore, setup-deploy, browse, + engine (gstack, _gstack-command).
Removed: entire iOS suite, design/devex suites, benchmark, cso, careful/freeze/guard,
document-*, health/retro/learn/make-pdf, ship/skillify/scrape, etc.

**Project skills** (`/Zerupt/.claude/skills/`): 13 of 33 moved to `.claude/skills-disabled/`.
Removed: all stitch-*, python-patterns/testing, grand-slam-offer, nano-banana,
video-to-website, frontend-slides, excalidraw-diagram, security-scan.

**Plugins** (`~/.claude/settings.json`): disabled example-skills, frontend-design,
claude-md-management, claude-code-setup, **notion**. Kept context7, linear, github,
neon-postgres, supabase. (figma/vercel already off.)

**Global rules** (`~/.claude/rules/common/`): 7 of 9 moved to `~/.claude/rules-disabled/`
(git-workflow, testing, agents, performance, patterns, hooks, development-workflow —
duplicated by Zerupt CLAUDE.md / built-in behavior). KEPT coding-style + security.
Note: these load natively from `~/.claude/rules/` with NO @import in any config.

**KNOWN TRADE-OFF:** the 5 `stitch-*` skills are required by `/website` (Path A
Stitch-first design + Phase 10 Remotion video) but NOT by `/work`. They are
intentionally disabled — `/website`'s design-generation and video steps will fail
until restored. `/work` itself has ZERO broken deps (verified 2026-05-30).

**How to restore:** move folder back from `*-disabled/` → original, or flip plugin
boolean to true in `~/.claude/settings.json`. Changes take effect NEXT session.
The ECC session-summary hook was left intact (only ~1.7KB, useful continuity).
See [[project-ecc-hooks-decoupled]].
