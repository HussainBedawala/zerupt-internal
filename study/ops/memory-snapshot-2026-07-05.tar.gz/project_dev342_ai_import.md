---
name: project_dev342_ai_import
description: "DEV-342 AI import resolution ladder — first AI in codebase; layered build plan, hardening decisions, deferred model comparison"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5491cd2d-66e7-4e3c-a9db-5c7acc02c885
---

DEV-342 (`ai: import column resolution ladder + ai assist`) is the **first AI feature in the Zerupt codebase** — sets the pattern for all future AI. Branch `phase-5/dev-342-ai-import-resolution-ladder`. Milestone M5. Built as 4 layers, each its own full `/work` cycle (TDD→review→verify→commit) then `/strategic compact` before the next:

- **Layer A — deterministic resolver core** (`apps/api/src/import/resolver/`): entity-fields, en+ar alias dict (~40 fields, generic — NOT Merpec-hardcoded), content heuristics (barcode/email/currency/date + entity-type sniffer), ladder rungs 1→5 greedy stable assignment mirroring existing `coa-column-mapper.ts`. 100% coverage, golden-file tests.
- **Layer B — learned cache (rung 4)** + tenant migration `import_mappings` (sourceFingerprint, entityType, sourceSystem, mapping jsonb, dictionaryVersion). Order-independent header-set hash; pluggable source-system signatures.
- **Layer C — FastAPI rung-5 + fixes** (`apps/ai/app/`): plugin contract (name/description/invoke/health per tech-stack §6), LiteLLM routing, prompt caching, PII masking, schema-validated output, telemetry + budget alert, graceful empty-response fallback.
- **Layer D — integration**: `@nestjs/axios` client → `AI_SERVICE_URL`, timeout + empty-on-failure.

**Hardening decisions (user approved "harden it all"):** confidence bands as code constants — ≥0.90 auto-bound (still confirm-all + undo + audit), 0.75–0.90 pre-filled+flagged, <0.75 suggestion only; **rung-5/LLM output NEVER auto-applied** regardless of score. LLM proposes only; deterministic code validates against enumerated canonical field set; LLM never writes business tables (mirrors [[project_ai_cost_routing_philosophy]] + agents/01). Spec fixes folded into this PR: correct `03-ai-import-assistant.md` confidence bands, litellm version currency, fixes-are-deterministic-first.

**DEFERRED to end of issue (do NOT forget):** user wants a full model comparison — Gemini, OpenAI, Claude, DeepSeek, and all other available models — across cost / accuracy / scalability, using context7 MCP to fetch latest LLM API versions, to choose the best routing combination. Do NOT fixate on Anthropic-only. This happens after Layer C/D, at the very end.

Related: [[project_ai_cost_routing_philosophy]], [[project_dev292_onboarding]].
