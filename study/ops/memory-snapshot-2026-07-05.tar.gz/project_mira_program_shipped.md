---
name: project_mira_program_shipped
description: "2026-06-11 overnight — full Mira capability program shipped to origin/main (50→100% improvement), all green"
metadata: 
  node_type: memory
  type: project
  originSessionId: 16f7e82d-af8d-4381-b4b8-beff40deabb9
---

2026-06-11 (overnight, autonomous): shipped the full "make Mira 100% better" program to `origin/main`. Commits: `1e4759c` (db), `8a60a00` (ai-brain), `9906c5e` (api), `8b84aac` (web), `377fad9` (i18n namespace fix).

**What shipped (all on main, all verified green):**
- **Layer-1 cleaning brain wired** (`/ai/migration/clean`): footer/subtotal/pivot/pagination/locale-numeral detectors + **mojibake/windows-1256 Arabic text repair** + **trial-balance "off by X, line N" pinpoint**. (Was dead code before.)
- **Zero-config file-type detection** (confidence-gated "this looks like suppliers, not customers").
- **Value-signatures override mislabeled headers** (`heuristics.ts`): GCC civil-IDs, Indian PAN/Aadhaar, SKU-matches-catalog — advisory pill, never auto-rebind.
- **Deterministic fuzzy party-dedup** (`apps/ai/app/migration/party_resolver.py`, rapidfuzz, normalize+Arabic↔Latin transliterate, conservative 0.92) wired into `party_matcher.py` (pre-pass before LLM) + `consolidation.py` bucketing.
- **Layer-2 decision cards surfaced + resolvable end-to-end** + **controlTotals recompute** before the go-live gate (GET /sessions/:id, POST .../cards/:key/resolve, `decision-card-stack.tsx`). Was computed-then-discarded.
- **Cross-record anomaly safety-net** (`anomalies.py`): sells-below-cost, dup barcode across items, zero/neg cost/qty, both-sides party → advisory cards.
- **Session learning loop** (`import_learned_decisions` table, migration `0074`; `learned-decisions.service.ts`): records card resolutions/merges, pre-fills next import.
- **Opening-balance**: contacts→AR/AP hand-off (CTA + `sourceUploadId` receive), items-not-in-catalog create, sign/future-date guardrails, multi-branch opening stock (target-warehouse pinning).
- **Visible layer**: accumulating Transcript (before→after chips), Mira's Receipt, mapping reframe + "Remembered" pill (surfaces the learned-mapping flywheel), named-fixes, imbalance callout. **Resumable imports** + **one-drop multi-file fan-out**.
- **Voice layer**: ElevenLabs Sarah, opt-in toggle, milestone-scoped, AR/EN, cached server route `app/api/mira-voice/route.ts`. See [[project_mira_voice]].

**Verified:** api 278 suites/5218, web 1982, ai 352 pytest, ruff/mypy clean, i18n parity, drizzle 0073/0074 applied to dev tenant. Playwright import suite 6/6 — **caught + fixed a real 404** (`/inventory/opening-stock` had no parent route segment).

**Left UNCOMMITTED in working tree (NOT Mira — pre-existing or concurrent session; founder to handle):** `apps/api/src/{doc-numbering,inventory/items,provisioning/seed-config.step}`, `components/shell/main-nav`, `stores/ui-store`, `messages/*/nav.json`, and settings/accounting panels (bank-reconciliation, fiscal, accounts, journal-entries, etc.).

**Deferred (documented, not done):** onboarding E2E (20-40min fresh-tenant provisioning) not run; B3 "do it like last time" proactive re-import (needs real repeat-import data); pgvector/embeddings (rejected as premature — deterministic + fuzzy + learned layers already cover real export shapes).

Builds on [[project_mira_ingestion_brain]], driven by [[feedback_assume_dumb_customers]]. Orchestration tracker: `/Zerupt/tmp/mira-overnight-orchestration.md`.
