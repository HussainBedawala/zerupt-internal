---
name: project_inventory_hardening_program
description: Overnight layer-by-layer audit + hardening of the inventory module (repeat of the accounting program); study + log in study/inventory/
metadata: 
  node_type: memory
  type: project
  originSessionId: 490195f2-4a83-48f8-befb-aca366904338
---

Started 2026-06-27. Founder mandate: accounting is perfected ([[project_accounting_hardening_program]]
layers 0-5 done) — repeat the SAME process for the ENTIRE inventory module. Goal: a customer who
wants ONLY inventory (assume no other module exists) can run their stockroom single-handedly, exactly
as an accountant can run accounting standalone.

**Per-layer loop:** (1) subagent writes study material under `study/inventory/`, (2) full audit
identifying gaps, (3) harden (think like a stockkeeper/inventory manager), (4) apply migrations to
dev tenant DB + push to prod, (5) commit + merge to main, (6) next layer. No tech debt, no follow-ups.
Subagents must NOT spawn their own subagents; write detail to /tmp, return terse summaries. Run
AUTONOMOUSLY end-to-end (founder approved full autonomy 2026-06-27).

**Layers (locked, ledger-first mirroring accounting):** 0 Stock ledger foundation (the 10-year
dimensionality decision: item × location × lot/batch × serial × bin) · 1 Master data
(items/UOM/pack-units/locations) · 2 Movement engine + reservations/ATP · 3 Valuation & costing
(WAC, COGS, FIFO decision) + GL handoff · 4 Counts & period integrity · 5 Reporting.

**Key findings from initial map (2026-06-27, verify per layer):** stock ledger IS immutable
append-only; BUT ledger carries only item×warehouse×branch×legalEntity — NO lot/batch/serial/bin
dimension (the headline Layer-0 gap); cost_layers.batchId no FK (tech debt); batch/serial schema
built but enforcement deferred (trackingType='none' default); WAC only (FIFO dormant); no
reservation/ATP model; dependency direction clean (inventory→accounting via events/outbox only).

**Process gates:** real `node dist/main` boot is the DI gate (not metadata test only); reviewers
every layer; 100% coverage on valuation/COGS. Honor [[project_modular_packaging_vision]] (keep
inventory a clean self-contained core, deps point down to accounting). Builds on
[[feedback_delegate_subagents]] and [[feedback_subagents_no_nested_spawn]]. Also relevant:
[[project_pack_units_uom]], [[project_coa_accuracy_gcc]] (WAC 5-category scoping).

**Source of truth / resume point:** `study/inventory/_hardening-log.md` (layer status table +
principles + map). Progress: **Layers 0 + 1 DONE.** Layer 1 merged main 067e70d1 (migration 0112 — bin_id ledger
dimension closing the Layer-0 deferral; items immutability trigger locking unit/sku/trackingType/
valuationMethod once history exists; normalized barcode + batch identity; pack-unit default uniques;
serial disambiguation; transactional guards; extracted ItemBarcodes/ItemPackUnits services; 342
tests; dev-PG validated, real-boot DI gate passed). GO-LIVE RUNBOOK item recorded (0112 normalized
unique-index swaps need per-tenant dup pre-flight on populated tenants). Layer 2 split into sub-layers (founder ruling): **2a DONE** (merged main 6e518eb1, no migration —
MovementAttributionService + BatchPickerService FEFO, attribution real across POS/sales/purchase/
adjustments/transfers, silent fallback removed→fail-loud, FEFO replay idempotency via stable-ordinal
sub-eventIds + line short-circuit; 1872 tests; reviewers confirmed fan-out preserves COGS/GL).
**2b DONE** (merged main 36097aed, migration 0113 — stock_reservations + reserved_qty/ATP, reserve/
release/fulfill via existing level-row lock, wired to SO confirm/cancel + invoice-confirm fulfill;
real-PG 2-conn last-unit race proved no oversell). NEXT = **2c** (code-only, no migration: reversal
orchestrator gated on reverse() returning non-null id → routes adjustment void + transfer cancel-SENT;
DELETE the double-counting short-receipt shortfall row (F8b correctness bug); serial/batch retirement
on adjustment-decrease (F5); audit/plan at /tmp/inventory-hardening/layer-2c-audit.md). **2c DONE** (merged main 6c08cea4, no migration — InventoryReversalService orchestrator gated on
reverse() id; adjustment void + transfer cancelSent; short-receipt double-count fixed by deletion;
serial/batch retirement; reversal now contra-s ORIGINAL GL accounts → per-account net-zero; 1124 tests).
**LAYER 2 COMPLETE.** **LAYER 3 COMPLETE** (merged main b4dc47b5, no migration): WAC-only locked
(FIFO selectability removed), serial specific-cost relief (GL==subledger), landed-cost JE on outbox,
sale-return at original cost, costAtSale normalized per-unit, per-line cost keying. **Found+fixed a
pre-existing CRITICAL: live POS sales never relieved inventory/COGS** — now wired via a dedicated
`.inventory` domain event → fanOutSale, made crash-durable via a poller emitAsync re-fan-out
(also hardens sales+purchase). 2026 tests green. Carried the founder's HUSKY=0 Dockerfile hotfix to
main in the same push.
DEFERRED (founder decisions, in log): IAS 2 NRV write-down; serial POS-return physical relocation;
service file-size extractions. FOUNDER TODO: verify POS stock-relief end-to-end on a real dev tenant
before go-live (reviews were code/test-level only).
**LAYER 4 COMPLETE** (merged main e38f96fb, migration 0114 — stock_counts.count_date): counts post
set-to-counted vs LIVE on-hand under FOR UPDATE (F1, no mid-count drift); approvePost is ONE atomic tenant tx
with header row-lock + strict status guard + extracted StockAdjustmentsService.postAdjustmentInTx reused by
create() (F2, no partial/double post); count_date threaded to occurredAt+assertPeriodOpen (F3); reserved-
variance endpoint + daily @Cron recon sweep running both detectors per legal entity inside tenant ALS (F4);
+F5/F6/F7/G3. Reviewer panel caught + fixed 2 blockers: **C1 CRIT** (recon scheduler ran with NO tenant ALS
context → silent nightly failure; fixed via TenantDbResolverService + tenantStore.run per zatca worker) and
**HIGH** (zero-WAC found-increase rolled back the whole atomic count; fixed with fallback unitCost
items.costPrice→0+warn). Real-PG validated + boot DI gate passed; 97 suites/1940 tests green.
FOUNDER FOLLOW-UPS (surfaced, not bugs): **BatchExpirySchedulerService has the IDENTICAL C1 ALS flaw** —
batch-expiry alerts likely never fire (high-value standalone fix); F6 found-item-not-in-snapshot; F8 per-item
negative policy; add stock_counts.count_date index when Layer 5 predicates lock.
**LAYER 5 COMPLETE** (merged main 6b98fa34, migration 0115 — sle_legal_entity_occurred_at_idx): all 5 report
families now tie to the immutable ledger BY CONSTRUCTION. Valuation as-of + "now" value FROM the ledger
(Σ signed total_cost, qty=Σ ledger.quantity over occurredAt); cache used only to flag qty+value drift.
Movement ledger orders/date-filters by occurredAt (was createdAt) + seeded per-page running balance + SQL
sourceModule filter. Batch expiry gets an expired-not-written-off bucket + the BatchExpiryScheduler ALS bug
fixed (G4). NEW slow-moving/dead-stock aging report + NEW count-variance/shrinkage report. Reorder ATP-aware
(on_hand−reserved+in_transit) + SQL pagination. 5-reviewer panel found+fixed: SQLi in stock-aging (db
CRITICAL), now-valuation value-drift flag + F7 zero-WAC value (accounting HIGH×2), double-nested envelope (api
HIGH), single-scan aging (db H2). Real-PG validated + boot DI gate passed; broad sweep 119 suites/2372 tests.

🏁 **PROGRAM COMPLETE (2026-06-27).** All 6 layers (0,1,2a/2b/2c,3,4,5) shipped to main. Inventory now runs
standalone + ledger-true.

🏁 **PERSONA LIVE-TESTING PASS COMPLETE (2026-07-02).** Separate follow-up track: 16-submodule persona-driven
live-testing (storekeeper/owner personas) on real PROD tenant Al-Asala Auto Parts (Kuwait, KWD 3dp, no VAT,
150 items/8 cats/KWD 190,717.320). Submodules 01-16 all verified with founder screenshots + JE tie-outs.
Findings #1-#179 in `agent-os/product/testing/inventory/_findings.md`; checklists in
`agent-os/product/testing/inventory/NN-*.md`. **Final submodule 16 (Promotions)** signed off: built missing
target picker (promos were inert), verified discount GL (gross revenue + 4300 contra + cash, balanced),
server-side value/target/window guards, list shows target names + locale-aware (Intl.ListFormat), and fixed a
promotions-surfaced FNC-sentinel bug in the central JE auto-posting chokepoint (header stored "FNC" at 2dp →
resolves to tenant currency at correct precision; commit c6a82f8c). Promotion commits c21ce381/f9048399/c6a82f8c. **Founder follow-ups (NOT correctness gaps):** F12 reorder→purchase UP dependency
(only remaining packaging-boundary violation; event-ify PO creation); IAS 2 NRV write-down (Layer 3 deferral);
file-size extractions; movement-ledger keyset pagination; permission-naming consistency. **TOP FOUNDER TODO:**
verify live POS stock-relief end-to-end on a real dev tenant before go-live (Layer 3/4 reviews were
code/test-level only). Resume/detail: study/inventory/_hardening-log.md. **Layer 0** (merged main 310967be, migration 0111 — batch/serial
ledger dimensions, occurredAt, eventId full-unique idempotency, total_cost CHECK, DB immutability
trigger, quantity reconciliation detector; dev-PG validated, real-boot DI gate passed, 250 tests
green). NEXT = Layer 1 (master data: items/UOM/pack-units/locations; also adds nullable binId to
ledger since bins table already exists). Carried-forward items recorded in the log (batch/serial
attribution threading → Layer 2; serial specific-cost + FIFO occurredAt ordering → Layer 3).
