---
name: project_dev306_launch_hardening
description: "DEV-306 final pre-launch security hardening — done in code, ops runbook items pending before go-live"
metadata: 
  node_type: memory
  type: project
  originSessionId: 06ca47c3-e6ff-4112-8a9f-b35ddcbe9b4b
---

DEV-306 (production launch security gate) completed & merged to main 2026-06-10 — commits `b604379` (security hardening) + `bd7f711` (serial-tracking FE, landed an in-flight feature from another agent + fixed its silent import-mapping bug). Marked Done in Linear; full findings + ops runbook are in the DEV-306 Linear comment.

**Shipped (code):** next 16.1.6→16.2.7 (auth-bypass CVE), protobufjs override + posthog-js + vitest CVEs, web Sentry re-enabled, HSTS + global X-Frame-Options + **report-only** CSP, webhook SSRF guard (create+delivery), scanner double-post advisory lock, sql.raw→inArray, upload filename sanitization, signup 409 + admin migration `0011` UNIQUE(user_id), print-agent crypto temp names. Verified: API 5031 tests, Web 1843 tests, typecheck all green.

**PENDING before "live" (ops/dashboard — NOT code):**
- Apply admin migration `0011_freezing_tigra.sql` to `zerupt_admin` (NOT a tenant migration; pre-gate: no dup user_id rows).
- Set env: Railway `CORS_ORIGINS`, `SENTRY_DSN`, confirm `PLATFORM_ADMIN_USER_IDS`; Vercel `NEXT_PUBLIC_SENTRY_DSN` etc.
- Confirm Supabase `custom_access_token_hook`; confirm Railway prunes devDeps.
- Flip CSP report-only→enforce after watching violations.
- Original checklist still manual: domains DNS, Betterstack uptime, Neon PITR, load test.
- ~~Low-risk residuals~~ ALL CLOSED 2026-06-10 (commit `3bc6cb7`, pushed to main): print-agent SHA-256 + per-OS verify command now shown in download card; web `xlsx`/SheetJS replaced with `exceljs` (kills proto-pollution+ReDoS CVEs); scanner links draft bill to scan_job before confirm + self-healing resume (no orphan possible); webhook delivery pins validated IP via per-delivery undici dispatcher + redirect:manual (DNS-rebinding TOCTOU closed). 130 api tests + 10 web tests green, typecheck + i18n parity clean.

**DEFERRED until live customers (DEV-415):** Neon PITR window is only 6h (`history_retention_seconds: 21600`) on project Zerupt `restless-hill-33464873`. Bump to 7 days (604800s) once first real customer onboards — 6h too short for a financial ERP. Non-destructive setting; small storage cost. Resurface this when launch/customers come up.

**LAUNCH CHECKLIST STATUS (2026-06-10):** domains live (app+api.zerupt.com), Sentry on (PostHog intentionally off, DEV-229), CORS/rate-limit/headers done, admin migration 0011 applied to prod, load smoke-test passed (10 concurrent, 0 err), Betterstack uptime monitor live (api.zerupt.com/api/v1/health). Only open: PITR extension (DEV-415, deferred).

**Tenant isolation/auth audited CLEAN** (JWT-only tenant scoping, DB-backed RBAC, fail-closed guards, per-tenant DBs) — see [[project_auth_jwt_tenant_claim]].

**Process learning:** multiple agents on `main` concurrently caused a `git reset` that wiped uncommitted work mid-session (had to re-apply next.config/sentry/.env edits). When running parallel agents on a shared worktree, commit security work to protect it, and always stage explicit file lists (never `git add -A`) — the tree often holds other agents' in-flight files.
