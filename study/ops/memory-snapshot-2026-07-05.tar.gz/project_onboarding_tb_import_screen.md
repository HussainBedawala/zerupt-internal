---
name: project_onboarding_tb_import_screen
description: "Onboarding import screen rebuilt around single canonical TB import (worktree, unmerged)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 898168b5-c6f4-42e8-8a9a-058e61b1b73f
---

2026-06-14 overnight: rebuilt the onboarding import screen so the Trial Balance import is the single canonical books path, reusing the exact `<TbImportDialog>` from the Accounting → Trial Balance page (same AI-ladder pipeline). Built in a SEPARATE git worktree `/Users/hus3ain/Development/Zerupt/erp-onboarding-import` on branch `phase-5/onboarding-tb-import`, based on phase-3 committed tip (462bb5a) to avoid colliding with the inventory agent's uncommitted work in the primary `erp/` tree. Commits `474613e` + `6f361c6` (fail-loud trade-control fix). **MERGED into phase-3/pack-units-uom 2026-06-14 via no-ff merge `51fdd77`** (1 trivial conflict in review-summary.test.ts fixture — kept both primaryLanguage+secondaryLanguage). Inventory agent's pack-unit work (af60306 + ancestors) preserved; merged tree verified green: web+api typecheck, i18n parity, 604 affected api tests, 2080 web tests. Worktree erp-onboarding-import can be removed.

What changed (30 files, web+api green: typecheck/i18n/tests):
- New `TrialBalanceSection` (apps/web/.../components/import/trial-balance-section.tsx) wraps `<TbImportDialog>`; skippable → standard COA; as-of-date done state; "import instead"/re-import.
- Routed import/miraImport → sectioned `ImportScreen` (was the single-dropzone `MiraImportScreen`, now unrouted but kept compiling). Sections: Your books (TB headline) → catalogue & stock → customers & suppliers.
- Removed standalone `openingBalances` row (duplicate opening-balance posting path); TB now owns COA + opening balances.
- Removed the "import your own chart of accounts" path entirely: web schema/transform/review row/translations + api `coaSource` → `z.literal("standard").optional().default("standard")`, dropped imported-COA branch in materialize-coa.ts (standard path intact: seedTemplate + seedDefaultBindings + overrides).
- hub-status + go-live readiness now read committed `tb_import_runs` (status='applied') so a TB import satisfies `opening_balances` and surfaces its as-of date.

Key facts confirmed this session:
- Control accounts: AR=1131, AP=**2111**, Inventory=1141, OBE plug=3900. (Verified 2026-06-14 against `apps/api/src/accounts/data/coa-base-template.ts:553` — "2211" in an earlier note was WRONG; the standard GCC template and all opening-import/journal code use 2111.)
- `/complete` pipeline always seeds standard COA (coaSource always 'standard' now), so skip→standard COA needs no extra seeding and `accounts` readiness check won't block.
- `reconciliation.service.ts` is the go-live gate (AR/AP/inventory/TB tie-out).

Founder follow-ups flagged (NOT done — out of scope this pass):
- Orphaned backend endpoint `POST /coa/reconcile` (coaReconcileSchema + importedAccountSchema in onboarding.dto.ts:409) — dead plumbing from removed imported-COA path, NO web caller. Safe to delete its controller/service/module/tests as a separate task.
- ~~hardcoded AR/AP control-code fallbacks → Mira decision card~~ DONE 2026-06-14 (commit 6f361c6), but NOT as a decision card: removing custom-COA import means every tenant uses the standard template, so `trade_receivables`/`trade_payables` are always bound and `assertSystemRolesBound` already rejects unbound roles before the resolver runs — the fallback was dead. Fix = fail loud (throw ConflictException) instead of silently guessing 1131/2111. A decision card would be machinery for a scenario that can no longer occur.
- Post-TB import hierarchy to build next: TB → item master → opening stock (→reconcile 1141) → AR parties (→1131) → AP parties (→2211).

Worktree note: needs own `pnpm install` + env copied from primary tree; build packages (`pnpm turbo build --filter=./packages/*`) before api typecheck/jest resolve `@zerupt/db` etc. Rebase onto phase-3/main when inventory agent's branch lands (2-3 shared files: ui dialog/sheet, common.json).
