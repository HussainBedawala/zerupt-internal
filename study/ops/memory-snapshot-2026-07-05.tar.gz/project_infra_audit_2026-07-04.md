---
name: project-infra-audit-2026-07-04
description: "2026-07-04 infra/cost/security audit + same-day fix program — what shipped, what's pending on founder, P3 deep audit still to run"
metadata: 
  node_type: memory
  type: project
  originSessionId: 1c484aa6-6fe5-413d-ac38-5468b5176175
---

2026-07-04 four-track infra audit (Neon/Railway/Vercel+Sentry+Supabase/codebase) then full fix execution, shipped to erp main (d40a86c2..072321c2, report commit ce941ff in internal repo). Report: `study/ops/infra-audit-2026-07-04.md`.

**Shipped:** drizzle-orm 0.45.2 (SQLi GHSA-gpj5-g38j-94v9); Upstash fully removed (in-process tenant cache in tenant-context, in-memory auth rate limiter — was fail-open/dead since June 5); Neon pool `on('error')` + dead-pool self-heal (ZERUPT-API-7 was a missing error listener = process crash); AI import-classifier fallback chains provider-diverse gemini→cerebras→groq, 0 same-model retries, stale Fireworks rungs removed, fallback logs downgraded; web stale-chunk auto-reload, static robots/sitemap, bot-probe 404s in proxy.ts (matcher dot-exclusion replaced with extension list); Supabase public-bucket allowlist (tenant-assets only) + SVG blocked end-to-end + shared magic-byte helper + cacheControl 3600; Sentry env-gated off local dev + setUser({id})/tenant_id tag + refresh-token noise downgraded. Infra applied live: pg_stat_statements on all prod+dev DBs; zerupt-internal Railway watchPatterns scoped to /tools/zerupt-mcp/**; @zerupt/ai healthcheckPath /health set.

**ALL P0–P2 CLOSED 2026-07-04 (founder confirmed):** Neon suspend 300s set via API on prod+dev (verified); meilisearch deleted; Vercel Firewall rules added; Railway Upstash env vars deleted; Upstash account cancelled; Supabase bucket flags confirmed. Nothing pending except P3.

**Decisions:** API stays single-replica until live cashier traffic (in-memory tenant cache assumes this — revisit both together). Audit-log retention deliberately deferred. Pre-existing API jest failures on main (bins, purchase-returns, zatca-document, import-resolution, data-export-worker, ai-import.client, entity-fields, items.service) — verified failing on pristine HEAD worktree, not from this session.

**Next:** P3 deep audit (separate session, founder chose): tenant-isolation/auth security (Opus), performance-at-scale w/ EXPLAIN + pg_stat_statements evidence, POS resilience failure-mode matrix (deepest track), observability/recovery. Scope in the report's P3 section.
