---
name: drizzle-orm-migration
description: Migrating from Prisma to Drizzle ORM — decision rationale, milestone, and key patterns
type: project
---

Decided to migrate from Prisma ORM to Drizzle ORM on 2026-03-17 while in Phase 0/1 with 0 users.

**Why:** Drizzle is better for Zerupt's multi-tenant (database-per-tenant) architecture — lightweight instance creation, first-class pgvector support, no shadow DB needed, smaller bundle for serverless. Prisma's dynamic datasource issue #2443 has been open since 2021.

**How to apply:**
- Milestone "Migration to Drizzle ORM" under Phase 1 project, target 2026-03-24
- 4 issues: DEV-225 (schemas) → DEV-226 (connections) → DEV-227 (query consumers) → DEV-228 (cleanup)
- Neon driver strategy: `drizzle-orm/neon-http` for admin DB, `drizzle-orm/neon-serverless` for tenant DBs
- DI tokens: `TENANT_PRISMA` → `TENANT_DB`, `ADMIN_PRISMA` → `ADMIN_DB`
- Schema files: TypeScript in `packages/db/src/schema/` and `packages/db-admin/src/schema/` (one file per domain)
- No `prisma generate` step — Drizzle infers types directly from schema
- Keep Prisma migration SQL files as read-only archive
