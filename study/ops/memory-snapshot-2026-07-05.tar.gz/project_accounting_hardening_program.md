---
name: project_accounting_hardening_program
description: Overnight layer-by-layer audit + hardening of the accounting module; study material + progress log in study/accounting/
metadata: 
  node_type: memory
  type: project
  originSessionId: 0993861d-4b71-4019-97f7-fc1176cb2154
---

Started 2026-06-20 night (founder asleep, autonomous). Mandate: perfect the accounting module
top-down, **layer by layer**, so it's 100% concrete and stable for 10 years and never revisited.

**Per-layer loop:** (1) subagent writes study material under `study/accounting/`, (2) full audit
identifying gaps (like Layer 0), (3) harden the layer (think like an accountant), (4) apply all
required migrations to dev tenant DB + push to prod (founder granted migration permission), (5)
commit + merge to main, (6) next layer. SKIP templates (founder does in morning). No tech debt,
no follow-ups. Subagents must NOT spawn their own subagents. Preserve context: subagents write
detail to `/tmp/accounting-hardening/`, return terse summaries.

**Layers:** 0 Ledger foundation · 1 Chart of Accounts · 2 Posting engine · 3 Sub-ledgers &
valuation · 4 Period & balance integrity · 5 Reporting.

**Source of truth / resume point:** `study/accounting/_hardening-log.md` (per-layer status table +
open items + guiding principles). Study chapters: `study/accounting/layer-0-ledger-foundation/`
(ch 00-09 done). Layer 0 branch: `phase-2/layer-0-ledger-hardening`.

Honor [[project_modular_packaging_vision]] (accounting must stay a clean self-contained core,
deps point down to it). Builds on [[feedback_delegate_subagents]] and
[[feedback_subagents_no_nested_spawn]].
