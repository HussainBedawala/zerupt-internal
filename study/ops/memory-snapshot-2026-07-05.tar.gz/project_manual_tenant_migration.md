---
name: project_manual_tenant_migration
description: How to manually apply Drizzle tenant migrations to dev + prod Neon DBs without relying on Railway
metadata: 
  node_type: memory
  type: project
  originSessionId: 0e522ec5-83af-438d-b766-ce909c2022f6
---

Manually applying pending tenant migrations (the right way, keeps `drizzle.__drizzle_migrations` tracking consistent so Railway pre-deploy never re-runs/conflicts). Used 2026-06-12 to ship 0081–0083.

**Topology** (see [[project_neon_db_topology]]): one Neon project `restless-hill-33464873`. Branches: prod=`br-red-term-a1vs9ndl`, dev=`br-old-recipe-a1d3dw26`. Admin DB `zerupt_admin` per branch holds `tenant_databases` registry (col `db_name`). Tables owned by `neondb_owner` (has DDL rights). Repo `erp/.env` is the DEV env.

**Migrator**: `apps/api/src/migration/migrate-all-tenants.service.ts` → `node dist/migration/migrate-tenants.cli --apply`. Reads tenants from `ADMIN_DB` (`DATABASE_ADMIN_URL`); per tenant builds connection from `POSTGRES_SUPERUSER_URL` swapping the db-name path; runs drizzle `migrate()` on `packages/db/drizzle`. Idempotent. `migrate-admin.cli` migrates the admin DB.

**Recipe**:
1. `pnpm --filter @zerupt/api build`
2. DEV: from `apps/api`, `node dist/migration/migrate-admin.cli` then `node dist/migration/migrate-tenants.cli --apply` (uses local dev `.env`). Also dev base DB: `cd packages/db && npx drizzle-kit migrate` (DATABASE_TENANT_URL=zerupt_tenant_dev).
3. PROD: prefix both CLIs with inline `DATABASE_ADMIN_URL=<prod> POSTGRES_SUPERUSER_URL=<prod>` where prod = `postgresql://neondb_owner:<pw>@ep-patient-surf-a1adanmx-pooler.ap-southeast-1.aws.neon.tech/zerupt_admin?sslmode=require` (get fresh creds via Neon MCP `get_connection_string` on br-red-term; rotate if leaked).
4. VERIFY from actual DB via Neon MCP `run_sql`: `SELECT count(*) FROM drizzle.__drizzle_migrations` + `information_schema.columns` checks per tenant. NEVER trust the CLI output alone.

**New tenants** are covered automatically by provisioning (`run-migrations.step.ts`, same migrations folder) — no manual step needed.

Gotcha: `document_type` enum values are lowercase (`jrn` not `JRN`) — cast to text in verification SQL.
