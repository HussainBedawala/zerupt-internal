---
name: feedback_delegate_test_fixing
description: Delegate test writing/fixing to subagents; founder wants main loop on functionality
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9ff8ead1-3aa4-4fe6-8c12-619f0bd94bd8
---

The founder's directive: my main job is to write functionality, not to write tests or
reconcile old tests to new behavior. Delegate repetitive, non-productive test-fixing
(updating mocks, matching old specs to new functionality, fixing assertions) to a
subagent (sonnet/haiku per complexity) so the main loop stays on design + implementation.

**Why:** Repetitive test plumbing burns founder-facing momentum and main-context budget.
**How to apply:** After I change functionality, hand the "make the spec mocks/assertions
match" work to a subagent. Keep writing the real code myself. See [[feedback_delegate_subagents]].
