---
name: project_resolver_engine_tb_import
description: "Resolver engine + unified trial-balance import — built 2026-06-13, PR"
metadata: 
  node_type: memory
  type: project
  originSessionId: 65d831aa-ac13-46ac-ace2-977437f77db7
---

2026-06-13 overnight: built the new **resolver engine** (replaces the old "5-rung ladder") + the **unified trial-balance import** flow. Branch `phase-2/resolver-engine-tb-import`, **PR #152** (zerupt-erp) — NOT merged (main auto-deploys to prod; needs founder review + ops steps).

**Architecture decided with founder (the model to keep):**
- COA is canonical & fixed (our codes/structure); customer's trial balance is the ONLY account input — no standalone COA import. We keep the client's **ledgers** as leaves (their names, our derived codes under the resolved group) and map each ledger → our canonical **group** (the CA "regrouping" model). Display-alias their term on 1:1 matches.
- Engine tiers: T0 normalize → T1 exact → T2 memory (global+tenant `resolution_memory`, admin DB, pgvector) → T3 semantic (embeddings, hosted `text-embedding-3-small` default; local bge-m3 opt-in) → T4 batched LLM reasoner (`/ai/resolve`, DeepSeek for coa) → T5 decision card. **LLM cost scales with distinct unresolved concepts, not rows.** Deterministic tiers FEED the reasoner (not gate it).
- TB yields 5 tiers: GL accounts+opening balances, AR/AP subledgers, cross-module recon hooks (inventory→1141, bank, FX), equity plug (OBE 3900 = numeric plug; suspense = classification plug, kept separate), dimensions. + abnormal-balance reclassification (overdraft/advances/drawings).

**Verified on real dev DB + real LLM:** imported `~/Downloads/Location Wise TB (1).xlsx` → AR control 1131=98.00 (was wrongly dumped to OBE pre-fix), balanced journal OB-0001 10,025.83. ~1,200 tests green.

**7-agent audit caught the big bug:** AR/AP were dumped into Opening Balance Equity instead of the control — fixed. Security review PASS.

**Founder TODO before merge:** (1) confirm prod admin DB can `CREATE EXTENSION vector`; (2) full browser/Playwright E2E (blocked by Supabase auth wall — service+real-DB E2E passed); (3) embeddings local-vs-hosted decision; (4) confidence calibration (real LLM ~0.77 → review band).

**Next milestone:** migrate product/customer/supplier/category imports onto the new engine. Per-party AR/AP identity via existing opening-party import. See [[project_import_pipeline_taxonomy]] (READ FIRST — authoritative live-vs-dead map), [[project_import_pipeline_fixes_2026-06]], [[project_mira_program_shipped]], [[project_onboarding_import_audit_2026-06-12]].

> CORRECTION (2026-06-15): earlier wording here implied the rung/ladder (`ImportResolutionService`) is "old" and should be deleted. That is WRONG and was confusing agents. The rung ladder (entity imports) and this T0–T5 resolver engine (TB) are BOTH the CURRENT live engines. The genuinely-dead thing is the old "Pipeline A" consolidate→graph→nodes flow. See [[project_import_pipeline_taxonomy]].
