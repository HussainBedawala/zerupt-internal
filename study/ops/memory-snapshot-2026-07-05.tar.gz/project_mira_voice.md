---
name: project_mira_voice
description: "Mira gets an opt-in, milestone-scoped, localized VOICE layer (ElevenLabs) — genuinely-helpful version, not chatty narration"
metadata: 
  node_type: memory
  type: project
  originSessionId: 16f7e82d-af8d-4381-b4b8-beff40deabb9
---

Decision (founder, 2026-06-10): build a VOICE layer for Mira on the import/onboarding flow. Founder heard a real ElevenLabs sample (EN + AR) and approved.

**Why it's genuine value, not gimmick:** a meaningful slice of MENA/India/SEA shopkeepers are low-literacy / non-technical; a calm spoken Arabic/Hindi guide during the scary data-migration moment is real accessibility + trust, and reinforces "Mira is a person on your team" / "not a random ERP." See [[feedback_assume_dumb_customers]].

**The helpful version (NOT the over-engineered one the audit rejected):**
- **Opt-in toggle**, remembered ("Mira can talk you through this"); honors mute + prefers-reduced-motion; never autoplays without the toggle (also satisfies browser gesture requirement).
- **Milestone beats only** (~5-6 spoken moments: welcome, "I found your file", cleaning wins, the imbalance callout, the Receipt) — NOT every transcript line. Text transcript stays the detail layer; voice carries the emotional arc.
- **Localized + cached:** Arabic + English at launch (match app locales). Fixed lines pre-generated as static audio assets; only dynamic numbers go through live TTS, cached by hash. Cost accrues only when toggle is on.
- Avoid: typewriter narration of every line, raw % read-out, sound/confetti (these were the rejected gimmick version).

**Tech:** ElevenLabs. Chosen voice = "Sarah - Mature, Reassuring, Confident" (id `EXAVITQu4vr4xnSDxMaL`), model `eleven_multilingual_v2`. Tuned settings (founder-approved direction): stability ~0.6 (calm, low randomness), similarity_boost ~0.8, style 0, speed ~0.9 (slightly slow = reassuring), speaker_boost on. Pacing via punctuation — em-dashes + ellipses for breath; short sentences. Prod needs an ElevenLabs API key + a small voice service (utterance → cached audio by locale+hash). Dev/prototype via ElevenLabs MCP.

Part of the Mira "Visible" layer — see [[project_mira_ingestion_brain]]. Pairs with the Transcript + Mira's Receipt UI.
