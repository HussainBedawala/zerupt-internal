---
name: project_pos_hardening_program
description: Layer-by-layer audit + hardening of the POS module (5th hardening program); study + log in study/pos/
metadata: 
  node_type: memory
  type: project
  originSessionId: 2b2e66e6-0090-4ea7-b7da-3c73049c2673
---

Started 2026-06-30. Founder mandate: accounting + inventory + purchase + sales are perfected
([[project_sales_hardening_program]]) — repeat the SAME process for the ENTIRE POS module. POS is
the most undertested module AND must level up from MVP to a **proper POS** (UX overhaul + features).

**POS is different:** it is an event-emitting front end, NOT a ledger. A sale persists to
pos_transactions/lines/payments → emits pos.transaction.completed → accounting listener writes the
balanced JE (DR Cash/Bank→CR Sales; DR COGS→CR Inventory) + inventory writes stock relief. POS never
writes journals/stock directly. Load-bearing invariants: (1) three-way tie-out POS↔GL↔stock per
sale/return/void/close; (2) offline clientId replay = exactly once; (3) denomination blind-close cash
recon; (4) print/sync never blocks a sale. Backend already MORE mature than sales/purchase were
(server recompute per mutation, advisory-lock idempotency, outbox at-least-once GL, partial unique
indexes). Gaps are correctness holes + UX + missing features.

**Locked decisions (2026-06-30):**
- Scope = must-have + STRONG features (competitive parity: loyalty, customer display, scale,
  prayer/break, reporting); AI differentiators (shrinkage/anomaly, upsell, reorder-at-till, Mira
  brief, NL reporting) DEFERRED post-program.
- Execution = AUTONOMOUS end-to-end, no mid-program check-ins.
- **Layout = phase-aware "C":** BUILD (catalog + full-width cart) ↔ inline SETTLE (cart expands into
  pay surface: split-tender + quick-cash denom + dwelling CHANGE DUE). NO payment modal. Remove the
  draggable cart/catalog splitter (fixed ratio per breakpoint). Cross-cutting adds: scan-anywhere
  capture, price-check/no-sale mode, weight/qty entry, named holds, scan-receipt-QR return.

**Top correctness gaps found (survey 2026-06-30):** cash-movement approvedById nullable + no guard
(CRIT); split-tender exists in schema/server but UI sends only one tender (CRIT); no order discount +
no discount-approval gate (HIGH); no grandTotal DB CHECK; changeGiven>0 allowed on card; costAtSale=0
silent; pos_receipts row created on first reprint not first print (false-negative completeness);
Z-report expectedCash may not exclude voided cash payments; gift_card/store_credit tenders have no
backing balance table (MVP stub).

**Layers:** 0 register/shift+cash integrity · 1 tx lifecycle+tie-out · 2 payments/tender+layout ·
3 discounts/promotions · 4 returns/exchanges · 5 offline sync · 6 receipts/printing/WhatsApp/ZATCA ·
7 reporting/close + strong features. Migrations dev-applied, prod auto via Railway. Next mig = 0134.

🏁 **PROGRAM COMPLETE (2026-06-30).** All 8 layers + quick-create shipped to main: d7bb7af7 (L0 mig0134)·
4b2b7c92 (L1 0135)· ef653901 (L2/L3/L4-BE/L7-reporting-BE/quick-create 0136-0138)· 2e5d6251 (L4-FE+L5 0139)·
97d5868d (prod hotfix + L6 receipts)· 383d23de (migration deploy-blocker incident)· e771087d (L7-FE).
Highlights: three-way tie-out per sale/return/void/no-receipt; offline idempotency (tx/shift/movement
clientId)+stale-price block+queues; denom blind-close+X-report+cash-to-safe; phase-aware BUILD↔SETTLE
inline split-tender/quick-cash/dwelling-change; order+line discount with signed-token approval (no PIN
at rest)+pre-tax VAT allocation; WhatsApp/gift/Arabic receipts; reporting screens+prayer-mode+customer-
display+weighing-scale. Reviewer panel per layer; all CRIT/HIGH/MED fixed. Resume/detail: study/pos/_hardening-log.md.
**Prod incident learned:** batch 1 journaled 0136 but didn't stage 0136.sql → Railway migrator aborted;
fixed in 383d23de + a journal-integrity CI guard now enforces every journal tag has a committed .sql.
**Deferred:** ZATCA QR POS wiring (post zatca-worktree-merge, KSA flag); loyalty+customers module
(needs customers table + loyalty-liability GL + accounting sign-off); seed a Manager role with the
pos.*.approve perms (fresh tenants seed only Owner). L7 shipped without the formal reviewer panel
(founder "commit everything") — typecheck+test green, un-dogfooded.

Subagents must NOT spawn subagents ([[feedback_subagents_no_nested_spawn]]); detail → /tmp/pos-hardening/.
Resume/detail: study/pos/_hardening-log.md. Competitive research + code survey synthesized into the plan.
