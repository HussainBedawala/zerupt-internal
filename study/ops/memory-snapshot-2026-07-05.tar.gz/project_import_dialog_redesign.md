---
name: import-dialog-redesign
description: "2026-06-07 import/onboarding UX overhaul — stacked dialog, AI-first mapping, placement merge; commit 99e909e on phase-5/import-dialog-ux"
metadata: 
  node_type: memory
  type: project
  originSessionId: d69a39b9-282a-475e-a0d5-40c4702de46b
---

2026-06-07: Full import UX redesign after founder's bad onboarding test. Commit `99e909e` on `phase-5/import-dialog-ux` (NOT yet PR'd — branch is behind main post-PR #143 and the tree still carries another agent's uncommitted approval-pin/purchase-followup WIP; rebase before PR).

Decisions locked:
- Import yes/no questions REMOVED from onboarding Step 7 (kept current-system only; dto booleans optional default false). Question + action now live together on the post-pipeline import screen: yes → "Start import" animates in → stacked dialog opens.
- New primitive `apps/web/src/components/ui/stacked-dialog.tsx` (stacked-cards effect, manual focus trap + inert behind-cards, modal={false} Radix root). Founder loves this 21st.dev-style effect — reuse for future multi-step flows.
- ImportDialog 5 steps: upload → real-CSV preview in window frame → AI-first mapping (auto-mapped confirm list + attention cards w/ sample values) → check (success hero if clean; grouped issues only, never empty rows) → apply.
- Deep link `?import=<type>&job=<id>` on /onboarding + standalone pages; refresh resumes (resume auto re-validates — validate is idempotent).
- Duplicate NAME = warning only (customers/suppliers); duplicate CODE = error (new check). Founder rule: identity = code/SKU, never name.
- "Opening Balances" renamed "Trial Balance (Opening Balances)" in UI — file format IS account/debit/credit. Unblocked from customers/suppliers prereq (spec only requires COA reconciliation, done by pipeline).
- Onboarding import hub + per-entity routes deleted; post-go-live standalone pages now thin ImportDialog wrappers; quick-start widget points to /inventory/items/import.

2026-06-07 later: commit `4a092af` closed two gaps — (a) AR/AP per-party aging import BUILT (opening-receivables/payables endpoints, party-tagged JE lines on 1131/2111, advisory-lock mutual exclusion with TB import per control account, reconciliation ties Σper-party vs GL, stranded-run self-heal, migration 0054); (b) opening wizards (stock/balances/+new party) redesigned to stacked-dialog cards with in-flight close guard + navigate-away confirm. Onboarding screen: sticky footer, loading shimmer (no not-done flash), two aging rows. Full 5-reviewer pass, all findings fixed. Mira/Migration-Brain direction specced in agent-os/product/ai-engine/07-mira-migration-brain.md (uncommitted root repo) + model matrix in 05.

Known gaps / follow-ups:
- E2E specs for new dialog flows not written (hub-only specs deleted; opening-import.spec references old full-page wizards — needs rewrite).
- opening-party-import.service.ts is 1006 lines (>800 guideline) — split candidate.
- Party-import done-state is session-local (no hub-status endpoint for party runs) — resets on refresh by design, documented.
- No Linear issue linked yet; branch name has no DEV-XX. Branch not yet PR'd (tree still carries other agent's purchase WIP incl. 0053 migration sharing _journal.json).

Related: [[project_gtm_migration_wedge]], [[project_onboarding_audit_2026-06]]
