---
name: feedback_no_em_dashes_product_copy
description: Never use em/en dashes in product copy; instruct every subagent the same
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9ff8ead1-3aa4-4fe6-8c12-619f0bd94bd8
---

No em dashes (—) or en dashes (–) ANYWHERE in product copy at all — user-visible strings,
i18n message JSON (en + ar), button labels, marketing/website copy. Use a colon, comma, or
period instead.

**Why:** founder mandate (2026-06-14); em dashes read as AI-generated and the brand voice avoids them.

**How to apply:** when delegating ANY task that writes copy, give the subagent a STRICT explicit
instruction: "no em/en dashes anywhere in product copy." After a subagent returns, grep new copy
for `[\x{2014}\x{2013}]` and strip violations. Code comments and `—`-as-empty-cell placeholders are
not "product copy" but prefer avoiding them too. Existing deferred backlog: ~280 em dashes in
messages en+ar (see [[project_pack_units_uom]]). [[feedback_assume_dumb_customers]]
