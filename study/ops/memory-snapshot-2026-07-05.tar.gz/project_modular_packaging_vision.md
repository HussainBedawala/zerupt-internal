---
name: project_modular_packaging_vision
description: Long-term vision to sell ERP modules independently (OAuth-style module selection); build clean self-contained core modules
metadata: 
  node_type: memory
  type: project
  originSessionId: 0993861d-4b71-4019-97f7-fc1176cb2154
---

Long-term (not near-term) founder vision stated 2026-06-20: sell Zerupt modules
**independently**, OAuth-style — a customer picks the module(s) they want and gets that module
plus only the essentials it needs to run. E.g. pick **Accounting** → get core Accounting alone;
pick **POS** → get POS + its essential dependencies; same for Purchase, Sales, etc.

**Build implication (applies now, foundation-level):** each module must be a clean,
self-contained CORE that can be packaged and sold alone. Dependency direction matters —
feature modules (POS/sales/purchase/inventory) depend DOWN on Accounting via events/the
transactional outbox; Accounting must NOT depend UP into them. Keep module boundaries clean so
a module can be extracted without dragging the rest of the monolith. This reinforces the
event-driven decoupling already in place.

Founder said "don't think too much about this, just FYI" — so treat as a design constraint to
respect (boundaries, dependency direction), not a near-term build task. Relates to the
accounting hardening program ([[project_zerupt_codebase_maturity]]) and the modular-monolith
architecture in CLAUDE.md.
