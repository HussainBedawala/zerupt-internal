---
name: project_import_recon_suspense_2026-06-18
description: "2026-06-18 import opening-balance posting/recon fixes + Suspense feature, shipped to main and deployed"
metadata: 
  node_type: memory
  type: project
  originSessionId: 36eea93a-9e8e-4756-af4b-e7ae70436929
---

2026-06-18 (Gulf Hardware Kuwait persona testing): fixed a cluster of Mira/unified opening-balance import bugs and shipped a Suspense feature. Two commits on `main`: `5fc6be21` (fixes + suspense) and `1a445735` (idempotent system-role account backfill CLI).

Bugs fixed: (A) AR/AP sub-ledger-vs-GL recon read a stale `sourceControlTotals` snapshot (0) → now reads live stub-invoice sum; (B) customer/supplier sub-ledger apply double-posted the AR/AP control on top of a TB-posted control (live AR went to 2× GL) → conversion-mode now seeds sub-ledger detail tied to the TB journal, posts no new control journal, records the real file sum; new `OpeningBalanceService.isOpeningControlSeeded`; (C) frontend `ENTITY_FIELDS` mirror in `apps/web/src/features/import/types.ts` had drifted — missing `openingBalance`/`creditLimit` so the mapping dropdown had no opening-balance option (+ field-label keys + en/ar); (D) go-live Zod enum missing `ar_subledger`/`ap_subledger` + suspense fields crashed the tie-out panel; (E/F/G) unified-opening-apply `buildColumnMappings` dropped user-confirmed review-band mappings (<0.92) → imported code/phone/paymentTerms not persisted, auto-generated SUP-#### codes broke dedup-on-reimport and opening-AP match-by-code → fix threads user `columnOverrides` into `applyOpening`/`ensureParties` as authoritative; AI prompt confidence raised in `apps/ai/app/llm/prompts.py`.

Suspense feature: new COA account **1191 "Opening Balance Difference"**, system role `opening_balance_suspense`, table `opening_balance_reconciling_items` (tenant migration `0096_lyrical_talos.sql`). Genuine AR/AP sub-ledger-vs-GL gaps park to 1191 as a durable tracked/acknowledgeable item (NEVER OBE 3900); go-live blocked until acknowledged or gap=0.

Ops (Railway auto-migrate was down, applied manually): migration `0096` applied + physically verified on dev (3 tenants) and prod (1 tenant, gulf_hardware). Suspense account 1191 was missing on existing tenants → new `seed:system-accounts` CLI (`CoaSeedService.ensureSystemRoleAccounts`, idempotent, mirrors migrate-tenants; run locally for dev, `railway run` for prod) applied + verified 1191 bound to role on dev+prod. Neon project `restless-hill-33464873`; dev branch `br-old-recipe-a1d3dw26`, prod (default) `br-red-term-a1vs9ndl`. Related: [[project_unified_mira_import]] [[project_resolver_engine_tb_import]] [[project_import_ai_first_mandate]] [[project_manual_tenant_migration]]
