---
name: project_admin_migration_deploy_gap
description: Provisioning failures often = admin-DB migration drift; admin migrations now auto-apply in Railway pre-deploy + describeError surfaces root cause
metadata: 
  node_type: memory
  type: project
  originSessionId: 3c128ca2-ffd3-4e3d-988f-9bd39aa666bc
---

2026-06-09: Prod signup/provisioning stalled forever ("Account created", job failed
attempt 1/3 instantly). Root cause was NOT Neon autosuspend or retry logic — it was
**admin-DB migration drift**: code referencing new `tenant_databases` columns
(`db_user_readonly`, `db_password_readonly_enc`, migration 0009) shipped, but the prod
admin DB was stuck at 0006. Every provisioning read threw `column does not exist` →
instant non-transient failure on CreateDB step 1.

**Why it was hidden:** Drizzle wraps the real pg error under `.cause`; the worker logged
only `error.message` = "Failed query: select ...", so the actual cause was invisible and
we guessed for hours (chased an autosuspend red herring — that `Connection terminated
unexpectedly` was a *separate* harmless JobProgressService LISTEN-socket drop).

**Fixes shipped (commit e007493):**
- `apps/api/src/migration/migrate-admin.cli.ts` — transactional neon-serverless migrator
  over DIRECT_URL_ADMIN. Runs FIRST in Railway pre-deploy (railway.json), before
  migrate-tenants (which reads the admin registry). Non-zero exit aborts the deploy.
- Dockerfile copies `packages/db-admin/drizzle` into the prod image.
- `describeError()` (`apps/api/src/provisioning/describe-error.ts`) walks the full
  `.cause` chain; worker now logs + stores `msg [pgcode] ← caused by: ...`.

**Diagnostic heuristic for future provisioning failures:** instant failure with no
`withNeonRetry` "retrying" lines = non-transient = almost certainly a schema/column
error. Check admin migration drift first: compare `drizzle.__drizzle_migrations` count in
prod `zerupt_admin` (Neon project restless-hill-33464873) vs files in
`packages/db-admin/drizzle/`. Recovery runbook: [[project_provisioning_recovery]] (see
agent-os/product/user-journeys/PROVISIONING-RECOVERY-RUNBOOK.md).
