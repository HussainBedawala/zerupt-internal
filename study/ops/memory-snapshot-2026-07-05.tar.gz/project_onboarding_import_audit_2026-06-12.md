---
name: project_onboarding_import_audit_2026-06-12
description: "2026-06-12 overnight 4-round audit+fix of the new single-dropzone Mira onboarding import, ahead of real-data testing"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2b05b887-0403-4150-bb7a-cab7163cfe76
---

Overnight 2026-06-12: full audit (4 rounds: audit→fix→verify, converged to zero new issues) of the new **single-dropzone Mira onboarding import** across web, api, ai service, db — ahead of founder + dad testing with real user data from another system.

Committed as `67ada6c` on main (erp repo), 45 files. Pushed together with other agents' commits as a single load.

**Biggest bugs fixed (were demo blockers):**
- Migration session could never reach `ready` → every commit 409'd (clean imports now land in `ready`; resolveCard auto-transitions when last blocking card clears).
- `resolveCard` could regress an `applied`/`applying` session → double-post of opening balances. Now 3-layer guarded (top guard + deriveResolveStatus + CAS WHERE predicate).
- AI engine deleted real products named "Total"/"Balance" (substring footer match) → word-boundary + numeric evidence; Arabic compound-label handling.
- csv_loader hardcoded utf-8 → crashed on windows-1256 Arabic exports; BOM corrupted headers. Now utf-8-sig/windows-1256/latin-1 + delimiter sniff + xlsx/binary rejection.
- parse_number: parens-negatives, reject percent/excel-text-apostrophe, year pivot; qty/stock columns protected from running-total stripping.
- Hardcoded AR/AP control codes 1131/2111 → resolved via system-role bindings (broke non-standard charts).
- CommitSummary consumed wrong shape (frontend type drift vs backend `{count,total}` + reconciliation `{canGoLive,status}`).
- Every session status now renders non-blank UI + defensive fallback (no dead-ends); stall timeout, start-over/start-fresh recovery, double-submit guard.

**DB:** migration `0080_colossal_pandemic.sql` — graph_edges timestamps→timestamptz, coa_reconciliation_runs + coa_suggestions indexes. Applied to dev tenant DB; existing tenants + prod auto-migrate on Railway pre-deploy (`migrate-tenants.cli --apply`).

All suites green: ai 394, api 5577, web 2081. Full turbo typecheck + lint + i18n pass.

See [[project_mira_program_shipped]], [[project_import_pipeline_fixes_2026-06]], [[feedback_assume_dumb_customers]].
