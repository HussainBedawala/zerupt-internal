---
name: project_ap_subledger_source_of_truth
description: "AP (and AR) aging/balances must derive from the GL party-tagged control-account sub-ledger, never from denormalized bill balances"
metadata: 
  node_type: memory
  type: project
  originSessionId: d37626b8-4abd-450e-b56f-5fb3b02d0552
---

Founder ruling (2026-07-03, purchase 09 hardening): the **AP subledger of record is the GL 2111 party-tagged balance (Σ credit − debit on the `trade_payables` control account), NOT denormalized `purchase_invoices.balance`.** Any aging/outstanding figure derived from open-bill balances silently misses non-bill 2111 movements (freight owed to a supplier, purchase-return void contras, manual JEs, advances) and breaks the four-way reconcile — proven with real prod money on Al-Asala.

Permanent fix shipped (commit cdad7367): the `/purchase` overview AP aging + Outstanding/Overdue AP KPIs now reuse the **one** GL-native `ApAgingService` engine (the same one behind `/reports/ap-aging`), shared via `apps/api/src/reports/ap-aging.module.ts` (`ApAgingModule`, deps: TenantDrizzleModule only). New method `ApAgingService.functionalBySupplier()` reuses the engine's existing GL fetch + FIFO settlement (no duplicated bucket math). The dead bills-based `SupplierApBalanceService.agingBuckets` was deleted. Result: these figures tie to the trial-balance AP control = Balance Sheet by construction.

**Rule going forward:** when building any AP/AR balance, aging, or "outstanding" figure, derive it from the party-tagged control-account sub-ledger via the shared aging engine — do NOT re-read denormalized document balances. This closes the long-standing "two AP-aging implementations" drift ([[feedback_never_hand_edit_migration_journal]] is a sibling reconcile lesson). AR side (sales) likely has the same `ArAgingService` GL-native engine already — prefer it over invoice-balance sums.
