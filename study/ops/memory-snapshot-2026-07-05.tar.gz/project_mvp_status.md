---
name: mvp-status-mar28
description: MVP project status as of 2026-03-28 — what's built, what's left, timeline target
type: project
---

**Status as of 2026-03-28:**
- Phase 0 (Infra): 49/49 DONE
- Phase 1 (Settings): 39/39 DONE
- Phase 2 (Accounting): 32/42 done, 10 remaining (mostly polish — keyboard nav, batch ops, test coverage, flux analysis)
- MVP Project: 38 issues, ALL New (M1-M6 not started)

**What's built in codebase:**
- Full multi-tenancy (admin DB + per-tenant DBs via Neon)
- Auth (Supabase + JWT), RBAC, org hierarchy
- Accounting engine: COA, journals, fiscal periods, tax calc, FX, year-end, GL, trial balance, opening balance, bank recon, withholding tax
- i18n (ar/en), RTL layout, IBM Plex fonts
- Frontend: Settings pages, Accounting pages (COA, journals, GL, trial balance, audit trail, bank recon, opening balance, fiscal years, account mappings)
- No inventory, POS, sales, purchase, reports, dashboard, onboarding yet

**MVP milestones (Linear):**
M0: Foundation verify → M1: Inventory → M2: POS → M3: Sales Invoicing → M4: Reports & Dashboard → M5: Onboarding & AI Import → M6: Print & Polish

**Why:** Hussain validated with experienced people that full suite is needed. AI onboarding is the differentiator.
**How to apply:** Don't suggest cutting Sales or Purchase. Focus on speed of execution through the full MVP.

**Old Phase projects (3-8) in Linear are stale** — they have pre-MVP scope with unrealistic 1-day target dates from initial planning. The MVP project supersedes them.
