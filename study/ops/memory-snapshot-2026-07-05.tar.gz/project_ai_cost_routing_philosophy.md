---
name: project_ai_cost_routing_philosophy
description: "Standing principle for how Zerupt uses LLMs — deterministic-first, learn-don't-re-infer, route-by-task. Governs all AI features, not just onboarding."
metadata: 
  node_type: memory
  type: project
  originSessionId: 851a75fd-96b4-4e8a-861b-f765b7862292
---

Zerupt is AI-native in **experience and outcome** (it does the work, learns, advises) — NOT in token spend. Decided 2026-05-30 while scoping M5 onboarding/import.

Three standing rules for every AI feature:
1. **Deterministic-first.** Repetitive/exact tasks (column mapping, validation, GL posting, COA role-binding) resolve deterministically. The LLM is the *last rung* for the ambiguous tail only. The LLM never decides anything that posts to the ledger.
2. **Learn, don't re-infer.** Cache/learn results (e.g. import source-fingerprint mapping cache) so repeat work trends to ~zero cost. System gets cheaper AND smarter with scale — opposite of legacy ERP.
3. **Route by task, not one model.** Via LiteLLM: extraction/low-reasoning (import mapping, fixes, classification) → cheap/fast tier; reasoning/judgment (COA reconciliation advice, Copilot, the "Next Move") → high-capability tier. Never run a reasoning model on what a regex resolves.

**Provider:** NOT yet decided — kept open behind LiteLLM portability. Do not assume a default vendor.

**Cost guardrails:** per-request LLM call + token telemetry; soft per-onboarding budget (~$1) whose breach signals a deterministic-path gap, not expected spend. Be *generous* with model quality where the LLM is genuinely right (advice, Copilot) — discipline elsewhere funds it.

Canonical: implemented as the import "resolution ladder" in [[project_mvp_status]] M5. Specs: `agent-os/product/onboarding/03-ai-import-assistant.md` (§ Column Resolution Ladder, § CoA Reconciliation), `agent-os/product/tech-stack.md` §6. Aligns with brand "power shown sparingly" — see [[feedback_full_suite]] and [[feedback_defensive_ux]].
