---
name: project_e2e_hardening_2026-06-17
description: 2026-06-17 overnight full-product E2E shakedown — 16 fixes + 11 module verifications shipped to main (commit 23d9c074)
metadata: 
  node_type: memory
  type: project
  originSessionId: 48640463-cdfd-4b0a-982d-2ea8857d0e35
---

Overnight autonomous E2E hardening of the whole ERP on Persona 3 (Gulf Hardware, Kuwait, KWD/no-VAT). All work delegated to subagents (root-cause-first, no nested spawns), verified, and pushed to main as ONE commit **23d9c074** (130 files). Full gate green pre-commit: all TS typecheck + 6152 api tests + 216 web test files. Issue log: `erp/docs/e2e-issues-log.md`.

**Verified correct (code + tests + live DB tie-outs reconcile to GL):** purchase return, sales credit note, manual JE + period lock, cheques/PDC, all 11 reports (BS balances, AR/AP/inventory tie to controls 1131/2111/1141), inventory sub-features, SO/PO + masters, Sami scanner, Zee scheduler (consumer unbuilt = Phase 7 stub), settings, Z-report. ISSUE-64 + prior counted-cash worry = not-bugs.

**Fixed:** 58 (POS availability scoped to register warehouse — CRITICAL), 68 (maker-checker → tenant setting require_payment_approval default OFF), 73 (DB immutability triggers on posted JEs, migration 0091), 76 (cash-flow IAS-7 category seeding, systemic), 48 (provisioning retry via liveness heartbeat), 50 (import-commit batched), 51 (import customer-vs-GL classification), 77/78/79 (inventory date guards / batch write-off GL via StockAdjustments / cleanup), 80 (customer creditLimit field+import, migration 0092, NO enforcement), 81 (Sami Arabic numerals), 69/70/71 (payment UI), 82/83/84 (customer search-by-code, dashboard tenant-timezone, dashboard currency dp).

**Migrations 0090/0091/0092 auto-apply on the Railway deploy this push triggered** (pre-deploy migrate-tenants --apply; a bad migration safely aborts the deploy). 0091 trigger was NOT run against a live DB — apply to a dev tenant + run ledger-immutability.integration.spec in CI before relying on it.

**FOUNDER TODO:** (1) run the cash-flow backfill UPDATE (in log, ISSUE-76) on existing tenants; (2) decide ISSUE-72 (per-payment bank selector), ISSUE-74 (cheque bounce-fee UX), ISSUE-80 enforcement policy (block/warn/override) — all left as decisions, not guessed; (3) finish + commit the separate uncommitted `apps/ai` location-mapper WIP (has a real mypy error, deliberately NOT committed); (4) live-confirm a supplier payment post (DR 2111/CR bank) + one POS sale.

See [[project_import_pipeline_taxonomy]], [[project_mvp_status]], [[feedback_assume_dumb_customers]].
