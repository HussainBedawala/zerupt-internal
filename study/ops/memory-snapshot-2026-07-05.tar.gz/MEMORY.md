# Zerupt Project Memory

> Identity, tech stack, git repos, brand, and conventions live in `/Zerupt/CLAUDE.md` — not duplicated here.
> This index holds only what CLAUDE.md doesn't: strategy, status, decisions, and references.

## Project Overview
- Zerupt = world's first agentic AI retail ERP (formerly HSN/Merpec). Solo founder: Hussain. Bootstrapping (no fundraising).
- Product specs (canonical): `/Zerupt/agent-os/product/`. Content guide: `agent-os/content-style-guide.md`.

## Founder & Strategy
- [Founder profile](user_founder_profile.md) — capacity, goals, influences, content strategy
- [Codebase maturity](project_zerupt_codebase_maturity.md) — reuse don't restart; ingestion engine + AI are the unbuilt wedge
- [Modular packaging vision](project_modular_packaging_vision.md) — long-term: sell modules independently (OAuth-style); clean self-contained cores, deps point DOWN to accounting
- [Accounting hardening program](project_accounting_hardening_program.md) — overnight 2026-06-20 layer-by-layer audit+harden; resume via study/accounting/_hardening-log.md
- [Inventory hardening program](project_inventory_hardening_program.md) — 2026-06-27 repeat of accounting program for inventory; ledger-first 6-layer plan; resume via study/inventory/_hardening-log.md
- [Purchase hardening program](project_purchase_hardening_program.md) — 2026-06-29 repeat for purchase module; dual-path (direct purchase + PO chain) + backend&frontend mandate; dev push + Railway prod auto-migrate; 6-layer plan; resume via study/purchase/_hardening-log.md
- [POS hardening program](project_pos_hardening_program.md) — ✅ COMPLETE 2026-06-30: 5th hardening program; all 8 layers + quick-create shipped (d7bb7af7·4b2b7c92·ef653901·2e5d6251·97d5868d·383d23de·e771087d, migs 0134-0139); three-way tie-out, offline idempotency+queues, blind-close+X-report, phase-aware BUILD↔SETTLE inline pay, token-approval discounts (no PIN at rest)+pre-tax VAT, WhatsApp/gift/Arabic receipts, reporting+prayer/display/scale; deferred ZATCA+loyalty; prod migration incident fixed (0136.sql gap → journal-integrity CI guard); resume via study/pos/_hardening-log.md
- [Sales hardening program](project_sales_hardening_program.md) — ✅ COMPLETE 2026-06-30: all 6 layers shipped (96d1c32d·86ee163f·b04b2508·acb8c13f·e8508148, migs 0131-0133); AR derived from party-tagged 1131 GL (reconcile holds), dual-path direct/SO, full reversal coverage (SO cancel/invoice void/credit note/receipt reversal), output VAT+COGS GL-correct; FX fail-loud is biggest deferral; resume via study/sales/_hardening-log.md

## Development Status
- [Decimal precision hardening](project_decimal_precision_hardening.md) — 2026-07-03 SHIPPED (bcc9da7f, pushed main): app-wide fix for hardcoded money/qty decimals; canonical primitives (formatMoneyAmount/formatQuantity/MoneyInput/QuantityInput) + items.quantityDecimals column (mig 0147) + ESLint guardrail; prod tenants auto-migrate on deploy; DEV tenant-DB migrate still pending (auto-mode blocks it)
- [Combobox consolidation](project_combobox_consolidation.md) — ✅ COMPLETE 2026-07-02: shared entity pickers across web; all 18 sites migrated + dead code deleted + pushed; primitives searchable/async/multi-select-list
- [Component consistency recon](project_component_consistency_recon.md) — ✅ COMPLETE 2026-07-03: recon → verified plan → full impl shipped to main (17 erp commits, 713f6d4f..4a99aef3); currency-decimals unified onto @zerupt/shared, new picker/money/qty/percent primitives, native selects→pickers, raw inputs→MoneyInput/QuantityInput, formatters deduped, stock-count per-item precision + pos-return currencyDecimals bugs fixed; ~200+ tests, final verify GREEN
- [AI engine redesign](project_ai_engine_redesign.md) — 2026-06-07: Zee + named team, own-the-brain strategy, invoice scanner IN the June 15 MVP; canonical spec `agent-os/product/ai-engine/`
- [MVP status](project_mvp_status.md) — what's built vs left, M0–M6 milestones (counts as of 2026-03-28; Linear MVP project supersedes stale Phase 3–8 projects)
- [DEV-292 onboarding wizard](project_dev292_onboarding.md) — building wizard one step at a time; Step 1 done (commit 8dd8228), Step 2 (Locations) next
- [DEV-294 onboarding wizard (web)](project_dev294_onboarding_wizard.md) — Phase A shell + B Step 1 built (2026-05-31, uncommitted, shared dev-346 branch); Phase C = Step 2 next
- [COA accuracy (GCC)](project_coa_accuracy_gcc.md) — 2026-06-02 audit+fix to zero findings; WAC 5-category scoping; Qatar dormant-VAT decision; staged uncommitted; DEV-360/361/362

- [Import AI-first mandate](project_import_ai_first_mandate.md) — 2026-06-17 founder ruling: ALL import column/field/location MEANING resolution must be fully AI-first; deterministic rung/alias gate is being REMOVED (supersedes keep-the-rung-ladder stance); aligns with in-flight AI location-mapper work
- [Import pipeline taxonomy](project_import_pipeline_taxonomy.md) — live-vs-dead map (PARTLY SUPERSEDED 2026-06-17 by AI-first mandate above): rung/ladder/T0-T5 engines, unified import = AI-first classify front door, Pipeline A = the dead flow (removed on web 2026-06-15); Pipeline-A map still valid
- [Import dialog redesign](project_import_dialog_redesign.md) — 2026-06-07 stacked-dialog import UX, dup-name→warning, trial-balance rename; commit 99e909e unmerged; AR/AP aging import = next wedge gap
- [Phase A launch wedges](project_phase_a_wedges.md) — Mira + Sami full June 15 build: 11 Linear issues (Phase A milestone c7759432), SSE in scope (no polling), Stitch project 13064527749493865394 (8 screens light+dark), build order
- [Printing epic 2026-06](project_printing_epic_2026-06.md) — 10-layer printing/receipts/transfers/orders ALL DONE 2026-06-07; 12 commits b5eda8d..50b60ba unpushed on shared branch
- [POS hardening 2026-06](project_pos_hardening_2026-06.md) — DEV-389–395 ALL DONE, merged PR #142 (2026-06-06); print-agent architecture + render-only document pattern locked
- [Onboarding audit 2026-06](project_onboarding_audit_2026-06.md) — wizard audited+fixed, merged PR #137; E2E fresh-user pattern + intentionally-unused fields
- [E2E POM infrastructure](project_e2e_pom_infrastructure.md) — testid registry + page objects + fixtures (2026-06-06); env gotchas: tenant migration drift, nest-watch kills provisioning
- [DEV-306 launch hardening](project_dev306_launch_hardening.md) — final security gate DONE in code (merged 2026-06-10, b604379); ops runbook pending (admin migration 0011, env vars, CSP flip, DNS/uptime) before go-live
- [Import pipeline fixes 2026-06](project_import_pipeline_fixes_2026-06.md) — 2026-06-10 overnight: AI model ids (PR #148 merged), currency-parse + chunk-recovery + matcher robustness (PR #149 open/green), import-files bucket + opening-balance design TODOs
- [Mira program shipped](project_mira_program_shipped.md) — 2026-06-11 overnight: full 50→100% Mira capability program pushed to main (5 commits); cleaning brain/anomalies/dedup/decision-cards/learning-loop/voice/resumable/multi-file; all green; non-Mira working-tree files left for founder
- [Onboarding import audit](project_onboarding_import_audit_2026-06-12.md) — 2026-06-12 overnight 4-round audit+fix of single-dropzone Mira import (commit 67ada6c); fixed commit-409 blocker, double-post guard, Arabic encoding/footer data-corruption, contract drift; all green, demo-ready
- [Knowledge graph](project_knowledge_graph.md) — 2026-06-11: business knowledge graph (DEV-417) built+shipped to main (commit c7b6bb7); graph_edges + GraphModule, born-from-migration seeding, Zee/Mira/Sami access, 3 user-felt features (blast-radius/dormant-capital/both-sides); learning-flywheel tenantId hardening same commit
- [Import price lists](project_import_price_lists_2026-06-18.md) — 2026-06-18: import captures extra price columns (wholesale/VIP/etc) into price_lists (commit 921e8a3f); customer-group auto-assign still unbuilt
- [Inventory import design](project_inventory_import_design.md) — 2026-06-14 DESIGN ONLY: TB-style unified item import (categories→locations→items→stock, reconcile Σ(qty×cost)=1141); doc erp/docs/inventory-import-design.md; awaiting founder confirmation
- [Onboarding TB import screen](project_onboarding_tb_import_screen.md) — 2026-06-14 overnight: import screen rebuilt around single canonical TB import (reuses TbImportDialog); removed COA-source question + duplicate openingBalances path; hub-status/readiness read tb_import_runs. Worktree erp-onboarding-import, branch phase-5/onboarding-tb-import, commit 474613e UNMERGED (awaiting founder). web+api green.
- [Pack units / UOM](project_pack_units_uom.md) — 2026-06-14: Wave 1 backend DONE+committed (f1cae08 Phase 0, fd6b626 wave1+fixes) on branch phase-3/pack-units-uom; base-unit-canonical pack conversion across pos/sales/purchase/stock via shared resolvePackUnit; migration 0087. Migrations APPLIED dev 2026-06-14 (prod rides Railway deploy). Wave 2 frontend IN PROGRESS 2026-06-14 (item-form pack editor + LineUnitPicker + search-payload enrichment done; line-entry wiring across pos/sales/purchase/stock running). Then unified Mira inventory import → see [[project_inventory_import_design]]
- [Unified Mira import](project_unified_mira_import.md) — 2026-06-14: ONE AI front-door import pipeline (ISSUE-12 fix); classify+comprehend+route each file into existing working engines (entity ImportResolutionService/ImportApplyService, TB TbImportService, opening-import); architecture LOCKED, staged build S1-S4
- [Resolver engine + TB import](project_resolver_engine_tb_import.md) — 2026-06-13 overnight: new tiered engine replaces the 5-rung ladder; unified trial-balance import (extract COA→canonical groups, AR/AP subledger, balanced opening journal); 7-agent audit+fix; verified on real dev DB (AR 1131=98); PR #152 UNMERGED (needs founder review + pgvector/E2E ops steps)
- [TB import zero-question session](project_tb_import_zero_question_session.md) — 2026-06-13 IN-PROGRESS: zero-cards + AI file-diagnosis rework; full continuation state in `erp/docs/tb-import-session-handoff.md`; real open bugs (learning stores leaf code 1113 not category; closing-col card on unlabeled Dr/Cr pairs); founder mandate = AI diagnoses file structure not regex

- [E2E hardening 2026-06-17](project_e2e_hardening_2026-06-17.md) — overnight full-product shakedown: 16 fixes + 11 module verifications shipped to main (commit 23d9c074); migrations 0090/0091/0092 auto-apply on deploy; founder TODOs = cash-flow backfill + 3 product decisions (72/74/80-enforcement) + finish apps/ai WIP + live-confirm payment/POS; PRINT not tested this pass
- [Auth emails branding](project_auth_emails_branding.md) — 2026-06-16: Zee-voiced branded auth emails (signup/invite/reset/magic) via Resend SMTP + Supabase dashboard templates; artifacts in erp/docs/auth-emails/; logo at zerupt.com/email/; founder TODO = rotate exposed Resend key + deploy website + dashboard setup
- [Books import template](project_books_import_template.md) — 2026-06-22: Zerupt-generated TB+Customers+Suppliers workbook, deterministic parse (AI off launch path); DEV-428 + design doc erp/docs/tb-template-import-design.md; supplier_addresses (migration 0110) shipped to dev tenants; prod has NO live tenant DBs (stale registry → DEV-429); inventory flow next (DEV-430)
- [Inventory import template](project_inventory_import_template.md) — 2026-06-28: DEV-430 inventory twin of books template (categories/items/opening-stock xlsx); 1141 first-writer-wins via ob_inv; pack defs persisted; derive-and-extend warehouses; record-before-seed durability (apply_claim_key); migrations 0116/0117; merged to main LOCALLY (unpushed); founder TODO = real-editor xlsx round-trip then push
- [Import recon + Suspense](project_import_recon_suspense_2026-06-18.md) — 2026-06-18: opening-balance double-post + recon-read + mapping-dropdown + party code/phone bugs fixed; new Suspense acct 1191 + tracked-items feature; shipped main (5fc6be21, 1a445735); migration 0096 + seed:system-accounts CLI applied+verified dev & prod

## Go-To-Market
- [Website story rebuild](project_website_story_rebuild.md) — 2026-06-09 overnight: zerupt.com rebuilt as one continuous emotional scroll (12 beats + /team + pricing gate + waitlist); all checks/build green; AR copy + WhatsApp # + founder/close images need founder
- [zerupt-mcp server](project_zerupt_mcp_server.md) — product-knowledge MCP for marketing agents (tools/zerupt-mcp, built 2026-06-07); Railway deploy pending user steps
- [GTM migration wedge](project_gtm_migration_wedge.md) — locked wedge + first-customer strategy + channels (office-hours 2026-05-31)
- [Pricing & Grand Slam Offer](project_pricing_offer.md) — GCC per-outlet tiers, 2-part guarantee, Founding 50, canonical in Linear (locked 2026-06-01)

## Compliance & Regulatory
- [Corporate structure](project_corporate_structure.md) — no Zerupt entity; operates under Malakstar Software Solutions Pvt Ltd (India)
- [ZATCA e-invoicing research](project_zatca_einvoicing_research.md) — 2026-06-10 deep brief; Phase 1 MVP-sized, Phase 2 (Wave 24 SAR 375k) = nearly all KSA retail; no vendor cert, taxpayer self-onboards; data-residency open
- [ZATCA e-invoicing implementation](project_zatca_einvoicing.md) — 2026-06-11: full P1+P2 epic; all 6 official PDFs read; curve=secp256k1, PIH seed, C14N1.1, XAdES-B-B resolved via SDK oracle; SDK at ~/Downloads/zatca-envoice-sdk-203 (Java 11)

## Operations
- [P3 deep audit 2026-07-04](project_p3_deep_audit.md) — 21 confirmed findings; remediation SHIPPED (erp main 81a3673b..669ee447, 5 commits); founder to-dos = Sentry metric alerts (#14) + Neon PITR retention/protect (#15); backlog = pos pay() lock-contention #18-#20
- [Infra audit 2026-07-04](project_infra_audit_2026-07-04.md) — 4-track audit + same-day fixes shipped (drizzle CVE, upstash removed, pool self-heal, AI fallbacks, storage hardening, sentry hygiene); founder dashboard actions + P3 deep audit pending
- [Manual tenant migration](project_manual_tenant_migration.md) — apply Drizzle tenant migrations to dev+prod Neon manually (the right way), verify from actual DB; new tenants auto-covered by provisioning
- [Migration deploy hardening](project_migration_deploy_hardening.md) — 2026-06-28: silent-skip root cause = Railway config-as-code path unset; shipped migrate-all.cli + boot drift guard (/health gates deploy) + migration_runs audit + feature-flag infra (commits 58cb0a85/76e1c680/91bfcdb1, deploy c1a9eb95 green); DI wiring bugs need module-compile smoke tests

## Design Principles
- [AP subledger source of truth](project_ap_subledger_source_of_truth.md) — AP/AR aging+balances derive from GL party-tagged control-account sub-ledger (shared ApAgingService), never denormalized bill balances; 09-1 fix cdad7367 killed the two-implementations drift
- [Never hand-edit migration journal](feedback_never_hand_edit_migration_journal.md) — a future-dated round `when` in drizzle _journal.json silently masked 11 prod migrations (2026-06-30); fixed via hash-based drift detection + CI journal-integrity guard; regenerate, never retype `when`
- [Assume dumb customers](feedback_assume_dumb_customers.md) — never throw away data or dead-end; one mistake = lost customer; AI must absorb mess
- [Defensive UX](feedback_defensive_ux.md) — always assume users will break things
- [Delegate to subagents](feedback_delegate_subagents.md) — heavy subagent use in /work to keep context lean
- [No nested subagent spawn](feedback_subagents_no_nested_spawn.md) — subagents I spawn must NOT spawn their own subagents (runaway-loop incident); instruct them explicitly
- [Full suite required](feedback_full_suite.md) — don't suggest cutting Sales/Purchase/AI from MVP
- [Subagent model selection](feedback_subagent_model_selection.md) — assign subagent models by complexity, never default (cost)
- [Check stash before redo](feedback_check_stash_before_redo.md) — vanished edits = check git stash/fsck first; concurrent sessions auto-stash the shared erp/ tree
- [Language-agnostic names](feedback_language_agnostic_names.md) — never hardcode English/Arabic; tenant primary/secondary pair from supported-languages registry; content-language only if locale ships
- [No em dashes in product copy](feedback_no_em_dashes_product_copy.md) — strict; instruct every subagent; grep new copy after
- [Decide for module persona](feedback_decide_for_module_persona.md) — in testing/fix passes, decide tradeoffs yourself by the module's persona; don't ask
- [POS approval gates settings-optional](feedback_pos_approval_gates_settings_optional.md) — never hardcode mandatory manager PIN on POS actions; per-register toggle, default OFF (sole owner runs the till alone); enforce only when enabled

## Decisions & Config
- [Drizzle migration](project_drizzle_migration.md) — Prisma → Drizzle ORM (completed 2026-03-18)
- [ECC hooks decoupled](project_ecc_hooks_decoupled.md) — ECC plugin disabled, hooks self-managed in settings.local.json; vercel/figma off; rules/common deleted
- [Context pruning](project_context_pruning.md) — skills/plugins/global-rules trimmed to /work essentials (2026-05-30, reversible via *-disabled/ folders)
- Notion = GTM/content HQ, Linear = dev only (Notion plugin now disabled — re-enable in ~/.claude/settings.json for GTM work)

## Architecture Decisions
- [Outbox suppressErrors silent-gap](project_outbox_suppresserrors_silent_gap.md) — 2026-07-03: @OnEvent suppressErrors:true swallowed durable JE-post failures → rows marked completed w/ no GL; fixed CODEBASE-WIDE (PR #168 purchase+accounting.post, PR #169 sales/pos/cheque/inventory via shared runDurableGated helper); landed_cost→lc enum was root cause
- [pg-boss queue architecture](project_pgboss_queue_architecture.md) — DEV-388 zero-polling queue on Neon; v10 CJS pin; deploy steps
- [Admin migration deploy gap](project_admin_migration_deploy_gap.md) — provisioning fail = admin-DB migration drift; now auto-applied in pre-deploy + describeError surfaces .cause

## Authentication
- [JWT tenant claim mechanics](project_auth_jwt_tenant_claim.md) — custom_access_token_hook preserves app_metadata; set claims via updateUserById + refreshSession; Neon dev-branch gotcha

## AI Architecture
- [AI cost & routing philosophy](project_ai_cost_routing_philosophy.md) — deterministic-first, learn-don't-re-infer, route-by-task; LLM is last rung; provider still open
- [AI model reliability 2026-06-18](project_ai_model_reliability_2026-06-18.md) — reliability-first: Gemini 2.5 Flash workhorse, DeepSeek json_schema bug fix (json_object allowlist), different-provider fallbacks; supersedes cost-first split; AI service needs redeploy

## References
- [Notion HQ](reference_notion_hq.md) — Content Calendar, Customer Pipeline, Competitor Intel, GTM Dashboard, Brand Kit, Pricing
- [Node→Neon ETIMEDOUT fix](project_node_neon_etimedout.md) — Happy Eyeballs 250ms timeout; prefix NODE_OPTIONS network-family-autoselection-attempt-timeout
- [Neon DB topology](project_neon_db_topology.md) — dev=br-old-recipe, prod=br-red-term; per-tenant DBs; drizzle tracking via sha256(file)+journal when; prod MCP writes need approval
