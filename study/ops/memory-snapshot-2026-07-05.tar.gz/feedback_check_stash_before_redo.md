---
name: feedback-check-stash-before-redo
description: "If uncommitted work \"vanishes\", check git stash/fsck BEFORE redoing it; concurrent Claude sessions auto-stash the shared tree"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f5ebb921-e8c4-4a0f-9d9e-ff3b33f57f93
---

When uncommitted working-tree changes appear to vanish / get reverted mid-task, DO NOT assume they're lost and redo them. First run, in order:
1. `git stash list`
2. `git fsck --no-reflogs | grep 'dangling commit'` then `git show -s --format='%ci %s' <commit>` on each — a stash is a dangling commit titled `WIP on <branch>: …`. Inspect by timestamp.
3. `git worktree list` and `git branch -a`.

**Why:** On 2026-06-10 a full frontend-audit fix campaign (172 files, +3028/−1333) appeared wiped from `erp/`'s working tree at 17:09. I (Claude) called the dangling commits "old history" and redid two entire waves of work. It was never lost — it was in stash `WIP on main: ce330e8` the whole time, recoverable in seconds. The user (correctly) called this out: "u shldve checked stash branched dude."

**Root cause:** The Zerupt `erp/` repo has an automated `git stash` firing every ~10–20 min all day (Claude Code's native checkpoint/rewind snapshots via `git stash`). Multiple concurrent `claude` sessions share the **one** working tree at `/Users/hus3ain/Development/Zerupt/erp`, so one session's checkpoint stashes another session's uncommitted edits.

**How to apply:**
- Never run multiple Claude sessions against the same working tree for write work — use a `git worktree` per session (`git worktree add <dir> -b <branch>`) so checkpoints don't cross-contaminate. See [[project_zerupt_codebase_maturity]].
- During long multi-agent edit campaigns on this repo, **commit after every batch** (even `--no-verify` WIP commits) — committed work survives the auto-stash; uncommitted does not.
- If something does vanish: recover from stash/fsck, do not redo.
