---
name: project_combobox_consolidation
description: Shared entity-combobox consolidation across the web app — COMPLETE (all 18 sites)
metadata: 
  node_type: memory
  type: project
  originSessionId: dffeaf74-82c7-4816-bbc3-7b9335c63974
---

✅ COMPLETE 2026-07-02. Consolidated 20+ hand-rolled "search input + listbox +
keyboard nav" pickers in apps/web onto shared primitives + thin per-entity
wrappers. All 18 sites migrated, dead code deleted, typecheck/i18n/tests/build
green, pushed to main.

**Primitives (`apps/web/src/components/`):**
- `searchable-combobox.tsx` — local single-select; creatable/hasError/data-testid.
- `async-combobox.tsx` — server-search single-select; debounce, keyboard nav,
  outside-click, unmount-safety, 4 dropdown states, pill/repeat modes, onScan
  barcode slot, renderCreateRow, autoFocus, and (for the account picker) portal +
  showOnEmpty + onClose. Unit-tested.
- `multi-select-list.tsx` — presentational controlled checkbox listbox.

**Wrappers:** BranchCombobox (locations), TaxGroupCombobox (taxation),
BankAccountCombobox (accounts), SupplierCombobox (purchase/orders),
CustomerCombobox (customers), ItemSearchCombobox (inventory; repeat+pill,
normalizes search vs barcode into PickedItemFull). Shared `common.combobox` i18n.

**Migrated (all 18):** direct-purchase, order-create (supplier+branch),
payment-create, invoice-create, create-cheque, direct-sale, bill-line-search,
invoice-line-search, adjustment-item-search, price-list-add-item-dialog,
reports item-filter, promotion-targets-section, serial-picker-dialog +
return-serial-picker-dialog, legal-entity-dialog (country+currency), and
AccountPicker (internals swapped, public API kept → its 6 call sites untouched).

**Also fixed same session** (founder-reported): settlement-card citron-fill
contrast → `bg-accent/[0.06]`; PO branch → BranchCombobox; `/purchase/direct` 404
(concurrent session added a real list page); orders header buttons side-by-side.

Repo zerupt-erp, all on main (founder tests prod). Shared-tree hazard: a
concurrent session's lint-staged stash/restore ate uncommitted edits once —
commit promptly in green windows (poll `pnpm --filter @zerupt/web typecheck`).
