---
name: feedback_delegate_subagents
description: Hussain wants heavy subagent delegation during /work to keep context lean
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2fd030f4-bc04-4584-aca8-b39e18e2e135
---

During `/work` (and dev tasks generally), delegate as much as possible to subagents — exploration, spec-reading, multi-file research, and parallelizable implementation/review.

**Why:** Keeps the orchestrator's context lean, saves tokens, and preserves accuracy (less context bloat = better focus). Stated repeatedly across sessions (DEV-293, DEV-346).

**How to apply:** Use Explore/general-purpose agents for codebase mapping; have them return tight structured summaries with file:line refs, not file dumps. Run independent research/review agents in parallel. Reserve the main thread for orchestration, decisions, and user-facing summaries. See [[feedback_defensive_ux]].
