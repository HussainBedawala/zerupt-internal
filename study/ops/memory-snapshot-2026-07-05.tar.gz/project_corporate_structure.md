---
name: project_corporate_structure
description: "Zerupt's legal/corporate structure — parent company Malakstar, India registration, no standalone Zerupt entity"
metadata: 
  node_type: memory
  type: project
  originSessionId: 600d56d0-ed2f-4003-b9ed-3579f9839c3e
---

Zerupt has **no legal entity of its own**. It operates under its mother company **Malakstar Software Solutions**, a **Private Limited company registered in India**.

- Bank account, Razorpay payment gateway, and all financial/legal instruments are created under **Malakstar's license**, not Zerupt's.
- Zerupt is a product/brand, not a registered company.

**Why:** Matters for any regulatory/compliance question — KSA ZATCA e-invoicing, VAT, cross-border data, payment processing, contracts. The contracting/billing entity is the Indian Pvt Ltd (Malakstar), so KSA-specific local-presence or in-country requirements must be assessed against an Indian software vendor serving Saudi taxpayers.

**How to apply:** When evaluating regulatory requirements (e.g. ZATCA solution-provider obligations, data residency, VAT registration), reason about Malakstar (India Pvt Ltd) as the legal vendor, with Zerupt as a SaaS product. Flag anything that would require a KSA local entity, KSA data residency, or local representation. See [[project_zatca_einvoicing_research]].
