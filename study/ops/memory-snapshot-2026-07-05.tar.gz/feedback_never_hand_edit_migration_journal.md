---
name: feedback_never_hand_edit_migration_journal
description: "Never hand-edit `when` in drizzle _journal.json; it once silently masked 11 prod migrations"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ee299fee-cb0d-411a-ba77-534787637727
---

NEVER hand-edit the `when` timestamp in `packages/db/drizzle/meta/_journal.json`. If a migration's ordering needs fixing during a parallel-worktree/branch merge, REGENERATE the entry with `drizzle-kit generate` rather than retyping `when`.

**Why:** On 2026-06-30 a hand-typed round placeholder `when` of `1782900000000` (= `2026-07-01T10:00:00.000Z`, a future wall-clock instant) on migrations 0126/0127/0135 silently masked 11 unapplied migrations (0128–0138) on BOTH prod tenants. The Railway pre-deploy migrate command ran on every deploy but reported "fleet is fully current" while applying nothing, because the legacy drift logic decided "pending?" by comparing journal `when` against `MAX(created_at)` of applied migrations — and the bogus future timestamp made every newer (correctly-stamped, earlier) migration look already-applied. `/sales/customers` then crashed on prod with `column sales_customers.default_currency does not exist`. The placeholder was a fingerprint of a hand-merged journal: real `drizzle-kit generate` stamps irregular ms-precision `Date.now()` (e.g. `…429791`); a round `:00:00.000` value never comes from a clock, and 0126/0135 shared the byte-identical value (copy-paste).

**How to apply:**
- Two failures had to coincide: the hand-edited non-monotonic `when` (trigger) + timestamp-based drift detection (amplifier). Both are now fixed.
- Permanent code fix (shipped): `apps/api/src/migration/migrate-all-tenants.service.ts` now decides applied/pending by HASH-SET MEMBERSHIP (sha256 of each `.sql` vs the `hash` rows in `drizzle.__drizzle_migrations`), never by `when`, plus a post-apply completeness assertion that fails the deploy non-zero if anything stays unapplied. `migration-drift.service.ts` (boot guard) delegates to it.
- CI guard (shipped): `packages/db/src/schema/__tests__/journal-integrity.test.ts` asserts `when` is strictly monotonic by idx AND never lands on an exact minute boundary (hand-typed-placeholder canary). Runs in the existing vitest suite whenever `@zerupt/db` changes.
- If a prod tenant ever shows this symptom again: check `_journal.json` for non-monotonic/future `when`, correct the journal AND the poisoned `drizzle.__drizzle_migrations.created_at` rows, then re-run `drizzle-kit migrate` (it runs all pending in ONE transaction, so a bug rolls back cleanly and prod stays at the last-good migration).
- Related process gotcha: migrations only ever `drizzle-kit push`'d to dev (never replayed as SQL) hide SQL bugs — e.g. enum→text in an INDEX predicate fails `must be marked IMMUTABLE` (CHECK constraints allow it, indexes don't). See [[project_migration_deploy_hardening]] and [[project_manual_tenant_migration]].
