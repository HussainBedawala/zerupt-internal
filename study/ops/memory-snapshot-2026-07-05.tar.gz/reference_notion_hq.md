---
name: notion-hq
description: Notion workspace structure for Zerupt HQ — GTM, content, customers, competitors, brand, pricing
type: reference
---

**Zerupt HQ** (Notion): https://www.notion.so/3302e0cbcc54816bbf80e96ff1d9b03c

| Page/DB | Type | Purpose |
|---------|------|---------|
| Content Calendar | Database | Plan, batch, track all content. Views: Pipeline (board), Calendar |
| Customer Pipeline | Database | Track leads → waitlist → trial → paying. View: Funnel (board) |
| Competitor Intel | Database | Feature comparison table for all competitors |
| GTM Dashboard | Page | Launch checklist, key metrics, weekly review template, acquisition channels |
| Brand Kit | Page | Colors, fonts, tone of voice, content hooks, social handles |
| Pricing & Revenue | Page | Pricing tiers ($29/$49/$99), Razorpay, revenue projections, unit economics, MRR milestones |

Dev stays in Linear. Notion = everything else (GTM, content, customers, brand).
