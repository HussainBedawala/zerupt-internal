---
name: project_mira_ingestion_brain
description: "Mira's smart-ingestion architecture — knowledge-graph + embeddings + value-signatures + learning loop; LLM is the last rung, not the engine"
metadata: 
  node_type: memory
  type: project
  originSessionId: 16f7e82d-af8d-4381-b4b8-beff40deabb9
---

Vision (founder, 2026-06-10): Mira must be able to take ANY file a (dumb) customer throws at her and figure out what every column means and where it routes — never deterministic whitelist-and-discard. Founder explicitly open to ML/DL models and an Obsidian-like connected knowledge graph; wants engineering solutions, not "throw it at a provider API key."

**Core reframe:** a file is NOT "a supplier file." It's a bag of columns, each routed independently. Yousef's supplier file → contact fields → supplier records + opening-balance column → AP opening balances + payment terms → supplier terms. One file fans out to multiple destinations. Nothing discarded. This kills the "Opening Balance cannot be matched" alarm structurally.

**Architecture — deterministic/learned/retrieval first, LLM last (cheaper + smarter over time):**
1. **Domain knowledge graph (ontology):** every importable concept (customer, supplier, item, category, warehouse, opening balance, AR/AP control account, tax code) as a node with canonical name, multilingual + export-tool aliases (Tally/Zoho/QuickBooks/Arabic/Hindi), data type, validation, examples, and edges (Opening Balance —posts-to→ AR control). Curated, version-controlled. Brain's long-term memory.
2. **Column resolver = fusion of name-similarity (pgvector embeddings vs aliases) + value-signatures (classify by the column's DATA — civil-id %, currency, phone, SKU match — because headers lie, data doesn't) + learned prior.** High conf auto-maps, medium one-click, low asks. Never discards.
3. **Learning loop (the moat):** store every confirm/correction as (header + value-signature) → ontology node. Real exports cluster; Mira stops needing the LLM for known shapes. Proprietary dataset competitors paying per-token can't copy. Later train a small classifier on it.
4. **Reconciliation / entity resolution:** fuzzy+embedding match incoming parties/items vs existing → merge/dedup/flag-new. Turns "cannot match" into "matched to existing supplier X."
5. **Graceful-uncertainty UX:** never hard-error; friendly confidence-scored yes/no, zero dead-ends.
6. **LLM minimized:** only ambiguous tie-breaks (constrained choice), unstructured inputs (PDF/photo → candidates), and NL explanation. Swappable via LiteLLM.

**Build order (June 15 launch):** now = stop discarding/alarming on extra columns, guide instead (launch fix). v1 post-launch = ontology + resolver + per-tenant learned store. v2 = cross-tenant learning + classifier + entity resolution. v3 = PDF/photo ingestion.

Driven by [[feedback_assume_dumb_customers]]. Extends [[project_ai_engine_redesign]] and [[project_ai_cost_routing_philosophy]] (deterministic-first, learn-don't-re-infer). Ingestion engine is the unbuilt wedge per [[project_zerupt_codebase_maturity]].
