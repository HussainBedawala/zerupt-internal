---
name: project_website_story_rebuild
description: "2026-06-09 overnight rebuild of zerupt.com as one continuous emotional story; what shipped, what's stubbed, what needs the founder"
metadata: 
  node_type: memory
  type: project
  originSessionId: ee34aa86-f49b-48b9-a68b-f19fd90aa6ab
---

Overnight 2026-06-09 (founder asleep, autonomous, heavy subagent delegation): rebuilt the marketing website (`erp/apps/website`) from a stack of boxed sections into ONE continuous "owner's day reversed" scroll — dark 10pm trap → warms to morning cream → one dark Next Move punctuation → warm resolve.

**Architecture (the spine):** `src/components/home/beat.tsx` = `<Beat tone="dark|light" space>` + `<BeatJoin from to>` gradient connectors (seamless temperature transitions, no banded seams). Story bible = `apps/website/docs/STORY-BUILD.md` (temperature map, citron-growth rule, per-beat intent — the canonical spec all subagents built against). Hero (video) deliberately UNTOUCHED.

**Homepage 12 beats, in order:** Hero → Trap(problem, dark editorial) → Turn(the-zerupt-way, warms, names Mira) → Team teaser(NEW, Zee + roster + `agent-sigils.tsx` abstract-symbolic SVGs) → Next Move(dark, citron peak) → Offer+guarantee(NEW, live Founding-50 counter) → Proof(product-preview) → Comparison(SSR ledger) → Pricing teaser → Founder(NEW) → FAQ → Final call(NEW, morning glance). Dropped Capabilities + Proof(old) components.

**Other pages:** `/team` flagship (NEW, own `team` namespace, sections in `src/components/team/`) · `/pricing` restyled + INDUSTRY GATE (`src/components/pricing/industry-gate.tsx` + `src/lib/industry-gate.ts`: WAC→signup / FIFO+pharmacy/fresh-food→waitlist, GCC vs non-GCC, focus-trapped dialog) · `/start` founder letter (noindex) · `/waitlist` (NEW, belonging-not-rejection, gate links here locale-prefixed w/ industry/country prefill) · `/thanks` + `/privacy` + `/terms` restyled via `legal-shell.tsx` · floating WhatsApp FAB (`whatsapp-fab.tsx`, mounted in layout).

**Verified:** typecheck + i18n:check + lint (0/0) + production build (exit 0) all clean. Visual QA at 1440/390 + RTL on every page; industry gate flow tested end-to-end.

**NEEDS FOUNDER (morning):**
1. All new Arabic copy is machine-translated — flagged `REVIEW` (home.team/offer/founder/finalCall/way, team.json, pricing gate, start, waitlist, common.whatsapp). Needs native GCC review.
2. `WHATSAPP_NUMBER = "<TODO>"` in `whatsapp-fab.tsx` — real E.164 number.
3. Founder portrait: drop real photo at `public/founder.jpg` (graceful monogram placeholder until then).
4. Morning-glance close image: Imagen API hit 429 (prepayment credits depleted again) — `final-call.tsx` uses gradient placeholder; set `IMAGE_SRC` once generated.
5. Legal copy (privacy/terms) still placeholder — needs real legal review before launch.

**Polish pass 2026-06-09 (4 parallel subagents + cleanup, all verified green):**
- **Navbar contrast fix** (`site-header.tsx`): scrolled state = `bg-ink/80 backdrop-blur` frosted header w/ cream text → always legible over BOTH cream and dark sections; transparent-with-correct-tone at top. `DARK_OPENING_PATHS` set ("" home, "team") fixes the `/team` white-band strip. One-line to add future dark-opening pages.
- **Problem/Trap** (`problem.tsx`) redesigned as asymmetric features-8-style bento (01 wide hero tile, 02+03 in side channel), citron still absent.
- **Meet-the-team** (`team-teaser.tsx` + new `team-member-card.tsx` + `team-member-detail.tsx`): framer-motion installed; hover-tilt cards + click-to-open focus-trapped accessible detail dialog (Zee voice, what-they-do, live/soon). No new copy keys (roster already had `voice`/`doForYou`/`team.detail.*`). RTL tilt mirror + reduced-motion handled.
- **Pricing industry gate** lag fixed: `AnimatePresence mode="wait"→"sync"` (was up to 560ms dead time/tap), extracted memoized `IndustryTile` (2 re-renders not 12), memoized `StepB`.
- **Redundancy cut:** deleted dead `capabilities.tsx` + `proof.tsx` (+ orphan `capabilities.*`/`proof.*` keys both locales); removed triple-stated guarantee from `final-call.tsx` (kept in offer + pricing); removed redundant FinalCall HomeCta (the WaitlistSection form right below is the CTA). `finalCall.guarantee` key left in place for parity.

Relates to [[project_phase_a_wedges]], build-blueprint + website-01-experience-and-journey docs in `agent-os/product/website/`.
