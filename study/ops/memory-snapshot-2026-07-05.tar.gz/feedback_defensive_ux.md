---
name: defensive-ux-design
description: Always assume users will break things — design defensively with error states, edge cases, and foolproof UX
type: feedback
---

Always assume users are stupid and will break stuff. Design every feature defensively.

**Why:** Hussain's explicit instruction. Retail ERP users in MENA/India/SEA are not tech-savvy. Every edge case that can happen, will happen.

**How to apply:**
- Every user-facing feature needs: error states, loading states, empty states, confirmation dialogs for destructive actions
- Never trust that users will follow the "happy path"
- Think through race conditions (double-clicks, rapid switching, tab duplication)
- Consider offline/slow network scenarios
- Validate everything client-side AND server-side
- Add guards against data loss (unsaved changes warnings, auto-save where possible)
- Test with the mindset: "what's the dumbest thing a user could do here?"
