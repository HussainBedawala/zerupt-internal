---
name: project-zerupt-codebase-maturity
description: "What's built in the Zerupt erp codebase vs not — verdict is reuse, don't restart"
metadata: 
  node_type: memory
  type: project
  originSessionId: c091cb73-d921-4488-b9e2-919b2441f750
---

Zerupt erp codebase maturity (surveyed 2026-05-24). **Verdict: usable foundation, do NOT start over.**

- **Accounting (apps/api):** SUBSTANTIAL + tested. 37 modules, ~73 API spec files. COA (bilingual templates, tree, seed), journal-entries (~7K LOC, posting/reversal/FX/year-end), trial-balance, general-ledger, tax-calc, fiscal-period (closing), bank-reconciliation, opening-balance (607 LOC), fx-revaluation, withholding-tax. Event-driven via transactional outbox; all mutations `@Audited`.
- **Multi-tenancy + auth:** SUBSTANTIAL, working. Per-tenant Postgres DBs, Supabase JWT, guard chain (JWT→TenantResolver→Entitlement→Permission), ALS tenant context, LRU connection pool (packages/tenant-context).
- **Provisioning (apps/api/provisioning):** backend works (BullMQ pipeline CreateDB→RunMigrations→SeedConfig→MarkReady, step-level resume, no PII in Redis). Production-quality.
- **Frontend (apps/web):** SUBSTANTIAL. ~19 real accounting pages, 22 feature modules, 340 files, Next.js 16 + i18n en/ar.
- **Data ingestion:** PARTIAL — only bank-statement CSV importer (`apps/api/src/bank-reconciliation/csv-import.service.ts`, 163 LOC: papaparse, BOM strip, 5 date formats, amount parsing, saveable column mapping). This is the SEED to generalize into the wedge ingestion engine. No customer/vendor/item/opening-balance bulk importers, no Excel, no AI mapping.
- **AI service (apps/ai):** SCAFFOLD-ONLY. main.py = 28 lines, health check. Zero LLM/pgvector/agents. Greenfield.
- **Tests:** 128 files total (~73 api, ~44 web).

The unbuilt parts (general ingestion engine + AI layer) ARE the differentiator/wedge — correct that they come last, on top of the solid accounting+tenancy base. See [[project-gtm-migration-wedge]].
