---
name: project_outbox_suppresserrors_silent_gap
description: "@OnEvent suppressErrors:true silently defeated durable outbox JE-post propagation; fixed for purchase only, sales/pos/inventory still latent"
metadata: 
  node_type: memory
  type: project
  originSessionId: a5185e87-cb07-4cf6-992f-cf602d6e9e35
---

2026-07-03 Al-Asala prod incident (PR #168, merged to main). Landed-cost GL never posted on ANY tenant: posting emitted `sourceDocumentType: "landed_cost"` but the `document_type` enum value is `"lc"` (migration 0146) → Postgres rejected every JE insert. Fixed the 4 literals.

**Non-obvious systemic gotcha (the real hardening lesson):** the outbox poller re-fans domain events via `emitAsync` and AWAITS the chain so a JE-post failure should mark the row failed/retry/dead-letter. But `@OnEvent(..., { async: true })` defaults **`suppressErrors: true`** (@nestjs/event-emitter), which swallows the listener rejection *before* the poller's `emitAsync` sees it → row wrongly marked `completed` with no GL, attempts=0, no last_error. The durable-replay rethrow (runListenerHandler + handleAccountingPost, both gated on `DURABLE_REPLAY_MARKER`) was correct but never escaped the decorator. Fix = add `suppressErrors: false`; safe because the rethrow only fires under the durable marker, so the fast path (fire-and-forget `emit()`) is unaffected.

**Fixed codebase-wide (PR #168 then PR #169):** `suppressErrors: false` on EVERY durable-replay `@OnEvent` handler — purchase (11) + `handleAccountingPost` in #168; sales (6), pos (3), cheque (8), inventory-accounting (2), inventory-domain stock-relief/COGS fan-out (12) in #169. The safety rule: only safe where throwing is gated on the durable-replay marker (so the fire-and-forget fast path can't unhandled-reject). Accounting listeners were already gated via `runListenerHandler`; the two inventory listeners (`inventory-domain`, `landed-cost`) threw unconditionally and were refactored to gate via a NEW shared helper `runDurableGated(logger, eventType, rawPayload, fn)` (in run-listener-handler.ts) — logs always, rethrows only under the marker. `inventory-event` STOCK_INBOUND/OUTBOUND intentionally NOT gated: never emitted / not in DOMAIN_EVENT_TYPES → no durable path, no silent-gap.

**Detection net:** the reconcile-drift check (was itself dead — `= ANY(jsArray)` → invalid `ANY((...))`; fixed to `inArray()` in #168) catches drift for eventId-preserving domain events; landed cost (posts under per-component subEventId) has a dedicated source-document drift check. See [[project_pgboss_queue_architecture]], [[project_migration_deploy_hardening]], [[feedback_never_hand_edit_migration_journal]].
