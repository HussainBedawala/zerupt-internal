---
name: founder-profile
description: "Hussain's situation, capacity, goals, and preferences as solo founder building Zerupt"
metadata: 
  node_type: memory
  type: user
  originSessionId: cbde5de5-7fc7-463c-babe-d1c48c6f24db
---

- Young solo founder, working 2 jobs + building Zerupt part-time (20-30 hrs/week, 5-6 hrs/day)
- Wants to quit jobs and go full-time on Zerupt ASAP — treats runway as if only 1-2 months
- Target: first paying customers via the migration wedge — see [[project-gtm-migration-wedge]]
- Has talked to experienced people + shop owners — validated that full ERP suite (accounting, POS, sales, purchase, reports) is needed, not a stripped MVP
- AI onboarding + AI suggestions is the KEY differentiator vs Zoho/Tally/ERPNext
- Comfortable on camera, good for personal brand content
- Primary content channel: Instagram (easiest for him, strong in MENA/India/SEA)
- Ad budget: ~$300/mo max currently (a message-testing lab, not an acquisition engine at this level)
- Follows: Eva Juergens (Personal Brand Launch), Alex Hormozi, Steven Bartlett, Leila Hormozi
- Wants help with EVERYTHING: dev, GTM, content, ads, marketing, brand, growth, hiring
- Wants Notion as GTM/content command center (Linear stays for dev)
- Infrastructure is deployed: Vercel (frontend), Railway (API), Neon (DB), SSL done
- Not a lot of business books read — learning from creators/podcasts
- Content strategy: don't overcomplicate, spend more time on dev than content right now
