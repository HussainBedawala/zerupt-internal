---
name: project_zatca_einvoicing
description: "ZATCA Saudi e-invoicing (Fatoora) Phase 1+2 implementation — resolved crypto facts, SDK location, plan"
metadata: 
  node_type: memory
  type: project
  originSessionId: b6fdcc36-95c9-438a-b65c-c2c98c13146d
---

Building **full ZATCA Phase 1 + Phase 2** as one epic (founder decision 2026-06-11). KSA e-invoicing compliance for the retail ERP. Plan + extractions: `agent-os/product/zerupt-specs/zatca-einvoicing/` (`IMPLEMENTATION-PLAN.md` + `extracted/01..06`). All 6 official ZATCA PDFs read end-to-end.

**Hard-won facts (resolved against the ZATCA SDK itself — these override the docs where they conflict):**
- **ECDSA curve = `secp256k1`** (NOT P-256/secp256r1). The Security Features PDF's "P-256" line is a known doc error; SDK ships `ec-secp256k1-priv-key.pem`. JDK 16+ removed secp256k1 from SunEC → **SDK must run on Java 11** (user has `openjdk@11`; Java 23 also installed but breaks it).
- **PIH first-invoice seed** = `NWZlY2ViNjZmZmM4NmYzOGQ5NTI3ODZjNmQ2OTZjNzljMmRiYzIzOWRkNGU5MWI0NjcyOWQ3M2EyN2ZiNTdlOQ==` (base64 of SHA-256("0") hex string).
- **Signature** = XAdES-B-B, ECDSA+SHA-256, enveloped in `ext:UBLExtensions`. **C14N 1.1** (`xml-c14n11`). Hash = SHA-256 over XML after XPath-excluding UBLExtensions, cac:Signature, AdditionalDocumentReference[ID='QR'].
- **QR** = binary TLV (Tag+Length are raw bytes, not ASCII), tags 1-5 Phase 1, 1-9 Phase 2 (tag 9 simplified only); whole TLV → base64. Two official test vectors in `extracted/03-qr-code.md`.
- **Invoice subtype** = `@name="NNPNESB"` attr on cbc:InvoiceTypeCode (01=standard→Clearance/blocking, 02=simplified→Reporting/24h). ONE unified ICV/PIH chain per EGS; rejected invoices still consume ICV.
- **Endpoints** (`/compliance`, `/compliance/invoices`, `/production/csids`, `/invoices/clearance/single`, `/invoices/reporting/single`), HTTP Basic auth w/ CSID+secret, header `accept-version: v2`. Sandbox OTP is static `123456`.

**Decisions:** signing = pure-TS at runtime + **ZATCA SDK as CI conformance oracle**. Architecture = quarantined `apps/api/src/zatca/` module, tenant schema `packages/db/src/schema/zatca.ts`, encrypted creds via existing `packages/shared/src/crypto.ts` AES-256-GCM, pg-boss for async reporting, QR via `apps/web/src/features/pos/print/qr.ts`. 100% test coverage (financial/compliance).

**SDK location:** `/Users/hus3ain/Downloads/zatca-envoice-sdk-203` (v3.0.8). Run: `FATOORA_HOME=$SDK/Apps JAVA_HOME=<openjdk@11> $SDK/Apps/fatoora <flags>`. Ships UBL XSDs (`Data/Schemas/xsds`), Schematron BR-KSA rules (`Data/Rules/schematrons`), CSR template/example (`Data/Input/`), sample key+cert (`Data/Certificates/`).

**STATUS 2026-06-11: BUILT + reviewed + PR open.** Branch `phase-2/zatca-einvoicing` (12 commits) in isolated worktree `/Users/hus3ain/Development/Zerupt/erp-zatca`. **PR #151** (HussainBedawala/zerupt-erp). DEV-416 In Progress. 6 specialist reviewers ran; all CRITICAL/HIGH fixed. Crypto byte-exact verified vs SDK (`fatoora -generateHash`/`-validate`). Tests: jest src/zatca 176, shared 328, web zatca 9. Gated dormant (`ZATCA_ENABLED` off + KSA-only). EGS granularity = per-register + shared server-EGS.

**⚠️ Before merge:** rebase on main + RENUMBER migrations `0073_zatca`/`0074` (other agent's `0073_fair_lilith` collides in drizzle journal).
**Deferred (flagged):** non-SAR rejected (FX/BT-111 = TODO); buyer Saudi National Address on B2B (needs customer-address field); per-register CSID selection in POS UI.
**Manual go-live:** `agent-os/product/zerupt-specs/zatca-einvoicing/MORNING-BRIEF.md` — sandbox OTP static `123456`; production needs each tenant's Fatoora/ERAD OTP; env `ZATCA_ENABLED` + `ZATCA_API_BASE_*`; legal sign-off (data residency/SaaS onboarding). Runtime signing pure-TS (no JVM in prod); SDK only CI oracle (`ZATCA_SDK_ROOT`+JDK11).

See [[project_corporate_structure]] (Malakstar India = vendor entity) and [[project_zatca_einvoicing_research]] (original brief).
