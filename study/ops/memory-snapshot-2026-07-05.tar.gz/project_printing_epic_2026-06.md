---
name: printing-epic-2026-06
description: "Printing/receipts/transfers/orders 10-layer epic — ALL DONE 2026-06-07, 12 commits b5eda8d..50b60ba, uncommitted on shared branch"
metadata: 
  node_type: memory
  type: project
  originSessionId: 84481297-5272-4b28-ae64-7d17c9121ab0
---

10-layer printing epic (plan doc deleted at wrap) completed 2026-06-07. Commits b5eda8d..50b60ba on the shared branch (`phase-4c/purchase-full-lifecycle` checkout; `phase-0/e2e-pom-infrastructure` pointer kept at same HEAD). NOT yet pushed/PR'd — another agent still working on the same branch (purchase lifecycle, e2e files).

Shipped: print-agent system printing + discovery + packaged binaries/installers (notify-only updates, no code signing); printer setup wizard + calibration; dot-matrix ESC * graphics (escp-raster.ts, form length UI-capped at 127 per ESC C); receipt templates classic/compact/bilingual + gift/duplicate + z-report via agent; internal EAN-13 barcodes (prefix 2, doc type `bar`, bulk reserveNumbers) + label printing (thermal via agent raster, A4 grids); digital receipt (tenant 0046 receipt_token, admin receipt_tokens 0007/0008, @Public /public/receipts/:token uuid-pipe 404, web (public)/r/[token], QR via `qrcode` lib + jsqr round-trip tests, app.zerupt.com/r/{token}); stock transfers (WAC cost-carry, in-transit GL); lean sales orders (convert→invoice sourceOrderId, DDL rode in 0044).

Migrations 0042–0046 (tenant) + 0007/0008 (admin) applied to dev DBs. All gates green: api 3997 tests, web 1705, lint 0 errors. Specs added under agent-os/product/ (pos/10, inventory/12+13, sales/09); study notes study/phase-4a/ (root repo pushed 75992f0).

**Remaining:** push + PR once the parallel agent's work is committed; production tenant migration via Railway pre-deploy. TRUST_PROXY env var added to .env.example — set on Railway.
