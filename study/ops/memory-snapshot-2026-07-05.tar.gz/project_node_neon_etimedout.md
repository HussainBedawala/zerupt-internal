---
name: node-neon-etimedout-fix
description: Fix for ETIMEDOUT AggregateError when node/pg/drizzle-kit connects to Neon (Happy Eyeballs 250ms too short for ap-southeast-1)
metadata: 
  node_type: memory
  type: project
  originSessionId: 84481297-5272-4b28-ae64-7d17c9121ab0
---

`drizzle-kit migrate` / any node-postgres connection to the Neon dev DBs (ap-southeast-1) can fail with `AggregateError [ETIMEDOUT]` (6 inner errors — one per resolved IP). Cause: Node 20+ Happy Eyeballs (`autoSelectFamily`) races each address with a 250ms connect timeout, too short for Singapore latency from Hussain's network. TCP/TLS to the IPv4 addresses works fine.

**How to apply:** prefix the command with `NODE_OPTIONS="--network-family-autoselection-attempt-timeout=10000"`. Verified working 2026-06-05 for tenant migrations from `erp/packages/db`. Sandboxed Bash also can't reach Neon — have the user run it via `!` if needed.
