---
name: project_neon_db_topology
description: Neon project/branch/tenant-DB topology + how to safely apply tenant migrations via MCP
metadata: 
  node_type: memory
  type: project
  originSessionId: ab5eeb1b-1319-4547-84c2-f34250ea1ccb
---

Neon project **Zerupt** = `restless-hill-33464873` (org Hussain, ap-southeast-1, pg17). Single project, two branches:

- **DEV branch** `br-old-recipe-a1d3dw26` (endpoint `ep-fancy-king-a11gw110`). `.env` (`DATABASE_ADMIN_URL`, `DIRECT_URL_TENANT`) points here. DBs: `zerupt_admin`, `zerupt_tenant_dev` (drizzle-kit template/scratch only), plus the REAL provisioned per-tenant DBs the running dev app uses: `zerupt_tenant_al_noor_mobiles_mq9eexcw`, `zerupt_tenant_zerupt_e2e_co_mq3zsaaj`.
- **PROD/default branch** `br-red-term-a1vs9ndl` (endpoint `ep-patient-surf-a1adanmx`). DBs: `zerupt_admin`, `zerupt_tenant_al_noor_mobiles_mq8gsvl3`.

Key gotcha: per-tenant DBs are SEPARATE databases. `drizzle-kit migrate` against `DIRECT_URL_TENANT` only hits `zerupt_tenant_dev` (the template) — it does NOT migrate the real provisioned tenant DBs. The dev app's signed-in tenant uses `..._mq9eexcw`, so a missing-column onboarding bug = that tenant DB being behind, not the template.

Source of truth for "what's applied" = the `drizzle.__drizzle_migrations` table IN each tenant DB (NOT the admin `tenant_databases.migration_version`, which is inconsistently a tag or an ISO timestamp). Admin registry: `tenant_databases(db_name, db_host, status, migration_version)` enumerates tenant DBs per branch (query on each branch's `zerupt_admin`).

**Applying a migration to a tenant DB by hand via Neon MCP (the right way):** drizzle stores `hash = sha256(<migration .sql file bytes>)` and `created_at = <journal `when` ms from drizzle/meta/_journal.json>`. Verified against existing rows. So per migration, run its SQL (split on `--> statement-breakpoint`) THEN `INSERT INTO drizzle.__drizzle_migrations (hash, created_at) VALUES ('<sha256>', <when>)` — all in one `run_sql_transaction`. Then set admin `tenant_databases.migration_version` to the latest tag (e.g. `0077_stormy_tyrannus`) — that's what `migrate-all-tenants.service.ts` writes. This is identical to what the deploy migrator does, so the next deploy skips them.

The blessed alternative for PROD: Railway pre-deploy runs `node dist/migration/migrate-tenants.cli --apply` (loops admin registry, transactional). Writing prod customer DBs by hand via MCP is blocked by the auto-mode classifier — needs explicit user approval. See [[project_admin_migration_deploy_gap]].
