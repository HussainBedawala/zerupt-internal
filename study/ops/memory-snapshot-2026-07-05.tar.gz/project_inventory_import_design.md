---
name: project_inventory_import_design
description: Singular Mira import pipeline — REFINE the existing consolidation engine for inventory (not build new); branch phase-3/mira-consolidation-inventory
metadata:
  node_type: memory
  type: project
  originSessionId: 9ff8ead1-3aa4-4fe6-8c12-619f0bd94bd8
---

**MAJOR PIVOT 2026-06-14 (v3, code-grounded — supersedes the v2 "build inventory import" plan below).**
Deep recon proved the singular pipeline ALREADY EXISTS: the Mira multi-file **consolidation/migration
engine** (`apps/api/src/migration/` + `apps/ai/app/migration/` + onboarding `mira-import/`). It already
consolidates (clean→consolidate AI) and commits categories→products→customers→suppliers + opening
stock + AR/AP + GL + OBE plug, with pre-post tie-out + reconciliation + resumable buckets, live in
onboarding. **Do NOT build a 2nd/3rd pipeline. TB import is UNTOUCHABLE (founder: perfected).**
Objective (founder verbatim): "one singular WORKING and ACCURATE pipeline, similar to TB." Plan doc
rewritten: `erp/docs/inventory-import-plan.md` (v3). Branch `phase-3/mira-consolidation-inventory`.

**Confirmed gaps (the whole job):**
- 1141 inventory tie-out ALREADY WIRED (reconciliation.service `inventory_subledger` line: Σ
  materializedStockLevels.totalValue vs balanceForRole merchandise_inventory; mismatch→hasMismatch→
  migration commit ledgerTiesOut=false). Just verify + SURFACE well.
- G1 per-warehouse stock COLLAPSES (real silent bug): consolidation.py keys product node on ITEM_CODE
  only → multi-warehouse item keeps only wh-1 qty. Fix: composite (item_code,location) key + synthesizeStock per (sku,wh).
- G2 barcodes+sellPrice HALF-BUILT: ImportApplyService product apply already accepts barcode(→itemBarcodes)
  + sellingPrice; only ClaimRole + projectProducts lack the roles. Pack units = no path (defer).
- G4 no in-product entry (only onboarding has drop+commit; /settings/migration/[id] review-only).
- Harmony (founder mandate, generic, NOTHING SILENT): H1 skipped-stock items only logger.warn→surface;
  H3 commit `difference`=OBE residual not the mismatched line→surface specific line+amount; H4 1141
  unbound→friendly msg; H5 sweep whole commit/synthesis/consolidation for silent collapse/skip/default.

**Build phases:** P1 in-product entry (test harness) → P2 mismatch surfacing → P3 per-warehouse → P4
barcodes/sell → P5 adversarial E2E (clean→dirty individual files in MAIN PRODUCT post-TB, not onboarding).
**Entry shape (founder):** BOTH global surface (Settings + Dashboard) AND per-module buttons (Items/
Customers/Suppliers), all → ONE reusable in-product Mira flow. FE leaf components are standalone
(FileDropSurface, DecisionCardStack, MatchingReviewPanel, MiraNarrationPanel, CommitSummary, 3 session
mutations from features/migration-matching/api/session-queries); only MiraImportScreen's setScreen("goLive")
is wizard-store-coupled → becomes router nav in-product. Em-dash i18n edits from concurrent agent =
fold into final commit (founder OK'd). [[project_resolver_engine_tb_import]] [[feedback_assume_dumb_customers]]

---
<details><summary>SUPERSEDED v2 plan (pre-pivot — kept for history)</summary>

Unified inventory (catalogue+stock) + customers/suppliers import, mirroring the TB import experience. Plan doc: `erp/docs/inventory-import-plan.md` (v2, finalized 2026-06-14 via 3-iteration agent loop: draft → 2 adversarial critiques → v2 → convergence gate PASS). Supersedes the old aspirational `erp/docs/inventory-import-design.md`.

**Core idea:** TB owns the GL control totals (1141 inventory, 1131 AR, 2111 AP). Collapse today's 7 onboarding import rows (category+product+openingStock, customer+openingReceivables, supplier+openingPayables) into 3 single-file drops: Catalogue&Stock, Customers, Suppliers. Each reconciles Σ back to its TB control. Categories DERIVED from the item file. Decision cards GROUPED/typed (one "200 categories", one "Cost vs Sell price", one reconciliation), NEVER per-row (the #1 abandonment risk at 5000 SKUs).

**Key recon facts (code-confirmed, corrected the old doc):**
- `opening-import/opening-stock-import.service.ts` (`kind='stock'`) ALREADY does upload→validate→apply with CAS, fingerprint, (item,warehouse) dedup, NO GL, partial recovery. EXTEND it — do NOT fork a `kind='inventory'`. `StockAdjustmentsService.createOpeningBalance` has no cross-run dedup (the import layer is load-bearing).
- TB posts 1131/2111/1141 by DEFAULT; party import's `assertControlAccountUnseeded` then 409s. So per-party import is currently unusable post-TB. Fixing = real code change.
- 1141 reconciliation contract is specified but NEVER wired (stock import never reads the TB run).
- `resolver-engine` accepts arbitrary catalog + tenant-scoped `category` memory (target_key = stable per-tenant key, NOT UUID). Two resolvers: keep `ImportResolutionService` for COLUMN mapping, ADD `resolver-engine` for VALUE resolution.
- BUG to fix: `ImportApplyService.applyCategory` raw-inserts bypassing `MAX_CATEGORY_DEPTH=4`.
- Run schema has `parkedAmount/parkedReason/parkedAck` → reuse for the 1141 OBE residual (not a soft log).
- Customers/suppliers pages have NO import button (items page does → `/inventory/items/import`).

**CONFIRMED founder decisions (2026-06-14):** (1) extend kind='stock'; (2) AR/AP = Option A (TB optionally excludes 1131/2111 when per-party detail comes; party import posts detail; handles partial); (3) no-TB stock = post DR 1141 / CR Opening Balance Equity + pending-expected-1141, never block; (4) one file per domain; (5) MVP wedge first; (6) categories derived, residual parks to OBE w/ ack.

**MVP cut to build next (no branch yet):** 1141 GL-read query + types → InventoryExtractor + section/pivot segmenter + numeric normalization (Arabic-Indic digits, currency symbols) → diagnosis client (`/ai/diagnose` entityHint, regex fallback) → resolver-engine config (dynamic category tree + warehouse + pack) → extend stock apply with master-data phases (categories/items/barcodes/packs, fix depth bypass) [5a] → reconciliation Σ(file line totals) vs 1141 + OBE residual + resumable per-phase [5b] → InventoryImportDialog FE (category-tree review, net-change preview, SSE progress, cost-vs-price + reconciliation cards) → catalogue-only zero-stock path. FAST-FOLLOW: TB AR/AP exclusion + customers/suppliers unify + import buttons; no-TB edge already in MVP scope per decision 3; pivot-warehouse cards; onboarding Step 7 rework.

Reconciliation basis = Σ(file line totals qty_pack×cost_pack), NOT re-derived per-base cost (rounding). Then E2E live on fresh KSA tenant, then commit. 100% coverage on money paths.

**ADDED v2.1 (2026-06-14, two core principles + MVP constraints):**
- **§2b ENTITY-GRAPH IMPORTER:** a file = denormalized view of an entity graph. Diagnosis identifies ALL entity types present (item/category/supplier/customer/warehouse/taxGroup/brand), resolver-engine (already multi-entity via entity_kind) resolves each vs its OWN table + stubs missing, apply wires relationships (= knowledge-graph edges). Build a general entityType→{table,create,link} ROUTER, not N special cases. "One file per domain" governs PRIMARY entity + reconciliation only; any file may reference other entities. CONFIRMED MVP RULE: MVP routes catalogue domain only; if it RECOGNIZES another entity column (supplier/customer/brand/tax-group), TELL THE USER + direct them to the right page, NEVER silently drop. Router = fast-follow.
- **§2c BILINGUAL NAMES (correct, no hacks):** items.name NOT NULL = primary-language; display has NO fallback. Correct = (1) detect each value's language (script), (2) place in its MATCHING language slot, (3) if primary-lang name absent → GENERATE via first-class reviewed stage (brand-aware: transliterate proper nouns/brands, translate generics; confidence-gated; non-blocking; language-agnostic from registry). NO translation infra exists today (only AR→Latin transliterator in scanner). CONFIRMED MVP RULE — NO HACKS: MVP does detect+correct-placement fully; NEVER silently mis-files wrong-language into a slot. Missing primary → EXPLICIT acknowledged user choice ("file is English but shop is Arabic — add Arabic now / keep English for now"). AI auto-generation that pre-fills that review = fast-follow.
- Infra facts: items has NO defaultSupplierId (only supplier_item_codes scanner cache); category hierarchy only single-col/indentation/code-prefix (multi-column cat+subcat = NEW build); supplier+customer createable name-only; item tax = taxGroupId FK (no rate); barcode type enum ean13/upca/code128/custom; bilingual-name.ts primaryText=name always, secondaryText=nameAlt??null (no fallback).

[[project_resolver_engine_tb_import]] [[project_pack_units_uom]] [[feedback_assume_dumb_customers]] [[feedback_language_agnostic_names]] [[project_knowledge_graph]]
</details>
