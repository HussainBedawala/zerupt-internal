---
name: project_knowledge_graph
description: "2026-06-11 — business knowledge graph (DEV-417) built + shipped to main; the connected brain Zee/Mira/Sami read from"
metadata:
  node_type: memory
  type: project
  originSessionId: 91ab4f03-fc19-4334-a627-a24832f67a01
---

2026-06-11: built the tenant-scoped **business knowledge graph** (Linear DEV-417, V2 project) and shipped to `origin/main` in one commit `c7b6bb7` (52 files, all gates green). The realization of the knowledge-graph rung from [[project_mira_ingestion_brain]].

**What it is (deliberately NOT a graph DB, NOT pgvector):** a graph *view* over the relational tables already present, plus ONE thin tenant-scoped `graph_edges` table (`from_type/from_id/to_type/to_id/edge_type/confidence/source/metadata`, idempotent 6-tuple unique) for the relationships that aren't already FKs. Edge kinds materialized: `supplied_by` (inferred), `duplicate_of`, `resolved_from`. Everything else (owes/bills/contains/posts_to/belongs_to…) is computed via Postgres traversals. Deterministic + auditable so it sits next to the money. Migration `0075_majestic_kinsey_walden` (applied to dev tenant).

**Architecture:**
- `apps/api/src/graph/` — `GraphModule`/`GraphService` (exported): `addEdges` (idempotent upsert), `inbound`/`outbound`, `blastRadius`, `bothSidesParties`, `dormantCapital`, `insights`. SQL builders in `graph/queries/*`. Endpoints `GET /tenant/graph/{blast-radius,both-sides-parties,insights}`.
- **Born from the migration (Mira):** `migration-session.service.consolidate()` seeds `duplicate_of` + `resolved_from` edges best-effort at go-live (`graph-edge-derivation.ts`), then `supplied-by-inference.ts` infers `item→supplier` from purchase history. Never fails go-live.
- **Agent access:** Sami = scanner enriches matches with supplier exposure + both-sides (`graphContext`); Zee = dashboard insights endpoint; Mira = edge seeding.

**The user FEELS it (3 features, AR+EN, defensive):**
1. Pre-delete **blast-radius guard** — `DELETE`/deactivate on item/customer/supplier returns 409 + `?force=true` override; calm dialog lists dependencies (`blast-radius-dialog.tsx`, `blast-radius.guard-helper.ts`).
2. **Dormant-capital + orphan** insight widget on the dashboard (`graph-insights-widget.tsx`, `graphInsights` widget).
3. **Both-sides-party** reconciliation surfacing (customer AND supplier with net AR/AP).

**Also shipped same commit:** hardened the learning flywheel — explicit `tenantId` WHERE on both learned-cache lookups (defense-in-depth) + live re-hydration of Mira's "remembers" suggestions on session resume.

**Left for founder (NOT done):** customer/supplier *frontend* deactivate dialogs still use plain confirms — backend guard + `BlastRadiusDialog` ready, one-line swap each (located under sales/customers + suppliers web features). Concurrent founder session's import-UI working-tree changes were deliberately NOT committed (shared-tree entanglement; stash@{0} holds their WIP).

Spec: `agent-os/product/zerupt-specs/knowledge-graph/`. Driven by [[feedback_assume_dumb_customers]], extends [[project_mira_ingestion_brain]] + [[project_ai_cost_routing_philosophy]].
